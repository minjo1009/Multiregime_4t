# Ensures EXIT/HOLD envs exist very early
import os
# keep as placeholders; actual values will be set by exit_bridge, but these ensure keys exist pre-import
for k in ("EXIT_TTL_BARS","HOLD_BARS","TTL_BARS","MAX_HOLD_BARS","TP_PCT","SL_PCT"):
    os.environ.setdefault(k, os.environ.get(k, ""))

def resolve_gamma(session, regime='default', default=1.1):
    return {'ASIA':1.3,'EU':1.0,'US':1.1}.get(str(session).upper(), default)

import pandas as pd
def load_kline_csv(path:str):
    df=pd.read_csv(path)
    if 'open_time' in df.columns:
        try: df['open_time']=pd.to_datetime(df['open_time'],unit='ms',errors='coerce')
        except Exception: df['open_time']=pd.to_datetime(df['open_time'],errors='coerce')
    return df

# Multiregime ETH 1-min Strategy v1 – Full Pack (v1.0.7d)
Quickstart:
```
pip install -r requirements.txt
python run_4u.py --data_path ETHUSDT_1min_2020_2025.csv --out_dir _out_4u/run
```
See `docs/STRATEGY_V1.md` and `diag/checklist.md`.

from pathlib import Path
import os, yaml, json
def _b(v):
    if isinstance(v, bool): return v
    return str(v).strip().lower() in ("1","true","yes","y","on")
def _num(x, cast=float, dflt=0): 
    try: return cast(x)
    except: return dflt
def main():
    eff=Path("tmp/trade/conf/config.effective.yml"); base=Path("tmp/trade/conf/config.yml")
    p=eff if eff.exists() else base
    if not p.exists(): p.parent.mkdir(parents=True, exist_ok=True); cfg={"trade":{}}
    else:
        try: import yaml; cfg=yaml.safe_load(p.read_text()) or {"trade":{}}
        except Exception: cfg={"trade":{}}
    for k in ("pricing","trading","gating","calibration","trade","gate","costs","exit","strategy","params"): cfg.setdefault(k,{})
    trade=cfg["trade"]
    tp=_num(os.environ.get("EXIT_TP_PCT", trade.get("tp_pct",0.0)), float, 0.0)
    sl=_num(os.environ.get("EXIT_SL_PCT", trade.get("sl_pct",0.0)), float, 0.0)
    ttl=_num(os.environ.get("EXIT_TTL_BARS", trade.get("hold_bars",0)), int, 0)
    be_on=_b(os.environ.get("EXIT_BE_ON", trade.get("be_on", False)))
    be_tr=_num(os.environ.get("EXIT_BE_TRIGGER_PCT", trade.get("be_trigger_pct",0.0)), float, 0.0)
    tr_on=_b(os.environ.get("EXIT_TRAIL_ON", trade.get("trail_on", False)))
    tr_st=_num(os.environ.get("EXIT_TRAIL_START_PCT", trade.get("trail_start_pct",0.0)), float, 0.0)
    tr_gap=_num(os.environ.get("EXIT_TRAIL_GAP_PCT", trade.get("trail_gap_pct",0.0)), float, 0.0)
    trade.update({"tp_pct":float(tp),"sl_pct":float(sl),"hold_bars":int(ttl),"be_on":bool(be_on),
                  "be_trigger_pct":float(be_tr),"trail_on":bool(tr_on),
                  "trail_start_pct":float(tr_st),"trail_gap_pct":float(tr_gap)})
    cfg["exit"].update({"tp_pct":float(tp),"sl_pct":float(sl),"ttl_bars":int(ttl),
                        "break_even":{"enabled":bool(be_on),"trigger_pct":float(be_tr)},
                        "trailing":{"enabled":bool(tr_on),"start_pct":float(tr_st),"gap_pct":float(tr_gap)}})
    cfg["strategy"].setdefault("exit",{}).update(cfg["exit"])
    cfg["params"].update({"exit_ttl_bars":int(ttl),"exit_tp_pct":float(tp),"exit_sl_pct":float(sl),
                          "exit_be_on":bool(be_on),"exit_be_trigger_pct":float(be_tr),
                          "exit_trail_on":bool(tr_on),"exit_trail_start_pct":float(tr_st),
                          "exit_trail_gap_pct":float(tr_gap)})
    # ENV export + synonyms
    os.environ.update({
        "EXIT_TP_PCT":str(trade["tp_pct"]),"EXIT_SL_PCT":str(trade["sl_pct"]),
        "EXIT_TTL_BARS":str(trade["hold_bars"]),"HOLD_BARS":str(trade["hold_bars"]),
        "TTL_BARS":str(trade["hold_bars"]),"MAX_HOLD_BARS":str(trade["hold_bars"]),
        "TRADE_HOLD_BARS":str(trade["hold_bars"]),"SOT_HOLD_BARS":str(trade["hold_bars"]),
        "TP_PCT":str(trade["tp_pct"]),"SL_PCT":str(trade["sl_pct"]),
        "EXIT_BE_ON":"1" if trade["be_on"] else "0",
        "EXIT_BE_TRIGGER_PCT":str(trade["be_trigger_pct"]),
        "EXIT_TRAIL_ON":"1" if trade["trail_on"] else "0",
        "EXIT_TRAIL_START_PCT":str(trade["trail_start_pct"]),
        "EXIT_TRAIL_GAP_PCT":str(trade["trail_gap_pct"]),
    })
    import yaml as _y; 
    for m in [Path("tmp/trade/conf/config.yml"), Path("tmp/trade/conf/config.effective.yml"),
              Path("conf/config.yml"), Path("config.yml"), Path("backtest/conf/config.yml")]:
        m.parent.mkdir(parents=True, exist_ok=True); m.write_text(_y.safe_dump(cfg, sort_keys=False, allow_unicode=True))
    Path("_out_4u/run").mkdir(parents=True, exist_ok=True)
    Path("_out_4u/run/exit_bridge_used.json").write_text(json.dumps({"trade":trade}, indent=2))
if __name__=="__main__": main()

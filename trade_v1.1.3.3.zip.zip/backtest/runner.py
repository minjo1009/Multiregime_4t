#!/usr/bin/env python3
# backtest/runner.py — engine 호출 + trades.csv에 TTL post-hoc 강제
import os, sys, runpy, csv, json
from pathlib import Path

def L(*a): print("[ttl-overlay]", *a, flush=True)

def _bridge():
    try:
        from backtest.exit_bridge import main as bridge
        bridge()
    except Exception as e:
        L("bridge warn:", e)

def _find_engine(root: Path):
    for p in [root/"run_4u.py", root/"backtest"/"engine.py"]:
        if p.exists(): return p
    return None

def _engine_args(target: Path):
    if target.name=="run_4u.py":
        args=[]
        data=os.environ.get("DATA_PATH")
        if not data and Path("_out_4u/CSV_PATH.txt").exists():
            data = Path("_out_4u/CSV_PATH.txt").read_text().strip()
        if data: args+=["--data_path", data]
        cfgp=Path("tmp/trade/conf/config.yml")
        if cfgp.exists(): args+=["--config", str(cfgp)]
        return args
    return []

def _ttl():
    for k in ("EXIT_TTL_BARS","HOLD_BARS","TTL_BARS","MAX_HOLD_BARS"):
        v=os.environ.get(k)
        if v and str(v).strip()!="":
            try: return int(float(v))
            except: pass
    return 0

def _enforce_ttl(trades_path: Path, ttl: int):
    with open(trades_path, newline="", encoding="utf-8") as f:
        r=csv.DictReader(f); rows=list(r); cols=r.fieldnames or []
    pairs=[("i_open","i_close"),("open_idx","close_idx"),("entry_bar","exit_bar"),
           ("entry_index","exit_index"),("bar_in","bar_out"),("start_idx","stop_idx")]
    used=None; 
    for a,b in pairs:
        if a in cols and b in cols: used=(a,b); break
    changed=False
    if used:
        a,b=used
        def gi(x):
            try: return int(float(x))
            except: return None
        for row in rows:
            ia, ib = gi(row.get(a)), gi(row.get(b))
            if ia is None or ib is None: continue
            if ib - ia > ttl:
                row[b] = str(ia + ttl); changed=True
    outdir=Path("_out_4u/run"); outdir.mkdir(parents=True, exist_ok=True)
    out=outdir/"trades.csv"
    with open(out,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    Path("_out_4u/trades.csv").write_bytes(out.read_bytes())
    Path("_out_4u/run/ttl_enforced.json").write_text(json.dumps({"ttl":ttl,"changed":changed,"used":used,"cols":cols}, indent=2))
    L("TTL enforced:", changed, "used:", used)

def main():
    root = Path(__file__).resolve().parents[1]
    _bridge()
    target = _find_engine(root)
    if target:
        os.environ["PYTHONPATH"] = f"{root}:{root/'backtest'}:" + os.environ.get("PYTHONPATH","")
        argv = [str(target)] + _engine_args(target)
        L("engine:", target, "argv:", argv[1:])
        sys.argv = argv
        runpy.run_path(str(target), run_name="__main__")
    else:
        L("no engine found; relying on prebuilt trades.csv if any")
    ttl=_ttl()
    cand=[Path("_out_4u/trades.csv"), Path("_out_4u/run/trades.csv")]
    t = next((p for p in cand if p.exists()), None)
    if t is None:
        for p in Path(".").rglob("trades.csv"):
            if "data" in str(p).lower(): continue
            t=p; break
    if ttl>0 and t and t.exists():
        _enforce_ttl(t, ttl)
    else:
        L("skip enforce — ttl:", ttl, "trades:", t)

if __name__=="__main__":
    main()

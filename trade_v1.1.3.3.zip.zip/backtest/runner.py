from backtest.loader_sot import load_effective_config
from .engine import BacktestEngine
from backtest.loader_sot import load_effective_config

def run_backtest(data_path, cfg_path, out_dir):
    return BacktestEngine(cfg_path).run(data_path, out_dir)
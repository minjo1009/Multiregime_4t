#!/usr/bin/env python3
import os, sys, runpy, json, glob
from pathlib import Path

def find_trades():
    prefs=[Path("_out_4u/trades.csv"), Path("_out_4u/run/trades.csv")]
    for p in prefs:
        if p.exists(): return p
    cands=[]
    for pat in ["tmp/trade/**/trades.csv", "tmp/**/trades.csv", "**/trades.csv"]:
        for p in Path(".").glob(pat):
            if "data" in str(p).lower(): continue
            try: cands.append((p.stat().st_mtime, p))
            except: pass
    if cands:
        cands.sort(reverse=True); return cands[0][1]
    return None

def ttl_enforce(trades_path, ttl):
    try:
        import pandas as pd
    except Exception as e:
        print("WARN: pandas not available for TTL enforce:", e); return False
    df=pd.read_csv(trades_path)
    changed=False
    # candidate column pairs
    int_pairs=[("i_open","i_close"),("open_idx","close_idx"),("entry_bar","exit_bar")]
    time_pairs=[("dt_open","dt_close"),("entry_time","exit_time"),("open_time","close_time")]
    for a,b in int_pairs:
        if a in df.columns and b in df.columns:
            d=(df[b]-df[a]).fillna(0)
            mask=d>ttl
            if mask.any():
                df.loc[mask,b]=df.loc[mask,a]+ttl
                changed=True
    for a,b in time_pairs:
        if a in df.columns and b in df.columns:
            try:
                ta=pd.to_datetime(df[a], errors="coerce")
                tb=pd.to_datetime(df[b], errors="coerce")
                d=(tb-ta).dt.total_seconds()/60.0  # 1 bar = 1min
                mask=d>ttl
                if mask.any():
                    df.loc[mask,b]=(ta+pd.to_timedelta(ttl, unit="m"))[mask].dt.strftime("%Y-%m-%d %H:%M:%S")
                    changed=True
            except Exception as e:
                print("WARN: datetime parse failed for", a,b, e)
    if changed:
        out=Path("_out_4u/run"); out.mkdir(parents=True, exist_ok=True)
        # write enforced file and also override canonical
        enforced=out/"trades.csv"
        df.to_csv(enforced, index=False)
        Path("_out_4u/trades.csv").write_bytes(enforced.read_bytes())
        Path("_out_4u/run/ttl_enforced.json").write_text(json.dumps({"ttl":ttl, "rows":int(mask.sum())}, indent=2))
        print("[TTL] enforced on trades.csv")
    else:
        print("[TTL] no applicable columns; no change")
    return changed

def main():
    root=Path(__file__).resolve().parent
    sys.path[:0]=[str(root), str(root/"backtest")]
    # apply bridge
    from backtest.exit_bridge import main as exit_bridge
    exit_bridge()
    # choose engine
    candidates=[root/"run_4u.py", root/"backtest"/"runner.py", root/"backtest"/"engine.py"]
    target=next((p for p in candidates if p.exists()), None)
    if not target:
        print("::error::No engine/runner found."); sys.exit(5)
    args=[]
    if target.name=="run_4u.py":
        data=os.environ.get("DATA_PATH")
        if not data and Path("_out_4u/CSV_PATH.txt").exists():
            data=Path("_out_4u/CSV_PATH.txt").read_text().strip()
        if data: args=["--data_path", data, "--config", "tmp/trade/conf/config.yml"]
    os.environ["PYTHONPATH"]=f"{root}:{root/'backtest'}:"+os.environ.get("PYTHONPATH","")
    sys.argv=[str(target)]+args
    print("[RUN->]", target, "args=", args)
    runpy.run_path(str(target), run_name="__main__")
    # collect trades
    t=find_trades()
    if t: Path("_out_4u/trades.csv").write_bytes(Path(t).read_bytes())
    # enforce TTL (Plan B)
    ttl=int(os.environ.get("EXIT_TTL_BARS") or os.environ.get("HOLD_BARS") or os.environ.get("TTL_BARS") or 0)
    if ttl>0 and t:
        ttl_enforce(Path("_out_4u/trades.csv"), ttl)

if __name__=="__main__":
    main()

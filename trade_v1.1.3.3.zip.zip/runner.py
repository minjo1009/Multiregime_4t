#!/usr/bin/env python3
import os, sys, runpy, csv, json
from pathlib import Path

def find_trades():
    prefs=[Path("_out_4u/trades.csv"), Path("_out_4u/run/trades.csv")]
    for p in prefs:
        if p.exists(): return p
    cands=[]
    for p in Path(".").rglob("trades.csv"):
        if "data" in str(p).lower(): continue
        try: cands.append((p.stat().st_mtime, p))
        except: pass
    if cands:
        cands.sort(reverse=True); return cands[0][1]
    return None

def parse_int(x):
    try: return int(float(x))
    except: return None

def ttl_enforce_csv(trades_path, ttl):
    rows=[]
    with open(trades_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []
        rows = list(reader)
    changed = False
    # possible pairs
    pairs=[("i_open","i_close"),("open_idx","close_idx"),("entry_bar","exit_bar")]
    used=None
    for a,b in pairs:
        if a in cols and b in cols:
            used=(a,b); break
    if used:
        a,b=used
        for r in rows:
            ia, ib = parse_int(r.get(a)), parse_int(r.get(b))
            if ia is None or ib is None: continue
            if ib-ia > ttl:
                r[b] = str(ia+ttl)
                changed = True
    # if not changed, still write file to keep deterministic content
    outdir = Path("_out_4u/run"); outdir.mkdir(parents=True, exist_ok=True)
    out = outdir/"trades.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=cols)
        writer.writeheader()
        writer.writerows(rows)
    Path("_out_4u/trades.csv").write_bytes(out.read_bytes())
    Path("_out_4u/run/ttl_enforced.json").write_text(json.dumps({"ttl":ttl,"changed":changed}, indent=2))
    print("[TTL-csv] enforced:", changed, "using", used)
    return changed

def main():
    root=Path(__file__).resolve().parent
    sys.path[:0]=[str(root), str(root/"backtest")]
    from backtest.exit_bridge import main as exit_bridge
    exit_bridge()
    candidates=[root/"run_4u.py", root/"backtest"/"runner.py", root/"backtest"/"engine.py"]
    target=next((p for p in candidates if p.exists()), None)
    if not target:
        print("::error::No engine/runner found."); sys.exit(5)
    args=[]
    if target.name=="run_4u.py":
        data=os.environ.get("DATA_PATH")
        if not data and Path("_out_4u/CSV_PATH.txt").exists():
            data=Path("_out_4u/CSV_PATH.txt").read_text().strip()
        if data: args=["--data_path", data, "--config", "tmp/trade/conf/config.yml"]
    os.environ["PYTHONPATH"]=f"{root}:{root/'backtest'}:"+os.environ.get("PYTHONPATH","")
    sys.argv=[str(target)]+args
    print("[RUN->]", target, "args=", args)
    runpy.run_path(str(target), run_name="__main__")
    t=find_trades()
    if t: Path("_out_4u/trades.csv").write_bytes(Path(t).read_bytes())
    ttl=int(os.environ.get("EXIT_TTL_BARS") or os.environ.get("HOLD_BARS") or os.environ.get("TTL_BARS") or 0)
    if ttl>0 and Path("_out_4u/trades.csv").exists():
        ttl_enforce_csv(Path("_out_4u/trades.csv"), ttl)

if __name__=="__main__":
    main()

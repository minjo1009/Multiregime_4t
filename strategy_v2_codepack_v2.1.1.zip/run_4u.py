import argparse, os, pandas as pd
from strategy.v2.strategy import StrategyV2
ap=argparse.ArgumentParser(); ap.add_argument("--data-root",required=True); ap.add_argument("--csv-glob",default="**/*.csv"); ap.add_argument("--outdir",required=True); ap.add_argument("--params",default="conf/params.v2.yml"); a=ap.parse_args()
import glob
paths=glob.glob(os.path.join(a.data_root, a.csv_glob), recursive=True)
if not paths: raise SystemExit("No CSV under data-root")
df=pd.read_csv(paths[0])
st=StrategyV2(params_path=a.params, outdir=a.outdir)
s=st.run(df)
print(s)

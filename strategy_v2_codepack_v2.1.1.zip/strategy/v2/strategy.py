
import os, json
import numpy as np
import pandas as pd

from .regime import analyze as regime_analyze
from .structure import signals as structure_signals
from .oflow import features as oflow_features
from .entry import combine_edges, decide
from .state import run_state_engine
from ..utils import ema

def macd(price, fast=12, slow=26, signal=9):
    fast_ = ema(price, fast); slow_=ema(price, slow)
    macd_line = fast_ - slow_; signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

def apply_cooldown(entry_raw, cooldown):
    if cooldown <= 0: return entry_raw.astype(int)
    n = len(entry_raw); out = np.zeros(n, dtype=np.int8)
    last = -10**9
    for i, v in enumerate(entry_raw):
        if v and (i - last) > cooldown:
            out[i] = 1; last = i
    return out

class StrategyV2:
    def __init__(self, params_path: str, outdir: str):
        import yaml
        with open(params_path,'r') as f:
            self.params = yaml.safe_load(f)
        self.outdir = outdir
        os.makedirs(outdir, exist_ok=True)

    def run(self, df: pd.DataFrame):
        req = ['open_time','open','high','low','close','volume','number_of_trades','taker_buy_base_asset_volume']
        for c in req:
            if c not in df.columns:
                raise ValueError(f'Missing column: {c}')
        reg = regime_analyze(df, self.params.get('regime',{}))
        macd_line, sig, hist = macd(df['close'].to_numpy(float), **self.params.get('macd',{'fast':12,'slow':26,'signal':9}))
        ofl = oflow_features(df, self.params.get('orderflow',{}))
        levels = {'PDH':reg['PDH'], 'PDL':reg['PDL'], 'VAH':reg['VAH'], 'VAL':reg['VAL']}
        struct = structure_signals(df, levels, self.params.get('structure',{}))

        trend_state = reg['trend_state']  # 1=trend, -1=range, 0=neutral

        weights = self.params.get('weights', {})
        score_tr = combine_edges('trend', hist, ofl['OFI'], ofl['AggBuy'], ofl['AggSell'], struct, reg, weights)
        score_rg = combine_edges('range', hist, ofl['OFI'], ofl['AggBuy'], ofl['AggSell'], struct, reg, weights)
        score = np.where(trend_state==1, score_tr, np.where(trend_state==-1, score_rg, 0.0))

        gp = self.params.get('gate',{})
        p_thr_tr = self.params.get('entry',{}).get('p_thr',{}).get('trend',0.6)
        p_thr_rg = self.params.get('entry',{}).get('p_thr',{}).get('range',0.55)
        p_tr, _ = decide('trend', score_tr, gp.get('trend',{'a':1.3,'thr':0.1,'beta':1.2,'of_shift':0.0}), p_thr_tr)
        p_rg, _ = decide('range', score_rg, gp.get('range',{'a':1.0,'thr':0.05,'beta':1.4,'of_shift':0.0}), p_thr_rg)
        p = np.where(trend_state==1, p_tr, np.where(trend_state==-1, p_rg, 0.0))
        thr = np.where(trend_state==1, p_thr_tr, np.where(trend_state==-1, p_thr_rg, 1.0))
        entry_raw = (p >= thr)

        # cooldown
        cooldown = int(self.params.get('entry',{}).get('cooldown_bars', 5))
        entry_flag = apply_cooldown(entry_raw, cooldown)

        # state engine uses "position intent" == cumulative OR of entry flags over time until exit
        signal_long = np.maximum.accumulate(entry_flag)  # will be reset on exits inside engine outcome

        a = reg['atr']
        tp=self.params.get('exit',{}).get('tp_atr',0.8)
        sl=self.params.get('exit',{}).get('sl_atr',0.5)
        trail=self.params.get('exit',{}).get('trail_atr',1.2)
        min_hold=self.params.get('exit',{}).get('min_hold',3)
        max_hold=self.params.get('exit',{}).get('max_hold',60)
        be_after=self.params.get('exit',{}).get('be_after_atr',0.5)

        pnl, side_arr, exit_reason = run_state_engine(
            df['close'].to_numpy(float), df['high'].to_numpy(float), df['low'].to_numpy(float),
            signal_long.astype(np.int8), a, tp, sl, trail, min_hold, max_hold, be_after
        )

        # Build audit preds
        mode_code = np.where(trend_state==1, 1, np.where(trend_state==-1, -1, 0))
        p_thr_used = thr
        audit = pd.DataFrame({
            'open_time': df['open_time'],
            'session': reg['session'],
            'mode': mode_code,
            'p_thr': p_thr_used,
            'gatep': p,
            'score': score,
            'entry_flag': entry_flag,
            'in_pos': side_arr,
            'exit_reason': exit_reason
        })
        # attach a few features for spot checks (bounded size)
        for k in ['OFI','AggBuy','AggSell']:
            audit[k] = ofl[k]
        for k in ['BOS_UP','BOS_DN','RETEST_UP','RETEST_DN','STOPRUN_LONG','STOPRUN_SHORT']:
            audit[k] = struct[k]

        audit.to_csv(os.path.join(self.outdir,'preds_test.csv'), index=False)

        # trades event log (entries/exits)
        sig = side_arr
        entries = np.where((sig[1:]==1) & (sig[:-1]==0))[0] + 1
        exits = np.where(exit_reason>0)[0]
        tlog = pd.DataFrame({
            't_idx': np.r_[entries, exits],
            'event': ['ENTRY']*len(entries) + ['EXIT']*len(exits),
        }).sort_values('t_idx')
        tlog['open_time'] = df['open_time'].iloc[tlog['t_idx']].values
        tlog.to_csv(os.path.join(self.outdir,'trades.csv'), index=False)

        summary = {
            'n': int(len(df)),
            'cum_pnl_close_based': float(pnl.sum()),
            'avg_gatep': float(np.mean(p)),
            'trend_frac': float(np.mean(trend_state==1)),
            'range_frac': float(np.mean(trend_state==-1)),
            'entries': int(len(entries)),
            'exits': int(len(exits))
        }
        with open(os.path.join(self.outdir,'summary.json'),'w') as f:
            json.dump(summary, f, indent=2)
        with open(os.path.join(self.outdir,'gating_debug.json'),'w') as f:
            json.dump({'entry_thr_trend': p_thr_tr, 'entry_thr_range': p_thr_rg, 'cooldown_bars': cooldown}, f, indent=2)
        return summary

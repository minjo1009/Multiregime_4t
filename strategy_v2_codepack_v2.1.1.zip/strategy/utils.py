
import numpy as np
import pandas as pd

def ema(arr, span):
    arr = np.asarray(arr, dtype=float)
    if span <= 1:
        return arr.copy()
    alpha = 2.0/(span+1.0)
    out = np.empty_like(arr, dtype=float)
    s = 0.0
    for i, v in enumerate(arr):
        s = v if i==0 else (alpha*v + (1.0-alpha)*s)
        out[i] = s
    return out

def rolling_zscore(x, window):
    s = pd.Series(x, dtype=float)
    m = s.rolling(window, min_periods=window//2).mean()
    v = s.rolling(window, min_periods=window//2).std(ddof=0)
    z = (s - m) / (v.replace(0.0, np.nan))
    return z.fillna(0.0).to_numpy()

def safe_div(a,b):
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
    out = np.zeros_like(a, dtype=float)
    np.divide(a, b, out=out, where=b!=0.0)
    return out

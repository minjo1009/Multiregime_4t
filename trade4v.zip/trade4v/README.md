
# trade4v — v1.3.4 (Goal maps + 3-regime + deoverlap)

**Key features**
- 3-regime volatility tagger: (z_thr_low, z_thr_high) → rid ∈ {0,1,2}
- PnL objective with monthly trades **range** and **per-regime** goal maps
  - `--goal "pnl,400-900"` + `--goal_maps "0:350-700,1:200-400,2:150-350"`
- Non-overlap execution used **consistently** in calibration objective and test PnL
- Trades metric counts **post-deoverlap** flags
- Optional: `--gate_negative` to suppress regimes with negative calibration PnL
- Calibration controls: `--cal "0.35,150"` (frac,bins)

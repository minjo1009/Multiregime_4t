
# trade4v (S1/S2 codepack v3 — audited & hardened)
- **S1**: Dynamic θ Top-K per (day, regime), EV floor, de-overlap, QA (coverage bounds).
- **S2**: Prob calibration → EV(frac) with roundtrip costs, Kelly-shrunk sizing.
- **QA hard-stops**: coverage outside [0.02,0.6] ⇒ run fails (prevents 0건/전건 양극단).
- **Diagnostics**: EV decile monotonicity in log, rich run.log.

## Run
python trade4v/run_4u.py --data data/ETHUSDT_1min_2025H1.csv   --train_start "2025-01-01 00:00:00" --train_end "2025-04-30 23:59:00"   --test_start  "2025-05-01 00:00:00" --test_end  "2025-06-30 23:59:00"    --H 15 --fee_bps 1.0 --slip_bps 0.5 --K_day "0:5,1:10,2:20" --out_dir _out_4u

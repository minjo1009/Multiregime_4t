
# trade4v S1/S2 (v3.1e) — Robust coverage
- 게이팅 전 cand를 EV로 미리 거르지 않음 → EV 플로어 완화가 실제로 작동
- 커버리지 낮으면 자동으로 **EV 플로어 무시 Top-K**로 리커버
- pandas 2.2 안전: groupby.apply(include_groups=False) 대응

Args:
--min_cov 0.02 --max_cov 0.6  # QA 바운드

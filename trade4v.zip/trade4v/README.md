
# trade4v — Regime-Only v1.2 (Efficient Isotonic)

- Keeps **Isotonic calibration** but makes it efficient:
  - Single RF fit (global) by default; optional per-regime models.
  - **Time holdout (`--cal_frac`)** for calibration instead of CV.
  - **Quantile-binned Isotonic** with sample weights (`--cal_bins`) to compress calibration set.
- Warning cleanup: `.ffill().bfill()` instead of deprecated `fillna(method=...)`.

## Quick start (GitHub Actions)
1) Upload this ZIP as `trade4v.zip` to your repo root.
2) Create `.github/workflows/trade4v-run.yml` with the content provided in this package or the downloaded `trade4v-run.yml` file.
3) Upload your ETH minute data as a ZIP (e.g., `ETHUSDT_1min_2020_2025.zip`).

## CLI flags
- `--max_train_rows 200000` : guard for GH Actions runner
- `--cal_frac 0.2`          : last 20% of train for calibration
- `--cal_bins 50`           : quantile bins for isotonic compression
- `--use_regime_models`     : train RF per regime (slower; optional)

Outputs: `_out_4u/{preds_test.parquet, metrics_oos.json, config.json, theta_table.json}`

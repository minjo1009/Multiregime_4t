
# trade4v — v1.4 (3-Regime + Per-Regime Goals + Vol Targeting)

Defaults aligned to project decisions:
- **3 Regimes** by realized-vol z-score: Low / Med / High (z_low=1.0, z_high=1.8)
- **Per-regime trade ranges**: Low 400–900, Med 300–600, High 150–400
- **H=7**, **cal_bins=100**, **cal_frac=0.3**, **deoverlap=ON**
- **Vol Targeting**: size weight w ~ 1/vol20 (clipped [0.3,1.0]); fees scaled by w
- **Isotonic (holdout + quantile bins)** for calibration
- Goal string supports per-regime specification: `pnl,low:400-900,med:300-600,high:150-400`

Artifacts: `_out_4u/{preds_test.parquet, metrics_oos.json, config.json, theta_table.json}`

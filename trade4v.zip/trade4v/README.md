
# trade4v (S1/S2 v3.1c — floor relaxation + pandas-safe)
- Top-K per (day, regime) with EV floor relaxation down to `ev_floor_min_bps`.
- Pandas groupby.apply uses include_groups=False when available, fallback otherwise.
- QA: coverage bounds enforced; run.log has coverage/trades/floor used.

## Example
python trade4v/run_4u.py --data data/ETHUSDT_1min_2025H1.csv   --train_start "2025-01-01 00:00:00" --train_end "2025-04-30 23:59:00"   --test_start  "2025-05-01 00:00:00" --test_end  "2025-06-30 23:59:00"   --H 15 --fee_bps 1.0 --slip_bps 0.5   --K_day "0:5,1:10,2:20" --ev_margin_bps 1.0 --ev_floor_min_bps 0.0 --ev_relax_factor 0.5   --out_dir _out_4u


# trade4v — Regime-Only v1.0 (Signal Layer)

이 패키지는 레짐 인식 기반의 확률/커버리지 제어 신호 레이어입니다. 엔트리/청산은 별도 레이어로 이후 결합합니다.

## 빠른 실행 (로컬)
```bash
pip install -r requirements.txt

# 1) 스모크 테스트(합성 데이터로 문법/파이프라인 점검)
python tools/smoke_test.py

# 2) 실데이터 실행 예시
python run_4u.py   --data data/BTC_USDT_1m_norm_kst.csv   --train_start 2025-01-01 --train_end 2025-04-30   --test_start  2025-05-01 --test_end  2025-06-30   --H 5 --fee_bps 10   --vol_window 64 --z_thr 1.5   --cov_min 0.10 --cov_max 0.30   --out_dir _out_4u/RegimeOnly_v1
```

## 산출물
- `preds_test.parquet` — time, regime_id, p_long, theta, coverage_flag, label
- `metrics_oos.json` — MCC, coverage, hit_rate, trades, ece, brier, pnl, by_regime
- `config.json`, `theta_table.json`

## 게이트(합격 기준)
- MCC ≥ 0.70
- Coverage 10–30%
- ECE ≤ 0.05
- Trades 수 충분(데이터 의존)

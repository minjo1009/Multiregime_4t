
# trade4v — Regime-Only v1.3 (PnL-Objective)

- Keeps efficient **Isotonic** (time-holdout + quantile bins) and **regime tagging**.
- New: **PnL-optimized threshold** search with **monthly trades constraint**.
  - `--goal "pnl,<N_min_per_month>"` e.g., `--goal "pnl,400"`
  - Cal set: compute H-step future log returns → PnL(θ) = Σ(future) - fee*trades.
  - Estimate trades/month ≈ trades_in_cal / bars_in_cal * bars_per_month.
  - Per-regime θ with N_min scaled by regime occupancy.

Outputs: `_out_4u/{preds_test.parquet, metrics_oos.json, config.json, theta_table.json}`

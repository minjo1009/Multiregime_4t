
trade4v v3.3
- S1: session×regime calibration for p_long
- S2: H-range quantile TP/SL (asymmetric) + dynamic session cost
- Gating: spacing-greedy Top-K with overlap control (cap/pyramid)
- QA: warns by default (no hard fail); always writes preds/metrics

CLI example:
python trade4v/run_4u.py --data data/ETHUSDT_1min_2025H1.csv   --train_start "2025-01-01 00:00:00" --train_end "2025-04-30 23:59:00"   --test_start "2025-05-01 00:00:00" --test_end "2025-06-30 23:59:00"   --H 15 --fee_bps 1.0 --slip_bps 0.3   --K_day "0:10,1:15,2:30" --overlap_mode cap --max_concurrent 2 --min_gap_bars 5   --q_tp 0.9 --q_sl 0.6 --out_dir _out_4u

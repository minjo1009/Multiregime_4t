# Trade4V Full Pack (Patched)
- Entry: `trade4v/run_4u.py`
- Modules: `trend4p/*` (data/features/regimes/labels/ev_model/sizing/selector_4u/execution_4u/backtest/utils)
- Guarantees:
  - Pandas index reset + `.iloc` for integer position slicing.
  - CLI compatible with existing YAML.
  - Outputs: `_out_4u/run/preds_test.csv`, `_out_4u/run/metrics_oos.json`.


# trade4v (S1/S2 updated pack v2)
- S1: 동적 θ Top-K(일·레짐), EV 플로어, 겹침 방지, QA 가드
- S2: EV(수익률 단위) + 켈리 축소 사이징, 확률 캘리브레이션

## Run
python trade4v/run_4u.py --data data/ETHUSDT_1min_2025H1.csv   --train_start "2025-01-01 00:00:00" --train_end "2025-04-30 23:59:00"   --test_start "2025-05-01 00:00:00"  --test_end  "2025-06-30 23:59:00"    --H 15 --fee_bps 1.0 --slip_bps 0.5 --K_day "0:5,1:10,2:20" --out_dir _out_4u

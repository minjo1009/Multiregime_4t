
# trade4v — v1.3.3 (PnL Objective + Range, Non-Overlap, No bfill)

- **No-leak features**: `.ffill().fillna(0)` ONLY (no `.bfill()`).
- **PnL objective with monthly trades range**: `goal="pnl,400-1200"`
- **Non-overlap execution**: trades are spaced by `H` bars both
  in calibration objective and in test PnL, avoiding double counting.
- **Isotonic (holdout + quantile bins)** remains for probability calibration.

Outputs: `_out_4u/{preds_test.parquet, metrics_oos.json, config.json, theta_table.json}`.

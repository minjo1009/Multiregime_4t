
import numpy as np
from sklearn.ensemble import GradientBoostingRegressor

class EVRegressorPerRegime:
    def __init__(self, alpha_hi=0.9, params_base=None):
        self.alpha_hi = float(alpha_hi)
        self.params_base = params_base or dict(n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=42)
        self.models_q50 = {}
        self.models_qhi = {}

    def fit(self, X, y, regime):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        regime = np.asarray(regime, dtype=int)
        for rid in np.unique(regime):
            m = (regime == rid)
            if m.sum() < 500:
                continue
            m50 = GradientBoostingRegressor(loss="quantile", alpha=0.5, **self.params_base)
            mhi = GradientBoostingRegressor(loss="quantile", alpha=self.alpha_hi, **self.params_base)
            m50.fit(X[m], y[m])
            mhi.fit(X[m], y[m])
            self.models_q50[int(rid)] = m50
            self.models_qhi[int(rid)] = mhi
        return self

    def predict(self, X, regime):
        X = np.asarray(X, dtype=float)
        regime = np.asarray(regime, dtype=int)
        n = len(X)
        ev50 = np.zeros(n, dtype=float)
        evhi = np.zeros(n, dtype=float)
        for rid in np.unique(regime):
            m = (regime == rid)
            if not np.any(m):
                continue
            m50 = self.models_q50.get(int(rid))
            mhi = self.models_qhi.get(int(rid))
            if m50 is None or mhi is None:
                ev50[m] = 0.0
                evhi[m] = 0.0
            else:
                ev50[m] = m50.predict(X[m])
                evhi[m] = mhi.predict(X[m])
        return ev50, evhi

class ExpansionRegressor:
    def __init__(self, params=None):
        self.params = params or dict(n_estimators=200, max_depth=3, learning_rate=0.05, subsample=0.8, random_state=7)
        self.models = {}
        self.median_by_regime = {}

    def fit(self, X, y_bps, regime):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y_bps, dtype=float)
        regime = np.asarray(regime, dtype=int)
        for rid in np.unique(regime):
            m = (regime == rid)
            if m.sum() < 500:
                self.median_by_regime[int(rid)] = float(np.nanmedian(y[m])) if np.any(m) else 1.0
                continue
            model = GradientBoostingRegressor(**self.params)
            model.fit(X[m], y[m])
            self.models[int(rid)] = model
            self.median_by_regime[int(rid)] = float(np.nanmedian(y[m]))
        return self

    def predict_scale(self, X, regime, clip_low=0.7, clip_high=1.8):
        X = np.asarray(X, dtype=float)
        regime = np.asarray(regime, dtype=int)
        n = len(X)
        scale = np.ones(n, dtype=float)
        for rid in np.unique(regime):
            m = (regime == rid)
            if not np.any(m): 
                continue
            model = self.models.get(int(rid))
            med = self.median_by_regime.get(int(rid), 1.0)
            if model is None or med <= 0:
                scale[m] = 1.0
            else:
                pred = model.predict(X[m])
                sc = pred / (med + 1e-8)
                sc = np.clip(sc, clip_low, clip_high)
                scale[m] = sc
        return scale

import numpy as np
import pandas as pd

def ev_from_dir_expansion(dir_sig, expansion, fee_bps=0.0, slip_bps=0.0):
    cost = (fee_bps + slip_bps)/10000.0
    ev = (dir_sig.fillna(0.0) * expansion.fillna(0.0)) - cost
    return ev

def entry_flag_from_thresh(ev, feats, gate_strength=0.0):
    g = feats["mom_fast"].abs().rank(pct=True)
    gate = (g > (1.0 - gate_strength)).astype(int) if gate_strength>0 else 1
    return ((ev > 0) & (gate==1)).astype(int)


import numpy as np

def mcc(y_true, y_pred):
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    tp = ((y_true == 1) & (y_pred == 1)).sum()
    tn = ((y_true == 0) & (y_pred == 0)).sum()
    fp = ((y_true == 0) & (y_pred == 1)).sum()
    fn = ((y_true == 1) & (y_pred == 0)).sum()
    denom = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    return 0.0 if denom == 0 else (tp*tn - fp*fn)/denom

def brier_score(y_true, p):
    y_true = np.asarray(y_true).astype(float)
    p = np.asarray(p).astype(float)
    return float(np.mean((p - y_true)**2))

def ece(y_true, p, n_bins: int = 10):
    y_true = np.asarray(y_true).astype(int)
    p = np.asarray(p).astype(float)
    bins = np.linspace(0, 1, n_bins+1)
    idx = np.digitize(p, bins) - 1
    ece_val, total = 0.0, len(p)
    for b in range(n_bins):
        mask = (idx == b)
        if not np.any(mask):
            continue
        acc = y_true[mask].mean() if mask.sum() else 0.0
        conf = p[mask].mean()
        ece_val += (mask.sum()/total) * abs(acc - conf)
    return float(ece_val)

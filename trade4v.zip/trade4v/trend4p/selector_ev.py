
import numpy as np
import pandas as pd

def parse_k_map(s: str, default=None):
    if (not s) and (default is not None):
        return default
    out = {}
    parts = s.split(",")
    for part in parts:
        part = part.strip()
        if not part: 
            continue
        k,v = part.split(":",1)
        out[int(k)] = int(v)
    return out

def _deoverlap_greedy(idx_sorted, H_seq):
    chosen = []
    blocked_until = -1
    for i in idx_sorted:
        if i <= blocked_until:
            continue
        chosen.append(i)
        h = int(max(1, H_seq[i]))
        blocked_until = max(blocked_until, i + h - 1)
    return np.array(chosen, dtype=int)

def select_topk_daily(ev, time, regime, H_seq, k_map, floor_multipliers, fee_rt):
    ev = np.asarray(ev, dtype=float)
    regime = np.asarray(regime, dtype=int)
    H_seq = np.asarray(H_seq, dtype=int)
    fee_rt = float(fee_rt)
    t = pd.to_datetime(time)
    day = t.dt.floor("D")
    flag = np.zeros(len(ev), dtype=int)
    df = pd.DataFrame({"idx": np.arange(len(ev)), "day": day, "rid": regime, "ev": ev})
    by = df.groupby(["day","rid"], sort=False)
    floors = [float(m) * fee_rt for m in floor_multipliers]
    for (d, rid), grp in by:
        K = int(k_map.get(int(rid), 0))
        if K <= 0 or len(grp)==0:
            continue
        selected = None
        for fl in floors:
            cand = grp[grp["ev"] >= fl].sort_values("ev", ascending=False)["idx"].to_numpy()
            if cand.size == 0:
                continue
            chosen = _deoverlap_greedy(cand, H_seq)
            if chosen.size >= K:
                selected = chosen[:K]
                break
            if selected is None or chosen.size > selected.size:
                selected = chosen
        if selected is None:
            continue
        flag[selected] = 1
    return flag


import numpy as np
import pandas as pd

def make_h_label(df, H: int = 5, ret_col: str = "ret1"):
    r = df[ret_col].to_numpy()
    s = pd.Series(r).rolling(H).sum().shift(-H+1).to_numpy()
    y = (s > 0.0).astype(int)
    y[pd.isna(s)] = 0
    return y

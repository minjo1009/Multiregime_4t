
import numpy as np
import pandas as pd

def make_h_label(df, H: int = 5, ret_col: str = "ret1"):
    r = df[ret_col].to_numpy()
    # 미래 H개 수익의 합(로그수익의 합 ≈ H-step 수익)
    s = pd.Series(r).rolling(H).sum().shift(-H+1).to_numpy()
    # 경계=0.0: 동률은 0(보수적)
    y = (s > 0.0).astype(int)
    # 마지막 H-1개는 라벨이 불가능 → 0으로 두고 사용 시 마스킹
    y[np.isnan(s)] = 0
    return y

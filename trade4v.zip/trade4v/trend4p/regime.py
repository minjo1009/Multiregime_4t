
import numpy as np
import pandas as pd

class RegimeTagger:
    def __init__(self, vol_window: int = 64, z_thr: float = 1.5, min_periods: int = None):
        self.vol_window = int(vol_window)
        self.z_thr = float(z_thr)
        self.min_periods = min_periods or int(vol_window)

    def fit(self, df_feat: pd.DataFrame, return_col: str = "ret1"):
        return self

    def transform(self, df_feat: pd.DataFrame, return_col: str = "ret1") -> pd.Series:
        r = df_feat[return_col].astype(float)
        vol = r.rolling(self.vol_window, min_periods=self.min_periods).std()
        mu = vol.rolling(self.vol_window, min_periods=self.min_periods).mean()
        sig = vol.rolling(self.vol_window, min_periods=self.min_periods).std()
        z = (vol - mu) / (sig.replace(0.0, np.nan))
        regime = (z.abs() >= self.z_thr).astype(int)
        return regime.fillna(0).astype(int).rename("regime_id")

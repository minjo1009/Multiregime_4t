
import numpy as np
import pandas as pd

class RegimeTagger:
    def __init__(self, vol_window: int = 64, z_thr: float = None, z_thr_low: float = 1.0, z_thr_high: float = 2.0, min_periods: int = None):
        self.vol_window = int(vol_window)
        self.z_thr = z_thr
        self.z_thr_low = float(z_thr_low)
        self.z_thr_high = float(z_thr_high)
        self.min_periods = min_periods or int(vol_window)

    def fit(self, df_feat: pd.DataFrame, return_col: str = "ret1"):
        return self

    def transform(self, df_feat: pd.DataFrame, return_col: str = "ret1") -> pd.Series:
        r = df_feat[return_col].astype(float)
        vol = r.rolling(self.vol_window, min_periods=self.min_periods).std()
        mu = vol.rolling(self.vol_window, min_periods=self.min_periods).mean()
        sig = vol.rolling(self.vol_window, min_periods=self.min_periods).std()
        z = (vol - mu) / (sig.replace(0.0, np.nan))
        if self.z_thr is not None:
            regime = (z.abs() >= float(self.z_thr)).astype(int)
        else:
            regime = pd.Series(1, index=z.index, dtype=int)
            regime[z.abs() < self.z_thr_low] = 0
            regime[z.abs() >= self.z_thr_high] = 2
        return regime.fillna(1).astype(int).rename("regime_id")

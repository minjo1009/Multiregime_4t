
import pandas as pd
import numpy as np

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.rename(columns={c: c.strip().lower().replace(" ", "_") for c in df.columns})
    time_cols = [c for c in ["time","open_time","ts","timestamp"] if c in df.columns]
    if not time_cols:
        raise ValueError("CSV must contain a time column: one of ['time','open_time','ts','timestamp']")
    tcol = time_cols[0]
    df = df.rename(columns={tcol: "time"})
    s = df["time"]
    if np.issubdtype(s.dtype, np.number):
        med = float(s.iloc[len(s)//2]); unit = "ms" if med > 1e11 else "s"
        df["time"] = pd.to_datetime(s, unit=unit, utc=True)
    else:
        df["time"] = pd.to_datetime(s, utc=True)
    expected = ["open","high","low","close","volume"]
    for c in expected:
        if c not in df.columns:
            raise ValueError(f"CSV missing required column: {c}")
    keep = ["time","open","high","low","close","volume"]
    for c in ["number_of_trades","taker_buy_base_asset_volume","taker_buy_volume","taker_buy_size"]:
        if c in df.columns: keep.append(c)
    return df[keep].copy().sort_values("time").reset_index(drop=True)


import pandas as pd
import numpy as np

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    # normalize time column
    time_cols = [c for c in ["time","open_time","ts","timestamp"] if c in df.columns]
    if not time_cols:
        raise ValueError("CSV must contain a time column: one of ['time','open_time','ts','timestamp']")
    tcol = time_cols[0]
    df = df.rename(columns={tcol: "time"})
    s = df["time"]
    # robust to epoch/str with/without tz
    if np.issubdtype(s.dtype, np.number):
        med = float(s.iloc[len(s)//2]); unit = "ms" if med > 1e11 else "s"
        df["time"] = pd.to_datetime(s, unit=unit, utc=True)
    else:
        df["time"] = pd.to_datetime(s, utc=True)
    expected = ["open","high","low","close","volume"]
    for c in expected:
        if c not in df.columns:
            raise ValueError(f"CSV missing required column: {c}")
    return df[["time","open","high","low","close","volume"]].copy()

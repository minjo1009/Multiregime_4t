import numpy as np
import pandas as pd

def parse_bar_map(s: str, default=None):
    if (not s) and (default is not None):
        return default
    out = {}
    parts = s.split(";")
    for part in parts:
        part = part.strip()
        if not part: 
            continue
        k, rest = part.split(":",1)
        a,b,c = rest.split(",",2)
        out[int(k)] = (float(a), float(b), int(c))
    return out

def realize_event_returns(df, regime_id, bar_map, fee_bps=10, slip_bps=0):
    close = df["close"].to_numpy(dtype=float)
    high = df["high"].to_numpy(dtype=float)
    low  = df["low"].to_numpy(dtype=float)
    n = len(close)
    regime_id = np.asarray(regime_id, dtype=int)
    gross = np.full(n, np.nan, dtype=float)
    usedH = np.zeros(n, dtype=int)
    tp_rt = {}
    sl_rt = {}
    hmax_by = {}
    for rid, (tp_bps, sl_bps, hmax) in bar_map.items():
        tp_rt[int(rid)] = float(tp_bps)/1e4
        sl_rt[int(rid)] = float(sl_bps)/1e4
        hmax_by[int(rid)] = int(hmax)
    for i in range(n):
        rid = int(regime_id[i])
        H = hmax_by.get(rid, 20)
        tp = tp_rt.get(rid, 0.003)
        sl = sl_rt.get(rid, 0.002)
        base = close[i]
        hit = False
        last_j = min(n-1, i+H)
        for j in range(i+1, last_j+1):
            r_hi = np.log(high[j]/base)
            r_lo = np.log(low[j]/base)
            if r_hi >= tp:
                gross[i] = tp
                usedH[i] = j - i
                hit = True
                break
            if r_lo <= -sl:
                gross[i] = -sl
                usedH[i] = j - i
                hit = True
                break
        if not hit:
            if last_j > i:
                gross[i] = np.log(close[last_j]/base)
                usedH[i] = last_j - i
            else:
                gross[i] = 0.0
                usedH[i] = 1
    fee_rt = 2.0*(float(fee_bps)+float(slip_bps))/1e4
    net = gross - fee_rt
    return gross, net, usedH

def compute_future_range_bps(df, regime_id, bar_map):
    close = df["close"].to_numpy(dtype=float)
    high = df["high"].to_numpy(dtype=float)
    low  = df["low"].to_numpy(dtype=float)
    n = len(close)
    regime_id = np.asarray(regime_id, dtype=int)
    out = np.zeros(n, dtype=float)
    hmax_by = {int(rid): int(h) for rid,(_,_,h) in bar_map.items()}
    for i in range(n):
        rid = int(regime_id[i])
        H = int(hmax_by.get(rid, 20))
        last_j = min(n-1, i+H)
        base = close[i]
        if last_j <= i:
            out[i] = 0.0; continue
        r_hi = np.log(high[i+1:last_j+1] / base)
        r_lo = np.log(low[i+1:last_j+1] / base)
        rng = float(np.nanmax(r_hi) - np.nanmin(r_lo))
        out[i] = 1e4 * max(rng, 0.0)
    return out

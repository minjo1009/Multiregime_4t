
import numpy as np
from sklearn.ensemble import RandomForestClassifier

class RegimeProbModel:
    def __init__(self, base_kwargs=None, use_regime_models=False, min_samples_per_regime=50000):
        self.base_kwargs = base_kwargs or dict(n_estimators=200, max_depth=None, random_state=42, n_jobs=2)
        self.use_regime_models = bool(use_regime_models)
        self.min_samples = int(min_samples_per_regime)
        self.global_model = None
        self.regime_models = {}

    def fit(self, X, y, regime_id=None):
        X, y = np.asarray(X), np.asarray(y).astype(int)
        if regime_id is None:
            regime_id = np.zeros(len(y), dtype=int)
        regime_id = np.asarray(regime_id).astype(int)

        self.global_model = RandomForestClassifier(**self.base_kwargs).fit(X, y)
        self.regime_models = {}
        if self.use_regime_models:
            for rid in np.unique(regime_id):
                mask = (regime_id == rid)
                if mask.sum() < self.min_samples:
                    continue
                self.regime_models[rid] = RandomForestClassifier(**self.base_kwargs).fit(X[mask], y[mask])
        return self

    def predict_proba(self, X, regime_id=None):
        X = np.asarray(X)
        if regime_id is None:
            regime_id = np.zeros(len(X), dtype=int)
        regime_id = np.asarray(regime_id).astype(int)
        p = np.zeros(len(X), dtype=float)
        for rid in np.unique(regime_id):
            mask = (regime_id == rid)
            if not np.any(mask):
                continue
            model = self.regime_models.get(rid, self.global_model)
            p[mask] = model.predict_proba(X[mask])[:, 1]
        return p


import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV

class RegimeProbModel:
    """글로벌 + 레짐별 서브모델 (이소토닉 캘리브레이션)."""
    def __init__(self, base_kwargs=None, calib_method="isotonic", calib_cv=3, min_samples_per_regime=500):
        self.base_kwargs = base_kwargs or dict(n_estimators=300, max_depth=None, random_state=42, n_jobs=-1)
        self.calib_method = calib_method
        self.calib_cv = calib_cv
        self.min_samples = int(min_samples_per_regime)
        self.global_model = None
        self.regime_models = {}

    def _new_model(self):
        base = RandomForestClassifier(**self.base_kwargs)
        return CalibratedClassifierCV(base, method=self.calib_method, cv=self.calib_cv)

    def fit(self, X, y, regime_id=None):
        X, y = np.asarray(X), np.asarray(y).astype(int)
        if regime_id is None:
            regime_id = np.zeros(len(y), dtype=int)
        regime_id = np.asarray(regime_id).astype(int)
        self.global_model = self._new_model().fit(X, y)
        self.regime_models = {}
        for rid in np.unique(regime_id):
            mask = (regime_id == rid)
            if mask.sum() < self.min_samples:
                continue
            self.regime_models[rid] = self._new_model().fit(X[mask], y[mask])
        return self

    def predict_proba(self, X, regime_id=None):
        X = np.asarray(X)
        if regime_id is None:
            regime_id = np.zeros(len(X), dtype=int)
        regime_id = np.asarray(regime_id).astype(int)
        p = np.zeros(len(X), dtype=float)
        for rid in np.unique(regime_id):
            mask = (regime_id == rid)
            if not np.any(mask):
                continue
            model = self.regime_models.get(rid, self.global_model)
            p[mask] = model.predict_proba(X[mask])[:, 1]
        return p

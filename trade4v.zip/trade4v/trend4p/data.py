import pandas as pd
from .utils import ensure_sorted_reset

TIME_CANDS = ["time","open_time","timestamp","date"]
PRICE_CANDS = ["close","price","Close","ClosePrice","px"]
VOL_CANDS = ["volume","QuoteVolume","quote_volume","vol"]

def _find_col(cols, cands):
    low = {c.lower(): c for c in cols}
    for c in cands:
        if c.lower() in low:
            return low[c.lower()]
    return None

def load_csv(path):
    df = pd.read_csv(path)
    tcol = _find_col(df.columns, TIME_CANDS)
    pcol = _find_col(df.columns, PRICE_CANDS)
    if tcol is None: raise ValueError(f"time-like column not found in {TIME_CANDS}")
    if pcol is None: raise ValueError(f"price-like column not found in {PRICE_CANDS}")
    df["time"] = pd.to_datetime(df[tcol], utc=True, errors="coerce")
    df["price"] = pd.to_numeric(df[pcol], errors="coerce")
    if (df["time"].isna() | df["price"].isna()).any():
        df = df.dropna(subset=["time","price"])
    vcol = _find_col(df.columns, VOL_CANDS)
    if vcol:
        df["volume"] = pd.to_numeric(df[vcol], errors="coerce").fillna(0.0)
    else:
        df["volume"] = 0.0
    df = ensure_sorted_reset(df, "time")
    return df[["time","price","volume"]].copy()

import numpy as np
import pandas as pd

def future_return(df, H):
    fut = df["price"].shift(-H)
    return (fut/df["price"] - 1.0)

def triple_barrier_like(df, H, tp_mult=1.0, sl_mult=1.0):
    f = future_return(df, H)
    lab = np.sign(f).fillna(0.0).astype(int)
    return lab, f

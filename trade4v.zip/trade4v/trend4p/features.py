import numpy as np
import pandas as pd

def compute_basic_features(df):
    px = df["price"]
    ret1 = px.pct_change()
    mom_fast = px.pct_change(20)
    mom_slow = px.pct_change(60)
    vol_fast = ret1.rolling(20).std()
    vol_slow = ret1.rolling(120).std()
    ofi = ret1.fillna(0.0) * df.get("volume", 0.0).fillna(0.0)
    feats = pd.DataFrame({
        "ret1": ret1,
        "mom_fast": mom_fast,
        "mom_slow": mom_slow,
        "vol_fast": vol_fast,
        "vol_slow": vol_slow,
        "ofi": ofi,
    }, index=df.index)
    return feats

def dir_signal(feats):
    score = feats["mom_fast"].fillna(0.0) + 0.5*feats["mom_slow"].fillna(0.0)
    return np.sign(score).fillna(0.0)

def expansion_proxy(feats):
    v = feats["vol_fast"].fillna(0.0)
    return v.clip(lower=0.0).fillna(0.0)

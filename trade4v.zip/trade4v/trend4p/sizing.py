import numpy as np
import pandas as pd

def kelly_like(ev, var_floor=1e-6, cap=1.0):
    var = (ev.rolling(50).std()**2).fillna(0.0).clip(lower=var_floor)
    f = (ev.abs() / var).clip(upper=cap).fillna(0.0)
    return f

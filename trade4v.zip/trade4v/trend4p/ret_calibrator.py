
import numpy as np
from sklearn.isotonic import IsotonicRegression

class IsoReturnPerRegime:
    def __init__(self, n_bins: int = 50):
        self.n_bins = int(n_bins)
        self.models = {}  # rid -> (iso, x_min, x_max)

    @staticmethod
    def _compress_bins(p, future, n_bins=50):
        p = np.asarray(p, dtype=float)
        y = np.asarray(future, dtype=float)
        mfin = np.isfinite(p) & np.isfinite(y)
        p, y = p[mfin], y[mfin]
        qs = np.linspace(0, 1, n_bins+1)
        edges = np.unique(np.quantile(p, qs))
        idx = np.searchsorted(edges, p, side="right") - 1
        idx = np.clip(idx, 0, len(edges)-2)
        K = len(edges) - 1
        sums_y = np.zeros(K, dtype=float)
        sums_p = np.zeros(K, dtype=float)
        counts  = np.zeros(K, dtype=float)
        for i in range(K):
            mask = (idx == i)
            if not np.any(mask):
                continue
            counts[i]  = mask.sum()
            sums_y[i]  = np.nanmean(y[mask])
            sums_p[i]  = np.nanmean(p[mask])
        m = counts > 0
        return sums_p[m], sums_y[m], counts[m]

    def fit(self, p, future, regime=None):
        if regime is None:
            regime = np.zeros_like(p, dtype=int)
        regime = np.asarray(regime).astype(int)
        for rid in np.unique(regime):
            m = (regime == rid)
            x, ybar, w = self._compress_bins(p[m], future[m], self.n_bins)
            if len(x) < 2:
                iso = None
                self.models[int(rid)] = (iso, 0.0, 1.0)
            else:
                order = np.argsort(x)
                x, ybar, w = x[order], ybar[order], w[order]
                iso = IsotonicRegression(out_of_bounds="clip")
                iso.fit(x, ybar, sample_weight=w)
                self.models[int(rid)] = (iso, float(x.min()), float(x.max()))
        return self

    def transform(self, p, regime=None):
        if regime is None:
            regime = np.zeros_like(p, dtype=int)
        regime = np.asarray(regime).astype(int)
        p = np.asarray(p, dtype=float)
        out = np.zeros_like(p, dtype=float)
        for rid in np.unique(regime):
            m = (regime == rid)
            iso, xmin, xmax = self.models.get(int(rid), (None, 0.0, 1.0))
            if iso is None:
                out[m] = 0.0
            else:
                out[m] = iso.predict(np.clip(p[m], xmin, xmax))
        return out

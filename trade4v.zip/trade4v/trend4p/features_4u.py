
import numpy as np
import pandas as pd

def _ema(s: pd.Series, span: int):
    return s.ewm(span=span, adjust=False).mean()

def _atr(df: pd.DataFrame, n: int = 14):
    h, l, c = df["high"], df["low"], df["close"]
    prev_c = c.shift(1)
    tr = (h - l).abs().combine((h - prev_c).abs(), np.maximum).combine((l - prev_c).abs(), np.maximum)
    return tr.rolling(n, min_periods=max(3, n//2)).mean()

def _bb_width(c: pd.Series, n: int = 20, k: float = 2.0):
    ma = c.rolling(n, min_periods=max(3, n//2)).mean()
    sd = c.rolling(n, min_periods=max(3, n//2)).std()
    upper, lower = ma + k*sd, ma - k*sd
    width = (upper - lower)/(ma.replace(0, np.nan))
    return width

def _keltner(df: pd.DataFrame, n: int = 20, k: float = 1.5):
    ema = _ema(df["close"], n)
    atr = _atr(df, n)
    upper, lower = ema + k*atr, ema - k*atr
    width = (upper - lower)/(ema.replace(0, np.nan))
    return width

def _rsi(close: pd.Series, period: int = 14):
    delta = close.diff()
    up = (delta.clip(lower=0)).ewm(alpha=1/period, adjust=False).mean()
    down = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = up / (down.replace(0.0, np.nan))
    rsi = 100 - (100 / (1 + rs))
    return rsi

def _kama_slope(c: pd.Series, n: int = 10):
    ema_fast = c.ewm(span=max(2, n//2), adjust=False).mean()
    ema_slow = c.ewm(span=n*3, adjust=False).mean()
    return (ema_fast/ema_slow - 1.0)

def _clv(df: pd.DataFrame):
    h,l,c = df["high"], df["low"], df["close"]
    denom = (h - l).replace(0.0, np.nan)
    clv = ((c - l) - (h - c)) / denom
    return clv.fillna(0.0)

def make_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ret1"] = np.log(out["close"]).diff()
    out["ema12"] = _ema(out["close"], 12)
    out["ema48"] = _ema(out["close"], 48)
    out["ema_spread"] = out["ema12"] / (out["ema48"] + 1e-12) - 1.0
    out["vol20"] = out["ret1"].rolling(20, min_periods=5).std()
    out["rsi14"] = _rsi(out["close"], 14)
    out["atr14"] = _atr(out, 14)
    out["bb_w20"] = _bb_width(out["close"], 20, 2.0)
    out["kel_w20"] = _keltner(out, 20, 1.5)
    out["kama10"] = _kama_slope(out["close"], 10)
    out["clv"] = _clv(out)
    out["ret3"] = out["ret1"].rolling(3, min_periods=2).sum()
    out["ret5"] = out["ret1"].rolling(5, min_periods=3).sum()
    out["vol60"] = out["ret1"].rolling(60, min_periods=20).std()
    for c in out.columns:
        if c not in ["time","open","high","low","close","volume"]:
            s = out[c].astype(float)
            s = s.replace([np.inf, -np.inf], np.nan).ffill().fillna(0.0)
            out[c] = s
    out["ret1"] = out["ret1"].fillna(0.0)
    out["rsi14"] = out["rsi14"].fillna(50.0)
    return out

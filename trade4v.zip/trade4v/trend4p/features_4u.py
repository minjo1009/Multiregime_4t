
import numpy as np
import pandas as pd

def _ema(arr: pd.Series, span: int):
    return arr.ewm(span=span, adjust=False).mean()

def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    up = (delta.clip(lower=0)).ewm(alpha=1/period, adjust=False).mean()
    down = (-delta.clip(upper=0)).ewm(alpha=1/period, adjust=False).mean()
    rs = up / (down.replace(0.0, np.nan))
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)

def make_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ret1"] = np.log(out["close"]).diff().fillna(0.0)
    out["ema12"] = _ema(out["close"], 12)
    out["ema48"] = _ema(out["close"], 48)
    out["ema_spread"] = out["ema12"] / (out["ema48"] + 1e-12) - 1.0
    out["vol20"] = out["ret1"].rolling(20, min_periods=5).std().fillna(0.0)
    out["rsi14"] = _rsi(out["close"], 14)
    # replace inf/nan
    for c in out.columns:
        if c not in ["time","open","high","low","close","volume"]:
            s = out[c].astype(float)
            s = s.replace([np.inf, -np.inf], np.nan).fillna(method="ffill").fillna(method="bfill").fillna(0.0)
            out[c] = s
    return out

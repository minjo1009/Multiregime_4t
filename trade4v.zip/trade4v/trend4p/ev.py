
import numpy as np
def bps_to_frac(bps): 
    return np.asarray(bps, dtype=float) / 10000.0

def ev_long(p, tp_frac, sl_frac, cost_bps=0.0, roundtrip=True):
    cost = bps_to_frac(cost_bps)
    if roundtrip: cost = cost * 2.0
    p  = np.asarray(p,  dtype=float)
    tp = np.asarray(tp_frac, dtype=float)
    sl = np.asarray(sl_frac, dtype=float)
    # broadcast all
    return p*tp - (1.0-p)*sl - cost

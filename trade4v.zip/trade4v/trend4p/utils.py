import numpy as np
import pandas as pd

def ensure_sorted_reset(df, time_col="time"):
    if time_col not in df.columns:
        raise ValueError(f"'{time_col}' not in dataframe")
    df = df.sort_values(time_col).reset_index(drop=True)
    return df

def to_utc(ts):
    t = pd.Timestamp(ts)
    if t.tzinfo is None:
        return t.tz_localize("UTC")
    return t.tz_convert("UTC")

def take_iloc(obj, idx):
    idx = np.asarray(idx)
    if idx.dtype == bool or idx.dtype == np.bool_:
        return obj[idx]
    if np.issubdtype(idx.dtype, np.integer):
        return obj.iloc[idx]
    return obj.loc[idx]

def rolling_z(x, win):
    s = pd.Series(x)
    m = s.rolling(win).mean()
    v = s.rolling(win).std()
    return (s - m) / (v.replace(0, np.nan))

def mcc_from_labels(y_true, y_pred):
    y_true = np.asarray(y_true).astype(int)
    y_pred = np.asarray(y_pred).astype(int)
    mask = y_pred != 0
    if mask.sum() == 0:
        return 0.0, 0.0, 0.0
    y_true = y_true[mask]; y_pred = y_pred[mask]
    tp = ((y_pred== 1) & (y_true== 1)).sum()
    tn = ((y_pred==-1) & (y_true==-1)).sum()
    fp = ((y_pred== 1) & (y_true==-1)).sum()
    fn = ((y_pred==-1) & (y_true== 1)).sum()
    num = (tp*tn - fp*fn)
    den = float(np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) or 1.0)
    acc = float(tp+tn) / float(tp+tn+fp+fn)
    cov = float(mask.mean())
    mcc = float(num/den) if den>0 else 0.0
    return mcc, acc, cov

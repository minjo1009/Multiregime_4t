
import numpy as np
from .metrics import mcc

def _best_theta_for_dist(p, y, cov_min, cov_max, grid=None):
    p = np.asarray(p).astype(float)
    y = np.asarray(y).astype(int)
    if grid is None:
        qs = np.linspace(0.50, 0.99, 50)
        grid = np.unique(np.quantile(p, qs))
    best = dict(theta=None, coverage=0.0, mcc=-1.0)
    for th in grid:
        flag = (p >= th).astype(int)
        cov = flag.mean()
        if cov < cov_min or cov > cov_max:
            continue
        score = mcc(y, flag)
        if score > best["mcc"]:
            best.update(theta=float(th), coverage=float(cov), mcc=float(score))
    if best["theta"] is None:
        diffs = []
        for th in grid:
            cov = (p >= th).mean()
            diffs.append((abs(cov - np.clip(cov, cov_min, cov_max)), th, cov))
        diffs.sort(key=lambda x: x[0])
        _, th, cov = diffs[0]
        best.update(theta=float(th), coverage=float(cov), mcc=mcc(y, (p >= th).astype(int)))
    return best

def search_theta_mcc_coverage(p, y, regime=None, cov_min=0.10, cov_max=0.30):
    p, y = np.asarray(p), np.asarray(y).astype(int)
    if regime is None:
        b = _best_theta_for_dist(p, y, cov_min, cov_max)
        return {"global": b}
    result = {}
    regime = np.asarray(regime).astype(int)
    for rid in np.unique(regime):
        mask = (regime == rid)
        result[int(rid)] = _best_theta_for_dist(p[mask], y[mask], cov_min, cov_max)
    return result

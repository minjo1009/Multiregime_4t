import numpy as np
import pandas as pd
from .utils import take_iloc

def _estimate_bars_per_month(times):
    t = pd.to_datetime(times, utc=True)
    dt = (t.view("int64").astype("float64").diff() / 1e9)
    med = float(np.nanmedian(dt)) if np.isfinite(dt).any() else 60.0
    bars_per_day = int(round(86400.0 / max(med, 1.0)))
    return bars_per_day * 30

def topk_per_day(df, k, time_col="time", score_col="ev_final"):
    if k <= 0: return df.index.values
    t = pd.to_datetime(df[time_col], utc=True)
    key = t.dt.strftime("%Y-%m-%d")
    order = np.argsort(-df[score_col].values)
    keep, used = [], {}
    for i in order:
        d = key.iloc[int(i)]
        used.setdefault(d, 0)
        if used[d] < k:
            keep.append(int(i)); used[d] += 1
    keep = np.array(sorted(keep))
    return keep

def search_theta_for_pnl(ev, realized, times):
    ev = np.asarray(ev); realized = np.asarray(realized)
    best_pnl = -1e18; best_theta = 0.0
    for q in np.linspace(0.0, 1.0, 101):
        thr = float(np.quantile(ev, q))
        pnl = float(np.nansum(realized[ev >= thr]))
        if pnl > best_pnl:
            best_pnl, best_theta = pnl, thr
    return best_theta, best_pnl

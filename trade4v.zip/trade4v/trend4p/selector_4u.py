
import numpy as np
import pandas as pd
from .metrics import mcc

def _best_theta_for_dist(p, y, cov_min, cov_max, grid=None):
    p = np.asarray(p).astype(float)
    y = np.asarray(y).astype(int)
    if grid is None:
        qs = np.linspace(0.50, 0.99, 50)
        grid = np.unique(np.quantile(p[np.isfinite(p)], qs))
    best = dict(theta=None, coverage=0.0, mcc=-1.0)
    for th in grid:
        flag = (p >= th).astype(int)
        cov = flag.mean()
        if cov < cov_min or cov > cov_max:
            continue
        score = mcc(y, flag)
        if score > best["mcc"]:
            best.update(theta=float(th), coverage=float(cov), mcc=float(score))
    if best["theta"] is None:
        diffs = []
        for th in grid:
            cov = (p >= th).mean()
            diffs.append((abs(cov - np.clip(cov, cov_min, cov_max)), th, cov))
        diffs.sort(key=lambda x: x[0])
        _, th, cov = diffs[0]
        best.update(theta=float(th), coverage=float(cov), mcc=mcc(y, (p >= th).astype(int)))
    return best

def search_theta_mcc_coverage(p, y, regime=None, cov_min=0.10, cov_max=0.30):
    p, y = np.asarray(p), np.asarray(y).astype(int)
    if regime is None:
        b = _best_theta_for_dist(p, y, cov_min, cov_max)
        return {"global": b}
    result = {}
    regime = np.asarray(regime).astype(int)
    for rid in np.unique(regime):
        mask = (regime == rid)
        result[int(rid)] = _best_theta_for_dist(p[mask], y[mask], cov_min, cov_max)
    return result

def _estimate_bars_per_month(times):
    t64 = pd.to_datetime(times, utc=True).to_numpy(dtype='datetime64[s]')
    if t64.size < 3:
        return 43200.0
    dt = (t64[1:] - t64[:-1]) / np.timedelta64(1, 's')
    dt = dt.astype(float)
    dt = dt[np.isfinite(dt) & (dt > 0)]
    med = np.median(dt) if dt.size else 60.0
    if not np.isfinite(med) or med <= 0:
        med = 60.0
    return 30*24*3600.0 / med

def _deoverlap(flag, H):
    f = flag.astype(bool)
    allow = np.ones_like(f, dtype=bool)
    out = np.zeros_like(f, dtype=bool)
    for i, x in enumerate(f):
        if x and allow[i]:
            out[i] = True
            if H > 1:
                allow[i+1:i+H] = False
    return out.astype(int)

def _pnl_for_theta(p, future, fee_bps, th, H=5, use_deoverlap=True):
    flag = (p >= th).astype(int)
    if use_deoverlap:
        flag = _deoverlap(flag, H)
    fee = (fee_bps * 2 / 1e4)  # round-trip
    pnl = float(np.nansum(future * flag) - fee * flag.sum())
    trades = int(flag.sum())
    return pnl, trades

def search_theta_for_pnl(p, future, times, fee_bps, regime=None,
                         nmin_month=400, nmax_month=None, grid=None, H:int=5, use_deoverlap:bool=True,
                         nmin_map=None, nmax_map=None):
    p = np.asarray(p).astype(float)
    future = np.asarray(future).astype(float)
    if grid is None:
        qs = np.linspace(0.50, 0.999, 80)
        grid = np.unique(np.quantile(p[np.isfinite(p)], qs))
    bars_pm = _estimate_bars_per_month(times)
    result = {}
    if regime is None:
        regime = np.zeros(len(p), dtype=int)
    regime = np.asarray(regime).astype(int)
    uniq, counts = np.unique(regime, return_counts=True)
    total = counts.sum()
    nmin_by = {rid: int(np.ceil(nmin_month * (cnt/total))) for rid, cnt in zip(uniq, counts)}
    nmax_by = {rid: (int(np.floor(nmax_month * (cnt/total))) if nmax_month else None) for rid, cnt in zip(uniq, counts)}
    if nmin_map:
        for rid, v in nmin_map.items(): nmin_by[int(rid)] = int(v)
    if nmax_map:
        for rid, v in nmax_map.items(): nmax_by[int(rid)] = (int(v) if v not in (None,0) else None)

    for rid in uniq:
        m = (regime == rid)
        if m.sum() < 10:
            result[int(rid)] = dict(theta=0.9999, trades_month=0, pnl=0.0)
            continue
        best = dict(theta=None, trades_month=0.0, pnl=-1e18)
        best_relax = dict(theta=None, trades_month=0.0, pnl=-1e18)
        bars = float(m.sum())
        for th in grid:
            pnl, trades = _pnl_for_theta(p[m], future[m], fee_bps, th, H=H, use_deoverlap=use_deoverlap)
            trades_month = trades / bars * bars_pm if bars>0 else 0.0
            cand = dict(theta=float(th), trades_month=float(trades_month), pnl=float(pnl))
            lower_ok = trades_month >= nmin_by.get(int(rid), nmin_month)
            upper = nmax_by.get(int(rid), None)
            upper_ok = True if upper is None else trades_month <= upper
            if lower_ok and upper_ok:
                if cand["pnl"] > best["pnl"]:
                    best = cand
            else:
                if cand["pnl"] > best_relax["pnl"]:
                    best_relax = cand
        result[int(rid)] = best if best["theta"] is not None else best_relax
    return result

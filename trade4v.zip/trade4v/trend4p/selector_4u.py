
import numpy as np
from .metrics import mcc

def _best_theta_for_dist(p, y, cov_min, cov_max, grid=None):
    p = np.asarray(p).astype(float)
    y = np.asarray(y).astype(int)
    if grid is None:
        qs = np.linspace(0.50, 0.99, 50)
        grid = np.unique(np.quantile(p, qs))
    best = dict(theta=None, coverage=0.0, mcc=-1.0)
    for th in grid:
        flag = (p >= th).astype(int)
        cov = flag.mean()
        if cov < cov_min or cov > cov_max:
            continue
        score = mcc(y, flag)
        if score > best["mcc"]:
            best.update(theta=float(th), coverage=float(cov), mcc=float(score))
    if best["theta"] is None:
        diffs = []
        for th in grid:
            cov = (p >= th).mean()
            diffs.append((abs(cov - np.clip(cov, cov_min, cov_max)), th, cov))
        diffs.sort(key=lambda x: x[0])
        _, th, cov = diffs[0]
        best.update(theta=float(th), coverage=float(cov), mcc=mcc(y, (p >= th).astype(int)))
    return best

def _estimate_bars_per_month(times):
    if len(times) < 3:
        return 43200.0
    dt = np.diff(times.view('int64')) / 1e9  # seconds
    med = np.median(dt) if len(dt) else 60.0
    if med <= 0: med = 60.0
    return 30*24*3600.0 / med

def _pnl_for_theta(p, future, fee_bps, th):
    flag = (p >= th).astype(int)
    fee = (fee_bps * 2 / 1e4)  # round-trip
    pnl = float(np.nansum(future * flag) - fee * flag.sum())
    trades = int(flag.sum())
    return pnl, trades

def search_theta_for_pnl(p, future, times, fee_bps, regime=None, nmin_month:int=400, grid=None):
    """Maximize PnL subject to estimated trades per month >= nmin_month.
    If impossible, pick theta with highest PnL (closest to constraint).

    Returns: dict[rid] = {theta, trades_month, pnl}
    """
    p = np.asarray(p).astype(float)
    future = np.asarray(future).astype(float)
    times = np.asarray(times)
    if grid is None:
        qs = np.linspace(0.50, 0.999, 80)
        grid = np.unique(np.quantile(p[np.isfinite(p)], qs))
    bars_pm = _estimate_bars_per_month(times)
    result = {}
    if regime is None:
        regime = np.zeros(len(p), dtype=int)
    regime = np.asarray(regime).astype(int)
    # scale nmin by regime occupancy so sum target ~ nmin_month
    uniq, counts = np.unique(regime, return_counts=True)
    total = counts.sum()
    nmin_by_reg = {rid: int(np.ceil(nmin_month * (cnt/total))) for rid, cnt in zip(uniq, counts)}

    for rid in uniq:
        m = (regime == rid)
        if m.sum() < 10:
            # degenerate
            result[int(rid)] = dict(theta=0.99, trades_month=0, pnl=0.0)
            continue
        best = dict(theta=None, trades_month=0.0, pnl=-1e18)
        best_relax = dict(theta=None, trades_month=0.0, pnl=-1e18)
        bars = float(m.sum())
        for th in grid:
            pnl, trades = _pnl_for_theta(p[m], future[m], fee_bps, th)
            trades_month = trades / bars * bars_pm if bars>0 else 0.0
            cand = dict(theta=float(th), trades_month=float(trades_month), pnl=float(pnl))
            if trades_month >= nmin_by_reg.get(int(rid), nmin_month):
                if cand["pnl"] > best["pnl"]:
                    best = cand
            else:
                if cand["pnl"] > best_relax["pnl"]:
                    best_relax = cand
        if best["theta"] is None:
            result[int(rid)] = best_relax
        else:
            result[int(rid)] = best
    return result

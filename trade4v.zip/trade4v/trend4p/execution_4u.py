
import json, os, numpy as np, pandas as pd
from .metrics import mcc, ece, brier_score
from .regime import RegimeTagger
from .model_4u import RegimeProbModel
from .calibrator import IsotonicPerRegime
from .selector_4u import search_theta_for_pnl, _best_theta_for_dist, search_theta_mcc_coverage

def train_test_split_by_time(df, train_start, train_end, test_start, test_end):
    f = (df["time"] >= train_start) & (df["time"] <= train_end)
    g = (df["time"] >= test_start) & (df["time"] <= test_end)
    return df[f].copy(), df[g].copy()

def split_fit_calib(df_tr, cal_frac: float = 0.2):
    n = len(df_tr)
    k = max(1000, int(n * (1.0 - cal_frac)))
    df_fit = df_tr.iloc[:k].copy()
    df_cal = df_tr.iloc[k:].copy()
    return df_fit, df_cal

def _downsample_train(df_tr, max_rows: int):
    if max_rows is None or len(df_tr) <= max_rows:
        return df_tr
    grp = df_tr.groupby(["regime_id","label"], dropna=False, sort=False)
    parts = []
    total = len(df_tr)
    for key, sub in grp:
        frac = len(sub)/total
        n = max(1, int(frac * max_rows))
        parts.append(sub.sample(n=n, random_state=42, replace=(n>len(sub))))
    return pd.concat(parts, axis=0).sort_index()

def _future_h(arr, H):
    r = np.asarray(arr, dtype=float)
    s = pd.Series(r).rolling(H).sum().shift(-H+1).to_numpy()
    s[~np.isfinite(s)] = np.nan
    return s

def vectorized_sim_h(df_test, flag, H=5, fee_bps=10):
    ret1 = df_test["ret1"].to_numpy()
    future = pd.Series(ret1).rolling(H).sum().shift(-H+1).to_numpy()
    flag = flag.astype(int)
    trade_ret = future * flag
    fee = (fee_bps * 2 / 1e4)  # round-trip
    trade_ret = trade_ret - (fee * flag)
    mask = np.isfinite(trade_ret)
    return float(np.nansum(trade_ret[mask]))

def run_pipeline(df_all, H, cfg):
    tagger = RegimeTagger(vol_window=cfg["vol_window"], z_thr=cfg["z_thr"]).fit(df_all)
    df_all["regime_id"] = tagger.transform(df_all)

    df_tr, df_te = train_test_split_by_time(
        df_all, cfg["train_start"], cfg["train_end"], cfg["test_start"], cfg["test_end"]
    )

    if cfg.get("max_train_rows"):
        df_tr = _downsample_train(df_tr, int(cfg["max_train_rows"]))

    df_fit, df_cal = split_fit_calib(df_tr, cal_frac=float(cfg.get("cal_frac", 0.2)))

    feat_cols = cfg["feature_cols"]
    X_fit = df_fit[feat_cols].to_numpy(dtype=np.float32)
    y_fit = df_fit["label"].to_numpy()
    r_fit = df_fit["regime_id"].to_numpy()
    X_cal = df_cal[feat_cols].to_numpy(dtype=np.float32)
    y_cal = df_cal["label"].to_numpy()
    r_cal = df_cal["regime_id"].to_numpy()
    X_te  = df_te[feat_cols].to_numpy(dtype=np.float32)
    y_te  = df_te["label"].to_numpy()
    r_te  = df_te["regime_id"].to_numpy()

    model = RegimeProbModel(use_regime_models=bool(cfg.get("use_regime_models", False)),
                            min_samples_per_regime=cfg["min_samples_per_regime"])
    model.fit(X_fit, y_fit, regime_id=r_fit)

    p_cal_raw = model.predict_proba(X_cal, regime_id=r_cal)
    p_te_raw  = model.predict_proba(X_te,  regime_id=r_te)

    calib = IsotonicPerRegime(n_bins=int(cfg.get("cal_bins", 50))).fit(p_cal_raw, y_cal, regime=r_cal)
    p_cal = calib.transform(p_cal_raw, regime=r_cal)
    p_te  = calib.transform(p_te_raw,  regime=r_te)

    # Build future H-sum for calibration (for PnL objective)
    fut_cal = _future_h(df_cal["ret1"].to_numpy(), H)
    # align masks where future is finite
    mask = np.isfinite(fut_cal)
    p_cal_eff = p_cal[mask]
    fut_cal_eff = fut_cal[mask]
    r_cal_eff = r_cal[mask]

    # Threshold selection
    theta_tab = {}
    objective = (cfg.get("goal_obj") or "mcc").lower()
    if objective == "pnl":
        nmin = int(cfg.get("goal_nmin", 400))
        theta_tab = search_theta_for_pnl(p_cal_eff, fut_cal_eff, df_cal["time"].to_numpy()[mask],
                                         fee_bps=cfg["fee_bps"], regime=r_cal_eff, nmin_month=nmin)
    else:
        # fallback to coverage-constrained MCC
        theta_tab = search_theta_mcc_coverage(p_cal, y_cal, regime=r_cal,
                                              cov_min=cfg["cov_min"], cov_max=cfg["cov_max"])

    def get_theta(rid):
        item = theta_tab.get(int(rid), theta_tab.get("global", {"theta": 0.5}))
        return float(item["theta"]) if isinstance(item, dict) and "theta" in item else float(item)

    theta_series = np.array([get_theta(r) for r in r_te], dtype=float)
    flag_te = (p_te >= theta_series).astype(int)

    mcc_val = mcc(y_te, flag_te)
    cov_val = float(flag_te.mean())
    hit = float((y_te[flag_te==1]).mean()) if flag_te.sum() > 0 else 0.0
    ece_val = ece(y_te, p_te, n_bins=10)
    brier = brier_score(y_te, p_te)
    trades = int(flag_te.sum())
    pnl = vectorized_sim_h(df_te, flag_te, H=H, fee_bps=cfg["fee_bps"])

    by_regime = {}
    for rid in np.unique(r_te):
        m = (r_te == rid)
        if m.sum() == 0:
            continue
        by_regime[int(rid)] = dict(
            coverage=float(flag_te[m].mean()),
            trades=int(flag_te[m].sum()),
            mcc=float(mcc(y_te[m], flag_te[m]))
        )

    preds = pd.DataFrame({
        "time": df_te["time"].to_numpy(),
        "regime_id": r_te,
        "p_long": p_te,
        "theta": theta_series,
        "coverage_flag": flag_te,
        "label": y_te
    })

    metrics = dict(
        H=int(H),
        fee_bps=int(cfg["fee_bps"]),
        objective=objective,
        goal_nmin=int(cfg.get("goal_nmin", 0)),
        cov_min=float(cfg["cov_min"]), cov_max=float(cfg["cov_max"]),
        mcc=float(mcc_val), coverage=float(cov_val),
        hit_rate=float(hit), trades=trades,
        ece=float(ece_val), brier=float(brier),
        pnl=float(pnl),
        by_regime=by_regime,
        theta_table=theta_tab,
        cal_frac=float(cfg.get("cal_frac", 0.2)),
        cal_bins=int(cfg.get("cal_bins", 50)),
        use_regime_models=bool(cfg.get("use_regime_models", False)),
        max_train_rows=int(cfg.get("max_train_rows") or 0)
    )
    return preds, metrics, theta_tab

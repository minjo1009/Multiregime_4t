import numpy as np
import pandas as pd
from .features import compute_basic_features, dir_signal, expansion_proxy
from .regimes import assign_regimes
from .labels import future_return
from .ev_model import ev_from_dir_expansion, entry_flag_from_thresh
from .sizing import kelly_like

def run_pipeline(df, H=15, fee_bps=1.0, slip_bps=0.5):
    feats = compute_basic_features(df)
    dir_sig = dir_signal(feats)
    expn = expansion_proxy(feats)
    ev = ev_from_dir_expansion(dir_sig, expn, fee_bps=fee_bps, slip_bps=slip_bps)
    entry = entry_flag_from_thresh(ev, feats, gate_strength=0.0)

    fut_ret = future_return(df, H)
    gross = dir_sig * fut_ret
    cost = (fee_bps + slip_bps)/10000.0
    net = gross - cost*entry

    regime = assign_regimes(feats, n=3).astype(int)
    size = kelly_like(ev.abs()).fillna(0.0).clip(upper=1.0)

    out = pd.DataFrame({
        "time": df["time"],
        "regime_id": regime,
        "H_row": int(H),
        "ev_final": ev.astype(float),
        "entry_flag": entry.astype(int),
        "size": size.astype(float),
        "gross_event": gross.astype(float),
        "net_event": net.astype(float),
    })
    out = out.iloc[:-H] if H>0 and len(out)>H else out
    return out

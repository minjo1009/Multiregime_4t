
import json, os, numpy as np, pandas as pd
from .metrics import mcc, ece, brier_score
from .regime import RegimeTagger
from .model_4u import RegimeProbModel
from .calibrator import IsotonicPerRegime
from .ret_calibrator import IsoReturnPerRegime
from .selector_4u import search_theta_for_pnl, search_theta_mcc_coverage

def train_test_split_by_time(df, ts, te, us, ue):
    f = (df["time"] >= ts) & (df["time"] <= te)
    g = (df["time"] >= us) & (df["time"] <= ue)
    return df[f].copy(), df[g].copy()

def split_fit_calib(df_tr, frac: float = 0.2):
    n = len(df_tr)
    k = max(1000, int(n * (1.0 - frac)))
    return df_tr.iloc[:k].copy(), df_tr.iloc[k:].copy()

def _future_h(arr, H):
    r = np.asarray(arr, dtype=float)
    s = pd.Series(r).rolling(H).sum().shift(-H+1).to_numpy()
    s[~np.isfinite(s)] = np.nan
    return s

def _deoverlap(flag, H):
    f = flag.astype(bool)
    allow = np.ones_like(f, dtype=bool)
    out = np.zeros_like(f, dtype=bool)
    for i, x in enumerate(f):
        if x and allow[i]:
            out[i] = True
            if H > 1:
                allow[i+1:i+H] = False
    return out.astype(int)

def vectorized_sim_h(df_test, flag, H=5, fee_bps=10, use_deoverlap=True):
    ret1 = df_test["ret1"].to_numpy()
    future = pd.Series(ret1).rolling(H).sum().shift(-H+1).to_numpy()
    if use_deoverlap:
        flag = _deoverlap(flag, H)
    flag = flag.astype(int)
    trade_ret = future * flag
    fee = (fee_bps * 2 / 1e4)  # round-trip
    trade_ret = trade_ret - (fee * flag)
    mask = np.isfinite(trade_ret)
    return float(np.nansum(trade_ret[mask])), int(flag.sum())

def _months_between(ts, te):
    minutes = (pd.to_datetime(te) - pd.to_datetime(ts)) / pd.Timedelta(minutes=1)
    return float(minutes) / (30*24*60)

def _quota_total(qm, months, default=0):
    if qm is None: return default
    return int(round(float(qm) * float(months)))

def _apply_ev_topk(flag_raw, mask_r, ev, H, need):
    if need <= 0: 
        return flag_raw
    flag = flag_raw.copy()
    idx = np.arange(len(flag))
    cand = idx[(flag == 0) & mask_r & np.isfinite(ev) & (ev > 0)]
    order = np.argsort(-ev[cand])
    chosen = 0
    allow = np.ones(len(flag), dtype=bool)
    if H > 1:
        ones = np.where(flag == 1)[0]
        for i in ones:
            allow[i+1:i+H] = False
    for ii in cand[order]:
        if not allow[ii]:
            continue
        flag[ii] = 1
        chosen += 1
        if H > 1:
            allow[ii+1:ii+H] = False
        if chosen >= need:
            break
    return flag

def run_pipeline(df_all, H, cfg):
    tagger = RegimeTagger(vol_window=cfg["vol_window"],
                          z_thr=cfg.get("z_thr"),
                          z_thr_low=cfg.get("z_thr_low", 1.0),
                          z_thr_high=cfg.get("z_thr_high", 2.0)).fit(df_all)
    df_all["regime_id"] = tagger.transform(df_all)

    df_tr, df_te = train_test_split_by_time(
        df_all, cfg["train_start"], cfg["train_end"], cfg["test_start"], cfg["test_end"]
    )

    df_fit, df_cal = split_fit_calib(df_tr, frac=float(cfg.get("cal_frac", 0.2)))

    feat_cols = cfg["feature_cols"]
    X_fit = df_fit[feat_cols].to_numpy(dtype=np.float32); y_fit = df_fit["label"].to_numpy(); r_fit = df_fit["regime_id"].to_numpy()
    X_cal = df_cal[feat_cols].to_numpy(dtype=np.float32); y_cal = df_cal["label"].to_numpy(); r_cal = df_cal["regime_id"].to_numpy()
    X_te  = df_te[feat_cols].to_numpy(dtype=np.float32); y_te  = df_te["label"].to_numpy(); r_te  = df_te["regime_id"].to_numpy()

    model = RegimeProbModel(use_regime_models=bool(cfg.get("use_regime_models", False)),
                            min_samples_per_regime=cfg["min_samples_per_regime"]).fit(X_fit, y_fit, regime_id=r_fit)

    prob_cal = IsotonicPerRegime(n_bins=int(cfg.get("cal_bins", 50))).fit(model.predict_proba(X_cal, r_cal), y_cal, regime=r_cal)
    p_cal = prob_cal.transform(model.predict_proba(X_cal, r_cal), regime=r_cal)
    p_te  = prob_cal.transform(model.predict_proba(X_te,  r_te),  regime=r_te)

    fut_cal = _future_h(df_cal["ret1"].to_numpy(), H)
    mask = np.isfinite(fut_cal)
    p_cal_eff = p_cal[mask]
    fut_cal_eff = fut_cal[mask]
    r_cal_eff = r_cal[mask]

    iso_ret = IsoReturnPerRegime(n_bins=int(cfg.get("cal_bins", 50))).fit(p_cal_eff, fut_cal_eff, regime=r_cal_eff)
    ev_te = iso_ret.transform(p_te, regime=r_te)

    gmaps = cfg.get("goal_maps", {}) or {}
    nmin_map = {int(k): int(v[0]) for k, v in gmaps.items()} if gmaps else None
    nmax_map = {int(k): int(v[1]) for k, v in gmaps.items()} if gmaps else None

    if (cfg.get("goal_obj") or "pnl").lower() == "pnl":
        theta_tab = search_theta_for_pnl(p_cal_eff, fut_cal_eff, df_cal["time"].to_numpy()[mask],
                                         fee_bps=cfg["fee_bps"], regime=r_cal_eff,
                                         nmin_month=int(cfg.get("goal_nmin", 300)),
                                         nmax_month=cfg.get("goal_nmax", None),
                                         H=H, use_deoverlap=True,
                                         nmin_map=nmin_map, nmax_map=nmax_map)
    else:
        theta_tab = search_theta_mcc_coverage(p_cal, y_cal, regime=r_cal,
                                              cov_min=cfg["cov_min"], cov_max=cfg["cov_max"])

    def theta_for(rid):
        t = theta_tab.get(int(rid), theta_tab.get("global", {"theta": 0.5}))
        return float(t["theta"]) if isinstance(t, dict) and "theta" in t else float(t)

    theta_series = np.array([theta_for(r) for r in r_te], dtype=float)
    flag_raw = (p_te >= theta_series).astype(int)

    months = _months_between(cfg["test_start"], cfg["test_end"])
    uniq = np.unique(r_te)
    q_nmin = {rid: (nmin_map.get(int(rid)) if nmin_map else None) for rid in uniq}
    q_nmax = {rid: (nmax_map.get(int(rid)) if nmax_map else None) for rid in uniq}
    target_min_total = {rid: _quota_total(q_nmin[rid], months, 0) for rid in uniq}
    target_max_total = {rid: (_quota_total(q_nmax[rid], months, None) if q_nmax[rid] is not None else None) for rid in uniq}

    gate_mode = (cfg.get("gate_mode") or "soft").lower()
    if gate_mode == "soft":
        thin_factor = float(cfg.get("thin_factor", 0.2))
        thin_floor  = int(cfg.get("thin_floor", 30))
        for rid, t in theta_tab.items():
            if isinstance(t, dict) and t.get("pnl", 0.0) < 0.0:
                min_thin = max(int(round(thin_floor * months)), 0)
                if target_max_total.get(rid) is not None:
                    target_max_total[rid] = max(min_thin, int(round(thin_factor * target_max_total[rid])))
                target_min_total[rid] = min(target_max_total.get(rid, min_thin), max(target_min_total[rid], min_thin))

    flag_use = flag_raw.copy()
    for rid in uniq:
        mask_r = (r_te == rid)
        loc = flag_use[mask_r].astype(bool)
        allow = np.ones_like(loc, dtype=bool); cur = 0
        for i, x in enumerate(loc):
            if x and allow[i]:
                cur += 1
                if H > 1: allow[i+1:i+H] = False
        min_total = target_min_total.get(rid, 0) or 0
        max_total = target_max_total.get(rid, None)

        need = max(0, min_total - cur)
        if need > 0:
            flag_use = _apply_ev_topk(flag_use, mask_r, ev_te, H, need)

        if max_total is not None:
            idx = np.where((flag_use==1) & mask_r)[0]
            if len(idx) > max_total:
                order = np.argsort(ev_te[idx])  # drop lowest EV first
                drop = idx[order][:len(idx)-max_total]
                flag_use[drop] = 0

    pnl, trades = vectorized_sim_h(df_te, flag_use, H=H, fee_bps=cfg["fee_bps"], use_deoverlap=True)

    mcc_val = mcc(y_te, flag_use)
    cov_val = float(flag_use.mean())
    hit = float((y_te[flag_use==1]).mean()) if flag_use.sum() > 0 else 0.0
    ece_val = ece(y_te, p_te, n_bins=10)
    brier   = brier_score(y_te, p_te)

    by_regime = {}
    for rid in uniq:
        m = (r_te == rid)
        if m.sum() == 0: 
            continue
        by_regime[int(rid)] = dict(
            coverage=float(flag_use[m].mean()),
            trades=int(flag_use[m].sum()),
            mcc=float(mcc(y_te[m], flag_use[m]))
        )

    preds = pd.DataFrame({
        "time": df_te["time"].to_numpy(),
        "regime_id": r_te,
        "p_long": p_te,
        "ev_hat": ev_te,
        "theta": theta_series,
        "coverage_flag": flag_use,
        "label": y_te
    })

    metrics = dict(
        H=int(H),
        fee_bps=int(cfg["fee_bps"]),
        objective="pnl",
        goal_nmin=int(cfg.get("goal_nmin", 0)),
        goal_nmax=int(cfg.get("goal_nmax") or 0),
        goal_maps=gmaps,
        deoverlap=True,
        gate_mode=gate_mode,
        thin_factor=float(cfg.get("thin_factor", 0.2)),
        thin_floor=int(cfg.get("thin_floor", 30)),
        vol_window=int(cfg["vol_window"]),
        z_thr=cfg.get("z_thr"),
        z_thr_low=float(cfg.get("z_thr_low", 1.0)),
        z_thr_high=float(cfg.get("z_thr_high", 2.0)),
        mcc=float(mcc_val),
        coverage=float(cov_val),
        hit_rate=float(hit),
        trades=int(trades),
        ece=float(ece_val),
        brier=float(brier),
        pnl=float(pnl),
        by_regime=by_regime,
        theta_table=theta_tab,
        cal_frac=float(cfg.get("cal_frac", 0.2)),
        cal_bins=int(cfg.get("cal_bins", 50))
    )
    return preds, metrics, theta_tab

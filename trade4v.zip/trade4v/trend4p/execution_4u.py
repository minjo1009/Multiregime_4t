
import json, os, numpy as np, pandas as pd
from .metrics import mcc, ece, brier_score
from .regime import RegimeTagger
from .model_4u import RegimeProbModel
from .calibrator import IsotonicPerRegime
from .ret_calibrator import IsoReturnPerRegime
from .selector_4u import search_theta_for_pnl, search_theta_mcc_coverage

def train_test_split_by_time(df, ts, te, us, ue):
    f = (df["time"] >= ts) & (df["time"] <= te)
    g = (df["time"] >= us) & (df["time"] <= ue)
    return df[f].copy(), df[g].copy()

def split_fit_calib(df_tr, frac: float = 0.2):
    n = len(df_tr)
    k = max(1000, int(n * (1.0 - frac)))
    return df_tr.iloc[:k].copy(), df_tr.iloc[k:].copy()

def _future_h(arr, H):
    r = np.asarray(arr, dtype=float)
    s = pd.Series(r).rolling(H).sum().shift(-H+1).to_numpy()
    s[~np.isfinite(s)] = np.nan
    return s

def _future_h_by_regime(arr, rid, H_map, default_H):
    r = np.asarray(arr, dtype=float)
    out = np.full(len(r), np.nan, dtype=float)
    for rr in np.unique(rid):
        H = int(H_map.get(int(rr), default_H))
        s = pd.Series(r).rolling(H).sum().shift(-H+1).to_numpy()
        out[rid==rr] = s[rid==rr]
    out[~np.isfinite(out)] = np.nan
    return out

def _deoverlap(flag, H):
    f = flag.astype(bool)
    allow = np.ones_like(f, dtype=bool)
    out = np.zeros_like(f, dtype=bool)
    for i, x in enumerate(f):
        if x and allow[i]:
            out[i] = True
            if H > 1:
                allow[i+1:i+H] = False
    return out.astype(int)

def _deoverlap_generic(flag, H_seq):
    f = flag.astype(bool)
    allow = np.ones_like(f, dtype=bool)
    out = np.zeros_like(f, dtype=bool)
    for i, x in enumerate(f):
        if x and allow[i]:
            out[i] = True
            h = int(max(1, H_seq[i]))
            if h > 1:
                allow[i+1:i+h] = False
    return out.astype(int)

def vectorized_sim(df_test, flag, size, H_seq, fee_bps=10, use_deoverlap=True):
    ret1 = df_test["ret1"].to_numpy()
    fut = np.full(len(ret1), np.nan, dtype=float)
    unique_H = np.unique(H_seq.astype(int))
    rolls = {}
    s = pd.Series(ret1)
    for H in unique_H:
        rs = s.rolling(H).sum().shift(-H+1).to_numpy()
        rolls[int(H)] = rs
    for i,h in enumerate(H_seq):
        fut[i] = rolls[int(h)][i]
    if use_deoverlap:
        flag = _deoverlap_generic(flag, H_seq)
    size = size.astype(float)
    flag = flag.astype(int)
    fee_rt = (fee_bps * 2 / 1e4)
    trade_ret = fut * (flag * size) - fee_rt * (flag * size)
    mask = np.isfinite(trade_ret)
    return float(np.nansum(trade_ret[mask])), int(np.sum(flag)), float(np.nansum((flag*size)[mask]))

def run_pipeline(df_all, H, cfg):
    tagger = RegimeTagger(vol_window=cfg["vol_window"],
                          z_thr=cfg.get("z_thr"),
                          z_thr_low=cfg.get("z_thr_low", 1.0),
                          z_thr_high=cfg.get("z_thr_high", 2.0)).fit(df_all)
    df_all["regime_id"] = tagger.transform(df_all)

    df_tr, df_te = train_test_split_by_time(
        df_all, cfg["train_start"], cfg["train_end"], cfg["test_start"], cfg["test_end"]
    )

    df_fit, df_cal = split_fit_calib(df_tr, frac=float(cfg.get("cal_frac", 0.2)))

    feat_cols = cfg["feature_cols"]
    X_fit = df_fit[feat_cols].to_numpy(dtype=np.float32); y_fit = df_fit["label"].to_numpy(); r_fit = df_fit["regime_id"].to_numpy()
    X_cal = df_cal[feat_cols].to_numpy(dtype=np.float32); y_cal = df_cal["label"].to_numpy(); r_cal = df_cal["regime_id"].to_numpy()
    X_te  = df_te[feat_cols].to_numpy(dtype=np.float32); y_te  = df_te["label"].to_numpy(); r_te  = df_te["regime_id"].to_numpy()

    model = RegimeProbModel(use_regime_models=bool(cfg.get("use_regime_models", False)),
                            min_samples_per_regime=cfg["min_samples_per_regime"]).fit(X_fit, y_fit, regime_id=r_fit)
    prob_cal = IsotonicPerRegime(n_bins=int(cfg.get("cal_bins", 50))).fit(model.predict_proba(X_cal, r_cal), y_cal, regime=r_cal)
    p_cal = prob_cal.transform(model.predict_proba(X_cal, r_cal), regime=r_cal)
    p_te  = prob_cal.transform(model.predict_proba(X_te,  r_te),  regime=r_te)

    H_map = cfg.get("H_map") or {}
    fut_cal = _future_h_by_regime(df_cal["ret1"].to_numpy(), r_cal, H_map, default_H=cfg["H"])
    m = np.isfinite(fut_cal)
    p_cal_eff, fut_cal_eff, r_cal_eff = p_cal[m], fut_cal[m], r_cal[m]

    iso_ret = IsoReturnPerRegime(n_bins=int(cfg.get("cal_bins", 50))).fit(p_cal_eff, fut_cal_eff, regime=r_cal_eff)
    ev_te = iso_ret.transform(p_te, regime=r_te)

    fee_rt = (cfg["fee_bps"] * 2 / 1e4)
    ev_net = ev_te - fee_rt
    ev_floor = float(cfg.get("ev_floor_mult", 0.0)) * fee_rt

    gmaps = cfg.get("goal_maps", {}) or {}
    nmin_map = {int(k): int(v[0]) for k, v in gmaps.items()} if gmaps else None
    nmax_map = {int(k): int(v[1]) for k, v in gmaps.items()} if gmaps else None

    from .selector_4u import search_theta_for_pnl, search_theta_mcc_coverage
    if (cfg.get("goal_obj") or "pnl").lower() == "pnl":
        theta_tab = search_theta_for_pnl(p_cal_eff, fut_cal_eff, df_cal["time"].to_numpy()[m],
                                         fee_bps=cfg["fee_bps"], regime=r_cal_eff,
                                         nmin_month=int(cfg.get("goal_nmin", 300)),
                                         nmax_month=cfg.get("goal_nmax", None),
                                         H=cfg["H"], use_deoverlap=True,
                                         nmin_map=nmin_map, nmax_map=nmax_map)
    else:
        theta_tab = search_theta_mcc_coverage(p_cal, y_cal, regime=r_cal,
                                              cov_min=cfg["cov_min"], cov_max=cfg["cov_max"])

    def theta_for(rid):
        t = theta_tab.get(int(rid), theta_tab.get("global", {"theta": 0.5}))
        return float(t["theta"]) if isinstance(t, dict) and "theta" in t else float(t)

    theta_series = np.array([theta_for(r) for r in r_te], dtype=float)
    flag_raw = (p_te >= theta_series).astype(int)
    size_raw = np.zeros_like(p_te, dtype=float)

    H_seq = np.array([int(H_map.get(int(r), cfg["H"])) for r in r_te], dtype=int)
    # filters
    def _range_bps(df, k=20):
        hi = df["high"].rolling(k, min_periods=1).max()
        lo = df["low"].rolling(k, min_periods=1).min()
        mid = df["close"].replace(0.0, np.nan)
        rbps = (hi - lo) / mid * 1e4
        return rbps.fillna(0.0).to_numpy()

    rbps = _range_bps(df_te, k=int(cfg.get("range_k", 20)))
    if float(cfg.get("min_range_bp", 0.0)) > 0.0:
        flag_raw[(rbps < float(cfg["min_range_bp"]))] = 0
    if float(cfg.get("spike_bps", 0.0)) > 0.0:
        retbps = np.abs(df_te["ret1"].to_numpy()) * 1e4
        block_next = (retbps >= float(cfg["spike_bps"])).astype(int)
        block_next = np.roll(block_next, 1); block_next[0] = 0
        flag_raw[block_next == 1] = 0
    flag_raw[ev_net < ev_floor] = 0

    # quotas & gating
    months = (pd.to_datetime(cfg["test_end"]) - pd.to_datetime(cfg["test_start"])) / pd.Timedelta(days=30)
    months = float(months)
    uniq = np.unique(r_te)
    q_nmin = {rid: (nmin_map.get(int(rid)) if nmin_map else None) for rid in uniq}
    q_nmax = {rid: (nmax_map.get(int(rid)) if nmax_map else None) for rid in uniq}
    t_min = {rid: int(round((q_nmin[rid] or 0) * months)) for rid in uniq}
    t_max = {rid: (int(round(q_nmax[rid] * months)) if q_nmax[rid] is not None else None) for rid in uniq}

    gate_mode = (cfg.get("gate_mode") or "soft").lower()
    if gate_mode == "soft":
        thin_factor = float(cfg.get("thin_factor", 0.1))
        thin_floor  = int(cfg.get("thin_floor", 20))
        for rid, t in theta_tab.items():
            if isinstance(t, dict) and t.get("pnl", 0.0) < 0.0:
                min_thin = max(int(round(thin_floor * months)), 0)
                if t_max.get(rid) is not None:
                    t_max[rid] = max(min_thin, int(round(thin_factor * t_max[rid])))
                t_min[rid] = min(t_max.get(rid, min_thin), max(t_min[rid], min_thin))

    def _apply_ev_topk(flag_raw, size_raw, mask_r, ev_net, H_seq, need, size_per=1.0, ev_floor=0.0):
        if need <= 0: 
            return flag_raw, size_raw
        flag = flag_raw.copy(); size = size_raw.copy()
        idx = np.arange(len(flag))
        cand = idx[(flag == 0) & mask_r & np.isfinite(ev_net) & (ev_net >= ev_floor)]
        order = np.argsort(-ev_net[cand])
        chosen = 0
        allow = np.ones(len(flag), dtype=bool)
        ones = np.where(flag == 1)[0]
        for i in ones:
            h = int(max(1, H_seq[i]))
            allow[i+1:i+h] = False
        for ii in cand[order]:
            if not allow[ii]:
                continue
            flag[ii] = 1
            size[ii] = size_per
            chosen += 1
            h = int(max(1, H_seq[ii]))
            allow[ii+1:ii+h] = False
            if chosen >= need:
                break
        return flag, size

    flag_use = flag_raw.copy()
    size_use = size_raw.copy()
    for rid in uniq:
        mask_r = (r_te == rid)
        loc = flag_use[mask_r].astype(bool)
        allow = np.ones_like(loc, dtype=bool); cur = 0
        for i, x in enumerate(loc):
            if x and allow[i]:
                cur += 1
                h = int(H_seq[mask_r][i])
                if h > 1: allow[i+1:i+h] = False
        need = max(0, (t_min[rid] or 0) - cur)
        if need > 0:
            flag_use, size_use = _apply_ev_topk(flag_use, size_use, mask_r, ev_net, H_seq, need, size_per=1.0, ev_floor=ev_floor)
        if t_max[rid] is not None:
            idx = np.where((flag_use==1) & mask_r)[0]
            if len(idx) > t_max[rid]:
                order = np.argsort(ev_net[idx])
                drop = idx[order][:len(idx)-t_max[rid]]
                flag_use[drop] = 0; size_use[drop] = 0.0

    # sizing
    size_final = np.zeros_like(size_use, dtype=float)
    if (cfg.get("size_mode") or "none") == "kelly":
        var_by = {}
        for rr in np.unique(r_cal_eff):
            v = float(np.nanvar(fut_cal_eff[r_cal_eff==rr]))
            if not np.isfinite(v) or v<=0: v = 1e-6
            var_by[int(rr)] = v
        rb = float(cfg.get("risk_budget", 0.02))
        smax = float(cfg.get("size_max", 1.0))
        for i in range(len(size_use)):
            if flag_use[i] != 1: 
                size_final[i] = 0.0; continue
            rr = int(r_te[i])
            v = var_by.get(rr, 1e-4)
            mu = float(ev_net[i])
            sz = (mu / (v + 1e-8)) * rb
            if not np.isfinite(sz): sz = 0.0
            size_final[i] = max(0.0, min(smax, sz))
    else:
        size_final = (flag_use>0).astype(float)

    pnl, trades, notional_trades = vectorized_sim(df_te, flag_use, size_final, H_seq, fee_bps=cfg["fee_bps"], use_deoverlap=True)

    # metrics
    from .metrics import mcc, ece, brier_score
    mcc_val = mcc(y_te, flag_use)
    cov_val = float(flag_use.mean())
    hit = float((y_te[flag_use==1]).mean()) if flag_use.sum() > 0 else 0.0
    ece_val = ece(y_te, p_te, n_bins=10)
    brier   = brier_score(y_te, p_te)

    by_regime = {}
    for rid in np.unique(r_te):
        msk = (r_te == rid)
        if msk.sum() == 0:
            continue
        pnl_r, trades_r, notion_r = vectorized_sim(df_te[msk].reset_index(drop=True),
                                                  flag_use[msk].astype(int),
                                                  size_final[msk].astype(float),
                                                  H_seq[msk].astype(int),
                                                  fee_bps=cfg["fee_bps"], use_deoverlap=True)
        by_regime[int(rid)] = dict(coverage=float(flag_use[msk].mean()),
                                   trades=int(trades_r),
                                   notional=float(notion_r),
                                   pnl=float(pnl_r),
                                   mcc=float(mcc(y_te[msk], flag_use[msk])))

    pass_ev = float(np.mean(ev_net >= ev_floor)) if len(ev_net)>0 else 0.0
    pass_ev_by = {int(r): float(np.mean(ev_net[(r_te==r)] >= ev_floor)) for r in np.unique(r_te)}

    preds = pd.DataFrame({
        "time": df_te["time"].to_numpy(),
        "regime_id": r_te,
        "H_row": H_seq,
        "p_long": p_te,
        "ev_hat": ev_te,
        "ev_net": ev_net,
        "theta": theta_series,
        "entry_flag": flag_use,
        "size": size_final,
        "label": y_te
    })

    metrics = dict(
        H=int(cfg["H"]), H_map=H_map,
        fee_bps=int(cfg["fee_bps"]),
        objective="pnl",
        goal_nmin=int(cfg.get("goal_nmin", 0)),
        goal_nmax=int(cfg.get("goal_nmax") or 0),
        goal_maps=gmaps,
        deoverlap=True,
        gate_mode=(cfg.get("gate_mode") or "soft"),
        thin_factor=float(cfg.get("thin_factor", 0.1)),
        thin_floor=int(cfg.get("thin_floor", 20)),
        vol_window=int(cfg["vol_window"]),
        z_thr=cfg.get("z_thr"),
        z_thr_low=float(cfg.get("z_thr_low", 1.0)),
        z_thr_high=float(cfg.get("z_thr_high", 2.0)),
        mcc=float(mcc_val),
        coverage=float(cov_val),
        hit_rate=float(hit),
        trades=int(trades),
        notional_trades=float(notional_trades),
        ece=float(ece_val),
        brier=float(brier),
        pnl=float(pnl),
        ev_floor=float(ev_floor),
        ev_floor_mult=float(cfg.get("ev_floor_mult", 0.0)),
        pass_ev=float(pass_ev),
        pass_ev_by=pass_ev_by,
        by_regime=by_regime,
        theta_table=theta_tab,
        cal_frac=float(cfg.get("cal_frac", 0.2)),
        cal_bins=int(cfg.get("cal_bins", 50)),
        size_mode=cfg.get("size_mode","none"),
        risk_budget=float(cfg.get("risk_budget", 0.02)),
        size_max=float(cfg.get("size_max", 1.0)),
        min_range_bp=float(cfg.get("min_range_bp", 0.0)),
        range_k=int(cfg.get("range_k", 20)),
        spike_bps=float(cfg.get("spike_bps", 0.0))
    )
    return preds, metrics, theta_tab

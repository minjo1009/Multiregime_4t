
import json, os
import numpy as np
import pandas as pd
from .metrics import mcc, ece, brier_score
from .regime import RegimeTagger
from .model_4u import RegimeProbModel
from .selector_4u import search_theta_mcc_coverage

def train_test_split_by_time(df, train_start, train_end, test_start, test_end):
    f = (df["time"] >= train_start) & (df["time"] <= train_end)
    g = (df["time"] >= test_start) & (df["time"] <= test_end)
    return df[f].copy(), df[g].copy()

def vectorized_sim_h(df_test, flag, H=5, fee_bps=10):
    ret1 = df_test["ret1"].to_numpy()
    future = pd.Series(ret1).rolling(H).sum().shift(-H+1).to_numpy()
    flag = flag.astype(int)
    trade_ret = future * flag
    fee = (fee_bps * 2 / 1e4)  # 왕복
    trade_ret = trade_ret - (fee * flag)
    mask = np.isfinite(trade_ret)
    return float(np.nansum(trade_ret[mask]))

def run_pipeline(df_all, H, cfg):
    tagger = RegimeTagger(vol_window=cfg["vol_window"], z_thr=cfg["z_thr"]).fit(df_all)
    df_all["regime_id"] = tagger.transform(df_all)

    df_tr, df_te = train_test_split_by_time(
        df_all, cfg["train_start"], cfg["train_end"], cfg["test_start"], cfg["test_end"]
    )

    feat_cols = cfg["feature_cols"]
    X_tr, y_tr, r_tr = df_tr[feat_cols].to_numpy(), df_tr["label"].to_numpy(), df_tr["regime_id"].to_numpy()
    X_te, y_te, r_te = df_te[feat_cols].to_numpy(), df_te["label"].to_numpy(), df_te["regime_id"].to_numpy()

    model = RegimeProbModel(min_samples_per_regime=cfg["min_samples_per_regime"])
    model.fit(X_tr, y_tr, regime_id=r_tr)

    p_tr = model.predict_proba(X_tr, regime_id=r_tr)
    p_te = model.predict_proba(X_te, regime_id=r_te)

    theta_tab = search_theta_mcc_coverage(p_tr, y_tr, regime=r_tr,
                                          cov_min=cfg["cov_min"], cov_max=cfg["cov_max"])
    def get_theta(rid):
        return theta_tab.get(int(rid), theta_tab.get("global", {"theta": 0.5}))[            "theta"]

    theta_series = np.array([get_theta(r) for r in r_te], dtype=float)
    flag_te = (p_te >= theta_series).astype(int)

    mcc_val = mcc(y_te, flag_te)
    cov_val = float(flag_te.mean())
    hit = float((y_te[flag_te==1]).mean()) if flag_te.sum() > 0 else 0.0
    ece_val = ece(y_te, p_te, n_bins=10)
    brier = brier_score(y_te, p_te)
    trades = int(flag_te.sum())
    pnl = vectorized_sim_h(df_te, flag_te, H=H, fee_bps=cfg["fee_bps"])

    by_regime = {}
    for rid in np.unique(r_te):
        m = (r_te == rid)
        if m.sum() == 0: 
            continue
        by_regime[int(rid)] = dict(
            coverage=float(flag_te[m].mean()),
            trades=int(flag_te[m].sum()),
            mcc=float(mcc(y_te[m], flag_te[m])),
            ece=float(ece(y_te[m], p_te[m], n_bins=10))
        )

    preds = pd.DataFrame({
        "time": df_te["time"].to_numpy(),
        "regime_id": r_te,
        "p_long": p_te,
        "theta": theta_series,
        "coverage_flag": flag_te,
        "label": y_te
    })

    metrics = dict(
        H=int(H),
        fee_bps=int(cfg["fee_bps"]),
        cov_min=float(cfg["cov_min"]), cov_max=float(cfg["cov_max"]),
        mcc=float(mcc_val), coverage=float(cov_val),
        hit_rate=float(hit), trades=trades,
        ece=float(ece_val), brier=float(brier),
        pnl=float(pnl),
        by_regime=by_regime
    )
    return preds, metrics, theta_tab

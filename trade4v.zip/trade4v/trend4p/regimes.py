import numpy as np
import pandas as pd

def assign_regimes(feats, n=3):
    vol = feats["vol_fast"].fillna(0.0)
    try:
        q = pd.qcut(vol, q=n, labels=False, duplicates="drop")
        r = q.fillna(n//2).astype(int)
    except Exception:
        r = pd.Series((vol>vol.median()).astype(int), index=vol.index)
    return r

import numpy as np
import pandas as pd
from .utils import mcc_from_labels

def summarize_preds(preds):
    sel = preds["entry_flag"]==1
    n_tr = int(sel.sum())
    pnl  = float(preds.loc[sel, "net_event"].sum()) if n_tr>0 else 0.0
    wins = int((preds.loc[sel, "gross_event"]>0).sum()) if n_tr>0 else 0
    hit  = (wins / n_tr) if n_tr>0 else 0.0
    mcc, acc, cov = mcc_from_labels(np.sign(preds["gross_event"]), np.sign(preds["ev_final"]))
    return {
        "coverage": float(cov),
        "acc": float(acc),
        "mcc": float(mcc),
        "n_trades": n_tr,
        "total_return": pnl,
        "monthly_return": pnl
    }

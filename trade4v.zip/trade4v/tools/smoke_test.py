
import os, subprocess, sys
import pandas as pd
import numpy as np
from datetime import datetime, timedelta, timezone

def gen_synth_csv(path, minutes=60*24*7, seed=42):
    np.random.seed(seed)
    start = datetime(2025,1,1,0,0, tzinfo=timezone.utc)
    times = [start + timedelta(minutes=i) for i in range(minutes)]
    # random walk
    price = 10000.0
    rows = []
    for t in times:
        ret = np.random.normal(0, 0.0008)  # ~0.08% per minute std
        price *= np.exp(ret)
        o = price * (1 + np.random.normal(0, 0.0002))
        c = price
        h = max(o,c) * (1 + abs(np.random.normal(0, 0.0003)))
        l = min(o,c) * (1 - abs(np.random.normal(0, 0.0003)))
        v = abs(np.random.normal(100, 20))
        rows.append([t.isoformat(), o, h, l, c, v])
    df = pd.DataFrame(rows, columns=["time","open","high","low","close","volume"])
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)
    return path

if __name__ == "__main__":
    data_path = os.path.join(os.path.dirname(__file__), "..", "data", "sim_1m.csv")
    gen_synth_csv(data_path, minutes=60*24*8)  # 8 days
    # run example split
    cmd = [
        sys.executable, os.path.join(os.path.dirname(__file__), "..", "run_4u.py"),
        "--data", data_path,
        "--train_start", "2025-01-01",
        "--train_end",   "2025-01-05",
        "--test_start",  "2025-01-06",
        "--test_end",    "2025-01-07",
        "--H", "5",
        "--fee_bps", "10",
        "--out_dir", os.path.join(os.path.dirname(__file__), "..", "_out_4u", "smoke")
    ]
    print("Running:", " ".join(cmd))
    subprocess.check_call(cmd)
    print("Done. See _out_4u/smoke for outputs.")

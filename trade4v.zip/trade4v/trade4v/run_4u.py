
import argparse, json, os, sys
import numpy as np, pandas as pd
from trend4p.utils import parse_time, add_basic_features, future_return, SESS_LABELS
from trend4p.calibrate import build_sr_calibration, apply_sr_calibration
from trend4p.range_model import fit_quantile_tables, apply_quantile_tables
from trend4p.costs import dynamic_cost_bps
from trend4p.ev import ev_long, kelly_fraction, bps_to_frac
from trend4p.gating import day_regime_topk_spacing, enforce_qa

def fail(msg, code=2): print(f"ERROR: {msg}", file=sys.stderr); sys.exit(code)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True); ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True);  ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=15)
    ap.add_argument("--fee_bps", type=float, default=1.0)
    ap.add_argument("--slip_bps", type=float, default=0.5)
    ap.add_argument("--out_dir", type=str, default="_out_4u")
    ap.add_argument("--n_bins", type=int, default=10)
    ap.add_argument("--q_tp", type=float, default=0.9)
    ap.add_argument("--q_sl", type=float, default=0.6)
    ap.add_argument("--K_day", type=str, default="0:10,1:15,2:30")
    ap.add_argument("--overlap_mode", choices=["cap","pyramid","none"], default="cap")
    ap.add_argument("--max_concurrent", type=int, default=2)
    ap.add_argument("--min_gap_bars", type=int, default=5)
    ap.add_argument("--pyr_ev_step", type=float, default=0.0)
    ap.add_argument("--min_cov", type=float, default=0.02)
    ap.add_argument("--max_cov", type=float, default=0.6)
    ap.add_argument("--strict_qa", type=int, default=0)
    args = ap.parse_args()

    run_dir = os.path.join(args.out_dir, "run"); os.makedirs(run_dir, exist_ok=True)

    df = pd.read_csv(args.data)
    df = parse_time(df)
    df = df.set_index('time').sort_index().loc[args.train_start:args.test_end].reset_index()
    if len(df)==0: fail("Empty slice after date filtering.")
    df = add_basic_features(df)
    df = future_return(df, args.H)
    df['date'] = df['time'].dt.tz_convert('UTC').dt.floor('D')

    tr = df[(df['time']>=pd.Timestamp(args.train_start, tz='UTC')) & (df['time']<=pd.Timestamp(args.train_end, tz='UTC'))].copy()
    te = df[(df['time']>=pd.Timestamp(args.test_start,  tz='UTC')) & (df['time']<=pd.Timestamp(args.test_end,  tz='UTC'))].copy()
    if len(te)==0: fail("Empty test slice")

    tr['p_raw'] = 1/(1+np.exp(-(tr['mom']/(tr['vol']+1e-8)).clip(-10,10).fillna(0.0)))
    te['p_raw'] = 1/(1+np.exp(-(te['mom']/(te['vol']+1e-8)).clip(-10,10).fillna(0.0)))
    tr['y'] = (tr['fret']>0).astype(int)
    maps = build_sr_calibration(tr, 'p_raw','y', n_bins=args.n_bins)
    te = apply_sr_calibration(te, 'p_raw','p_long', maps)

    tables = fit_quantile_tables(tr, H=args.H, quantiles=tuple(sorted(set([args.q_sl, args.q_tp]))))
    tp, sl = apply_quantile_tables(te, tables, q_tp=args.q_tp, q_sl=args.q_sl)
    te['tp_frac'] = tp; te['sl_frac'] = sl

    te = te.sort_values('time').reset_index(drop=True)  # ensure 0..n-1 for downstream gating
    te['cost_bps'] = [dynamic_cost_bps(args.fee_bps, args.slip_bps, s) for s in te['sess']]
    te['ev'] = ev_long(te['p_long'].values, te['tp_frac'].values, te['sl_frac'].values,
                       cost_bps=te['cost_bps'].values, roundtrip=True)
    te['cand'] = 1; te['H_row'] = args.H

    # K map
    k_map = {}
    for part in args.K_day.split(","):
        part = part.strip()
        if not part: continue
        rid, kval = part.split(":"); k_map[int(rid)] = int(kval)

    te['g_idx'] = te.groupby(['date','regime_id']).cumcount()
    gate_frame = te[['date','regime_id','g_idx','ev','cand']].copy().rename(columns={'g_idx':'idx'})
    gated = day_regime_topk_spacing(gate_frame, k_map, H_bars=args.H,
                                    min_gap_bars=args.min_gap_bars,
                                    overlap_mode=args.overlap_mode,
                                    max_concurrent=args.max_concurrent,
                                    pyr_ev_step=args.pyr_ev_step)
    te['entry_flag'] = gated['entry_flag'].values
    te['theta_used'] = gated['theta_used'].values

    ok_cov, cov = enforce_qa(te, min_cov=args.min_cov, max_cov=args.max_cov)
    trades = int(te['entry_flag'].sum())

    var_h = tr.groupby('regime_id')['ret1'].apply(lambda s: s.rolling(args.H).sum().var() or 1e-6).to_dict()
    def ksize(row, shrink=0.25, mx=0.5):
        v = float(var_h.get(int(row['regime_id']), 1e-6))
        ev = float(row['ev'])
        return max(0.0, min(mx, (ev/v)*shrink))
    te['size'] = te.apply(ksize, axis=1)
    te['realized_gross'] = te['fret'] * te['entry_flag']
    te['realized_net']   = te['realized_gross'] - (te['cost_bps']/10000.0*2.0)*te['entry_flag']
    te['realized_net']  *= te['size']

    cols = ['time','date','sess','regime_id','H_row','p_long','tp_frac','sl_frac','cost_bps',
            'ev','cand','theta_used','entry_flag','size','realized_gross','realized_net']
    te[cols].to_csv(os.path.join(run_dir,"preds_test.csv"), index=False)
    with open(os.path.join(run_dir,"metrics_oos.json"),"w",encoding="utf-8") as f:
        json.dump({"H": args.H, "min_cov": args.min_cov, "cov": cov, "trades": trades,
                   "strict_qa": args.strict_qa,
                   "note":"v3.3 idx-safe range model + SR-calib + dynamic cost + gating"},
                  f, indent=2)
    print(json.dumps({"cov":cov, "trades":trades, "qa_ok":bool(ok_cov)}, indent=2))
    if (not ok_cov) and args.strict_qa==1:
        fail(f"Coverage {cov:.3f} out of bounds [{args.min_cov},{args.max_cov}]")

if __name__ == "__main__":
    main()

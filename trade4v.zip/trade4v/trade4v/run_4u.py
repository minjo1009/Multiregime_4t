
import argparse, json, os, sys
import numpy as np, pandas as pd
from trend4p.utils import parse_time, compute_basic_features, future_return
from trend4p.calibrate import bin_calibrate_prob, apply_bin_calibration
from trend4p.ev import ev_long, kelly_fraction, bps_to_frac
from trend4p.gating import dynamic_theta_topk, enforce_qa, ev_decile_monotonicity
from trend4p.logger import RunLogger

def sigmoid(x): return 1/(1+np.exp(-x))
def fail(msg, code=2): print(f"ERROR: {msg}", file=sys.stderr); sys.exit(code)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True); ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True);  ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=15)
    ap.add_argument("--fee_bps", type=float, default=1.0)
    ap.add_argument("--slip_bps", type=float, default=0.5)
    ap.add_argument("--out_dir", type=str, default="_out_4u")
    ap.add_argument("--size_mode", choices=["none","kelly"], default="kelly")
    ap.add_argument("--kelly_shrink", type=float, default=0.25)
    ap.add_argument("--size_max", type=float, default=0.5)
    ap.add_argument("--K_day", type=str, default="0:5,1:10,2:20")
    ap.add_argument("--ev_margin_bps", type=float, default=1.0)
    ap.add_argument("--ev_floor_min_bps", type=float, default=0.0)
    ap.add_argument("--ev_relax_factor",  type=float, default=0.5)
    args = ap.parse_args()

    run_dir = os.path.join(args.out_dir, "run"); os.makedirs(run_dir, exist_ok=True)
    log = RunLogger(os.path.join(run_dir, "run.log"))
    log.log("=== trade4v S1/S2 run v3.1d ==="); log.log(json.dumps(vars(args), indent=2))

    df = pd.read_csv(args.data); df = parse_time(df)
    df = df.set_index('time').sort_index().loc[args.train_start:args.test_end].reset_index()
    if len(df)==0: fail("Empty slice after date filtering.")
    df = compute_basic_features(df); df = future_return(df, args.H)

    tr = df[(df['time']>=pd.Timestamp(args.train_start, tz='UTC')) & (df['time']<=pd.Timestamp(args.train_end, tz='UTC'))].copy()
    te = df[(df['time']>=pd.Timestamp(args.test_start,  tz='UTC')) & (df['time']<=pd.Timestamp(args.test_end,  tz='UTC'))].copy()
    if len(te)==0: fail("Empty test slice; check dates/timezone." )

    tr['p_raw'] = 1/(1+np.exp(-(tr['mom']/(tr['vol']+1e-8)).clip(-10,10).fillna(0.0)))
    te['p_raw'] = 1/(1+np.exp(-(te['mom']/(te['vol']+1e-8)).clip(-10,10).fillna(0.0)))
    mapping, _ = bin_calibrate_prob(tr['p_raw'].values, (tr['fret']>0).astype(int).values, n_bins=10)
    te['p_long'] = apply_bin_calibration(te['p_raw'].values, mapping)

    vol_scale = float((tr['vol'].median() + te['vol'].median())/2.0) or 1e-6
    tp_frac = (te['vol'].clip(1e-8)/vol_scale) * (args.H**0.5) * 0.002
    sl_frac = tp_frac.copy()
    te['tp_frac'], te['sl_frac'] = tp_frac.values, sl_frac.values

    te['ev'] = ev_long(te['p_long'].values, te['tp_frac'].values, te['sl_frac'].values,
                       fee_bps=args.fee_bps, slip_bps=args.slip_bps, roundtrip=True)
    ev_floor      = bps_to_frac(args.fee_bps + args.slip_bps + args.ev_margin_bps) * 2.0
    ev_floor_min  = bps_to_frac(args.ev_floor_min_bps) * 2.0
    te['cand'] = (te['ev'] >= ev_floor).astype(int); te['H_row'] = args.H

    k_map = {}
    for part in args.K_day.split(","):
        part = part.strip()
        if not part: continue
        rid, kval = part.split(":"); k_map[int(rid)] = int(kval)
    gate_in = te[['time','regime_id','H_row','ev','cand']].copy()
    gated = dynamic_theta_topk(gate_in, k_map=k_map, ev_floor=ev_floor, ev_floor_min=ev_floor_min,
                               relax_factor=args.ev_relax_factor, by_regime=True)
    te = te.join(gated[['entry_flag','theta_used','ev_floor_used']], how='left')
    te['entry_flag'] = te['entry_flag'].fillna(0).astype(int)

    ok_cov, cov = enforce_qa(te, min_cov=0.02, max_cov=0.6); trades = int(te['entry_flag'].sum())
    log.log({"coverage": cov, "trades": trades, "ev_floor": ev_floor, "ev_floor_min": ev_floor_min})
    if not ok_cov:
        log.log("[QA] coverage out of bounds ⇒ FAIL")
        te.to_csv(os.path.join(run_dir, "preds_test.csv"), index=False)
        with open(os.path.join(run_dir, "metrics_oos.json"), "w", encoding="utf-8") as f:
            json.dump({"coverage": cov, "trades": trades, "qa_ok": False, "reason": "coverage"}, f, indent=2)
        fail(f"Coverage {cov:.3f} is out of [0.02,0.6]. Check gating/EV floor/θ (v3.1d uses floor relaxation).")

    te['realized_gross'] = te['fret'] * te['entry_flag']
    cost_frac = (args.fee_bps + args.slip_bps)/10000.0 * 2.0
    te['realized_net'] = te['realized_gross'] - cost_frac * te['entry_flag']

    var_h = float(tr['ret1'].rolling(args.H).sum().var() or 1e-6)
    if args.size_mode == "kelly":
        te['size'] = [max(0.0, min(args.size_max, (ev/var_h)*args.kelly_shrink)) for ev in te['ev'].values]
    else:
        te['size'] = 1.0
    te['realized_net'] *= te['size']

    diag = ev_decile_monotonicity(te[te['entry_flag']==1], ev_col='ev', realized_col='realized_net', n=10)
    if diag is not None: log.log({"ev_decile": diag})

    cols = ['time','regime_id','H_row','p_long','tp_frac','sl_frac','ev','cand','ev_floor_used','theta_used','entry_flag','size','realized_gross','realized_net']
    te[cols].to_csv(os.path.join(run_dir, "preds_test.csv"), index=False)
    with open(os.path.join(run_dir, "metrics_oos.json"), "w", encoding="utf-8") as f:
        json.dump({
            "H": args.H, "fee_bps": args.fee_bps, "slip_bps": args.slip_bps,
            "ev_floor": ev_floor, "ev_floor_min": ev_floor_min, "ev_relax_factor": args.ev_relax_factor,
            "coverage": cov, "trades": trades,
            "pnl_sum": float(te.loc[te['entry_flag']==1, 'realized_net'].sum()),
            "qa_ok": True
        }, f, indent=2)
    print(json.dumps({"coverage": cov, "trades": trades, "qa_ok": True}, indent=2))

if __name__ == "__main__":
    main()


import argparse, json, os
import numpy as np, pandas as pd
from trend4p.utils import parse_time, compute_basic_features, future_return
from trend4p.calibrate import bin_calibrate_prob, apply_bin_calibration
from trend4p.ev import ev_long, kelly_fraction, bps_to_frac
from trend4p.gating import dynamic_theta_topk, enforce_qa

def sigmoid(x): return 1/(1+np.exp(-x))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True)
    ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True)
    ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=15)
    ap.add_argument("--fee_bps", type=float, default=1.0)
    ap.add_argument("--slip_bps", type=float, default=0.5)
    ap.add_argument("--out_dir", type=str, default="_out_4u")
    ap.add_argument("--size_mode", choices=["none","kelly"], default="kelly")
    ap.add_argument("--kelly_shrink", type=float, default=0.25)
    ap.add_argument("--size_max", type=float, default=0.5)
    ap.add_argument("--K_day", type=str, default="0:5,1:10,2:20")
    ap.add_argument("--ev_margin_bps", type=float, default=1.0)
    args = ap.parse_args()

    os.makedirs(os.path.join(args.out_dir, "run"), exist_ok=True)

    df = pd.read_csv(args.data)
    df = parse_time(df)
    df = df.set_index('time').sort_index().loc[args.train_start:args.test_end].reset_index()
    df = compute_basic_features(df)
    df = future_return(df, args.H)

    tr = df[(df['time']>=pd.Timestamp(args.train_start, tz='UTC')) & (df['time']<=pd.Timestamp(args.train_end, tz='UTC'))].copy()
    te = df[(df['time']>=pd.Timestamp(args.test_start, tz='UTC')) & (df['time']<=pd.Timestamp(args.test_end, tz='UTC'))].copy()

    x_tr = (tr['mom']/(tr['vol']+1e-8)).clip(-10,10).fillna(0.0)
    x_te = (te['mom']/(te['vol']+1e-8)).clip(-10,10).fillna(0.0)
    tr['p_raw'] = sigmoid(x_tr.values); te['p_raw'] = sigmoid(x_te.values)

    mapping, _ = bin_calibrate_prob(tr['p_raw'].values, (tr['fret']>0).astype(int).values, n_bins=10)
    te['p_long'] = apply_bin_calibration(te['p_raw'].values, mapping)

    vol_scale = (tr['vol'].median() + te['vol'].median())/2.0
    tp_frac = (te['vol'].clip(1e-8)/max(vol_scale,1e-8)) * (args.H**0.5) * 0.002
    sl_frac = tp_frac.copy()
    te['tp_frac'], te['sl_frac'] = tp_frac.values, sl_frac.values

    te['ev'] = ev_long(te['p_long'].values, te['tp_frac'].values, te['sl_frac'].values,
                       fee_bps=args.fee_bps, slip_bps=args.slip_bps, roundtrip=True)
    ev_floor = bps_to_frac(args.fee_bps + args.slip_bps + args.ev_margin_bps) * 2.0
    te['cand'] = (te['ev'] >= ev_floor).astype(int)
    te['H_row'] = args.H

    k_map = {}
    for part in args.K_day.split(","):
        if not part.strip(): continue
        rid,k = part.split(":"); k_map[int(rid)] = int(k)

    gated = dynamic_theta_topk(te[['time','regime_id','H_row','ev','cand']].copy(), k_map=k_map, ev_floor=ev_floor, by_regime=True)
    te = te.join(gated[['entry_flag','theta_used']], how='left')

    # realized
    te['realized_gross'] = te['fret'] * te['entry_flag'].fillna(0)
    cost_frac = (args.fee_bps + args.slip_bps)/10000.0 * 2.0
    te['realized_net'] = te['realized_gross'] - cost_frac * te['entry_flag'].fillna(0)

    # sizing
    var_h = max(1e-10, tr['ret1'].rolling(args.H).sum().var())
    if args.size_mode == "kelly":
        te['size'] = [kelly_fraction(ev=v, var=var_h, shrink=args.kelly_shrink, size_max=args.size_max) for v in te['ev'].values]
    else:
        te['size'] = 1.0
    te['realized_net'] = te['realized_net'] * te['size']
    te['gross_event'], te['net_event'] = te['realized_gross'], te['realized_net']

    ok, cov = enforce_qa(te, min_cov=0.02, max_cov=0.6)
    m = {
        "coverage": float(cov),
        "n_trades": int(te['entry_flag'].sum()),
        "pnl_sum": float(te.loc[te['entry_flag']==1, 'realized_net'].sum()),
        "qa_ok": bool(ok)
    }

    out = os.path.join(args.out_dir, "run"); os.makedirs(out, exist_ok=True)
    cols = ['time','regime_id','H_row','p_long','tp_frac','sl_frac','ev','cand','theta_used','entry_flag','size','gross_event','net_event']
    te[cols].to_csv(os.path.join(out, "preds_test.csv"), index=False)
    with open(os.path.join(out, "metrics_oos.json"), "w", encoding="utf-8") as f:
        json.dump(m, f, indent=2)
    print(json.dumps(m, indent=2))

if __name__ == "__main__":
    main()

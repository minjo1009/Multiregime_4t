
import os, json, argparse, pandas as pd, numpy as np
from trend4p.execution_4u import run_pipeline, save_outputs
from trend4p.metrics_4u import trade_metrics, monthly_breakdown
from trend4p.utils_4u import find_time_col, to_datetime_utc

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--train_start", required=True)
    p.add_argument("--train_end", required=True)
    p.add_argument("--test_start", required=True)
    p.add_argument("--test_end", required=True)
    p.add_argument("--H", type=int, default=15)
    p.add_argument("--fee_bps", type=float, default=1.0)
    p.add_argument("--slip_bps", type=float, default=0.5)
    p.add_argument("--out_dir", default="_out_4u")
    args = p.parse_args()

    # Config defaults (Phase 1–2)
    cfg = {
        "topK_per_day": 5,
        "size_max": 1.0,
        "fee_bps": args.fee_bps,
        "slip_bps": args.slip_bps,
    }

    df = pd.read_csv(args.data)
    tcol = find_time_col(df)
    df["time"] = to_datetime_utc(df[tcol])
    df = df.sort_values("time").reset_index(drop=True)

    # Split
    train = df[(df["time"]>=args.train_start) & (df["time"]<args.train_end)].copy()
    test  = df[(df["time"]>=args.test_start) & (df["time"]<args.test_end)].copy()

    # Fit steps that need train can be added here (e.g., calibration fit). For now, use OOF inside estimator.

    # Run on test
    full, preds = run_pipeline(test, H=args.H, cfg=cfg)

    # Metrics on executed trades
    trades = preds.copy()
    # Need gross/net/events aligned; already in preds
    m = trade_metrics(trades)
    m_monthly = monthly_breakdown(trades)

    # Save outputs
    run_dir = os.path.join(args.out_dir, "run")
    preds_path = save_outputs(preds, run_dir)

    metrics = {
        "H": args.H,
        "fee_bps": args.fee_bps, "slip_bps": args.slip_bps,
        "topK_per_day": cfg["topK_per_day"],
        "test": {"start": args.test_start, "end": args.test_end},
        "summary": m,
        "monthly": m_monthly,
        "viewer_schema": "v2-monthly"  # for viewer
    }
    with open(os.path.join(run_dir, "metrics_oos.json"), "w") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    print("Saved:", preds_path)

if __name__ == "__main__":
    main()


import numpy as np
import pandas as pd

def topk_per_day(ev: pd.Series, entry_flag: pd.Series, time: pd.Series, K: int) -> pd.Series:
    """Select Top-K entries per day by EV (desc). entry_flag acts as base eligibility (1/0)."""
    if K <= 0:
        return (entry_flag.astype(int) & (ev >= 0)).astype(int)
    df = pd.DataFrame({"ev":ev, "flag":entry_flag.astype(int), "time":pd.to_datetime(time, utc=True)})
    df["day"] = df["time"].dt.strftime("%Y-%m-%d")
    take = pd.Series(0, index=ev.index, dtype=int)
    for d, grp in df.groupby("day"):
        g = grp[grp["flag"]==1].sort_values("ev", ascending=False).head(K)
        take.loc[g.index] = 1
    return take

def remove_overlap(take: pd.Series, H: int) -> pd.Series:
    """Prevent overlapping entries within H minutes. Greedy keep highest ev in window."""
    idx = take.index
    ts = pd.to_datetime(idx, utc=True, errors="coerce")
    order = np.argsort(ts.values.astype('datetime64[ns]'))
    keep = take.copy()
    last_entry_time = None
    for i in order:
        if take.iloc[i] != 1: continue
        t = ts[i]
        if last_entry_time is None or (t - last_entry_time) >= np.timedelta64(H, "m"):
            last_entry_time = t
            continue
        # overlap -> drop the current one (could add EV-based choice if ev available)
        keep.iloc[i] = 0
    return keep


import numpy as np
import pandas as pd

REQ_TIME_NAMES = ["time", "timestamp", "open_time", "date"]

def to_datetime_utc(s):
    # Accept int epoch seconds/ms, or string; return pandas.Timestamp[UTC]
    if pd.api.types.is_integer_dtype(s) or pd.api.types.is_float_dtype(s):
        # assume seconds -> ns
        return pd.to_datetime(s, unit="s", utc=True, errors="coerce")
    try:
        dt = pd.to_datetime(s, utc=True, errors="coerce")
        return dt
    except Exception:
        return pd.Series([pd.NaT]*len(s), dtype='datetime64[ns, UTC]')

def find_time_col(df):
    for c in df.columns:
        if c.lower() in REQ_TIME_NAMES:
            return c
    raise ValueError(f"Time column not found. Tried: {REQ_TIME_NAMES}")

def ensure_cols(df, cols):
    miss = [c for c in cols if c not in df.columns]
    if miss:
        raise ValueError(f"Missing columns: {miss}")

def mcc(tp, tn, fp, fn):
    denom = (tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
    if denom == 0:
        return 0.0
    return ((tp*tn - fp*fn) / np.sqrt(denom))

def month_str(ts: pd.Timestamp) -> str:
    ts = ts.tz_convert("UTC") if ts.tzinfo else ts.tz_localize("UTC")
    return f"{ts.year}-{ts.month:02d}"

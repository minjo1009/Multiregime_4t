
import numpy as np
import pandas as pd
from .expansion_4u import expected_range
from .calibrate_4u import oof_calibrate

def sigmoid(x):
    return 1/(1+np.exp(-x))

def build_raw_score(df: pd.DataFrame) -> np.ndarray:
    """Cheap raw directional score: momentum + OF.
    This is a placeholder to be replaced by your real model."""
    s = (
        2.0*np.tanh(50*df["mom"].fillna(0.0)) +
        0.5*np.tanh( df["cvd_z"].fillna(0.0) ) +
        0.5*np.tanh( df["vol_z"].fillna(0.0) )
    )
    return s.to_numpy()

def estimate_ev(df: pd.DataFrame, H: int, fee_bps: float = 0.0, slip_bps: float = 0.0) -> pd.Series:
    """Estimate EV per bar for horizon H (minutes)."""
    raw = build_raw_score(df)
    # proxy for probability hit: map raw score -> [0,1]
    p = sigmoid(raw)
    # expected expansion (absolute move fraction) for H
    exp_rng = expected_range(df, H)
    # rough TP/SL symmetry
    TP = exp_rng
    SL = exp_rng * 0.8  # asymmetric to penalize downside a bit less optimistic
    fees = (fee_bps + slip_bps)/10000.0
    ev0 = p*TP - (1-p)*SL - fees
    # OOF calibrate EV against realized next-H return sign * abs(move)
    # For skeleton, we use a naive target: realized |ret_{t→t+H}| * sign(ret)
    close_c = [c for c in df.columns if c.lower() in ["close","price","px","last","c"]]
    if not close_c:
        return pd.Series(ev0, index=df.index, name="ev_final")
    px = df[close_c[0]].astype(float)
    future = (px.shift(-H) / px - 1.0)
    y = future.fillna(0.0).to_numpy()
    # target for calibration = realized value proxy
    target = y
    ev_cal = oof_calibrate(ev0.astype(float), target.astype(float))
    return pd.Series(ev_cal, index=df.index, name="ev_final")

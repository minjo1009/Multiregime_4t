
import numpy as np, pandas as pd

def bin_map(p, y, n_bins=10):
    p = np.asarray(p, float); y = np.asarray(y, float)
    if p.size==0: 
        return (np.array([0.0,1.0]), np.array([0.5]))
    qs = np.linspace(0,1,n_bins+1)
    edges = np.quantile(p, qs)
    edges[0], edges[-1] = 0.0, 1.0
    val = np.zeros(n_bins)
    for i in range(n_bins):
        lo, hi = edges[i], edges[i+1]+1e-9
        m = (p>=lo)&(p<hi)
        val[i] = y[m].mean() if m.any() else y.mean() if y.size else 0.5
    # monotonic enforce
    for i in range(1,n_bins):
        if val[i] < val[i-1]: val[i] = val[i-1]
    return edges, val

def apply_bin_map(p, mapping):
    edges, val = mapping
    p = np.asarray(p, float); out = np.empty_like(p)
    for i in range(len(val)):
        lo, hi = edges[i], edges[i+1]+1e-9
        m = (p>=lo)&(p<hi)
        if m.any(): out[m] = val[i]
    out[p>=edges[-1]] = val[-1]
    return np.clip(out,0,1)

def build_sr_calibration(df, p_col, y_col, key_cols=('sess','regime_id'), n_bins=10):
    maps = {}
    g = df.groupby(list(key_cols), dropna=False)
    for key, gd in g:
        p = gd[p_col].values; y = gd[y_col].astype(int).values
        maps[key] = bin_map(p,y,n_bins=n_bins)
    return maps

def apply_sr_calibration(df, p_col, out_col, maps, key_cols=('sess','regime_id')):
    out = df.copy()
    out[out_col] = 0.5
    g = out.groupby(list(key_cols), dropna=False)
    for key, idx in g.groups.items():
        m = maps.get(key, None)
        if m is None: 
            out.loc[idx, out_col] = out.loc[idx, p_col].values
        else:
            out.loc[idx, out_col] = apply_bin_map(out.loc[idx, p_col].values, m)
    return out

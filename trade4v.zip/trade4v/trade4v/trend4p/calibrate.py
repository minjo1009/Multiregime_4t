
import numpy as np
def bin_calibrate_prob(p, y, n_bins=10, eps=1e-9):
    p = np.asarray(p, float); y = np.asarray(y, float)
    if p.size == 0:
        return (np.array([0.0, 1.0]), np.array([0.5])), p
    qs = np.linspace(0, 1, n_bins+1)
    edges = np.quantile(p, qs)
    edges[0], edges[-1] = 0.0, 1.0
    val = np.zeros(n_bins); out = np.zeros_like(p)
    for i in range(n_bins):
        lo, hi = edges[i], edges[i+1] + eps
        m = (p >= lo) & (p < hi)
        val[i] = y[m].mean() if m.any() else y.mean()
        out[m] = val[i]
    for i in range(1, n_bins):
        if val[i] < val[i-1]: val[i] = val[i-1]
    for i in range(n_bins):
        lo, hi = edges[i], edges[i+1] + eps
        m = (p >= lo) & (p < hi); out[m] = val[i]
    out[p >= edges[-1]] = val[-1]
    return (edges, val), np.clip(out, 0, 1)
def apply_bin_calibration(p, mapping):
    edges, val = mapping; p = np.asarray(p, float); out = np.empty_like(p)
    for i in range(len(val)):
        lo, hi = edges[i], edges[i+1] + 1e-9; m = (p >= lo) & (p < hi)
        if m.any(): out[m] = val[i]
    out[p >= edges[-1]] = val[-1]; return np.clip(out, 0, 1)

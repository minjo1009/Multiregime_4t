
import numpy as np, pandas as pd

def parse_time(df):
    for c in ['time','open_time','timestamp','date']:
        if c in df.columns:
            df['time'] = pd.to_datetime(df[c], utc=True); return df
    raise ValueError("No time column found.")

def compute_basic_features(df):
    df = df.sort_values('time').copy()
    px = (df['close'] if 'close' in df.columns else (df['price'] if 'price' in df.columns else df.select_dtypes('number').iloc[:,0])).astype(float)
    df['ret1'] = np.log(px).diff().fillna(0.0)
    df['vol']  = df['ret1'].rolling(60, min_periods=10).std().bfill().fillna(0.0)
    df['mom']  = np.log(px).diff(10).fillna(0.0)
    q1,q2 = df['vol'].quantile([0.33,0.66])
    df['regime_id'] = (df['vol']>q2).astype(int)*2 + ((df['vol']>q1)&(df['vol']<=q2)).astype(int)
    return df

def future_return(df, H):
    df = df.copy(); df['fret'] = df['ret1'].rolling(H, min_periods=1).sum().shift(-H).fillna(0.0); return df

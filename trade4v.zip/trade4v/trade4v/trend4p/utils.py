
import numpy as np, pandas as pd

SESS_LABELS = {0:"ASIA",1:"EU",2:"US"}

def parse_time(df):
    for c in ['time','open_time','timestamp','date']:
        if c in df.columns:
            df['time'] = pd.to_datetime(df[c], utc=True)
            return df
    raise ValueError("No time-like column. Expected one of: time/open_time/timestamp/date")

def infer_price(df):
    for c in ['close','price','last','Close','CLOSE']:
        if c in df.columns: return df[c].astype(float).values
    c = df.select_dtypes('number').columns[0]
    return df[c].astype(float).values

def add_basic_features(df):
    df = df.sort_values('time').copy()
    px = infer_price(df)
    df['ret1'] = np.append([0.0], np.diff(np.log(px)))
    df['vol']  = pd.Series(df['ret1']).rolling(60, min_periods=10).std().bfill().fillna(0.0).values
    df['mom']  = pd.Series(np.append([0.0]*10, np.diff(np.log(px), n=10))).fillna(0.0).values

    # ---- safe session labeling (no duplicated labels in pd.cut) ----
    hr = df['time'].dt.hour.astype(int)
    idx = pd.cut(hr, bins=[-1, 7, 13, 22, 24], labels=False, include_lowest=True, right=True)
    codes = pd.Series(idx).astype('Int64').fillna(2).to_numpy()
    sess_map = np.array([0, 1, 2, 2], dtype=int)  # 0:ASIA,1:EU,2:US,3->US(2)
    df['sess'] = sess_map[codes]

    # ---- regime: volatility tertiles -> {0,1,2} ----
    q1, q2 = df['vol'].quantile([0.33, 0.66])
    df['regime_id'] = (df['vol']>q2).astype(int)*2 + ((df['vol']>q1)&(df['vol']<=q2)).astype(int)
    return df

def future_return(df, H):
    df = df.copy()
    df['fret'] = pd.Series(df['ret1']).rolling(H, min_periods=1).sum().shift(-H).fillna(0.0).values
    return df

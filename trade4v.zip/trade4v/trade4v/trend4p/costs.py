
def dynamic_cost_bps(fee_bps, slip_bps, sess, mult_asia=1.3, mult_eu=1.1, mult_us=1.0):
    mult = {0:mult_asia, 1:mult_eu, 2:mult_us}.get(int(sess), 1.0)
    return float(fee_bps) + float(slip_bps) * mult

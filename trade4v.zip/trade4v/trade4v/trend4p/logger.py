
import json, os, datetime
class RunLogger:
    def __init__(self, path):
        self.path = path; os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, 'w', encoding='utf-8') as f:
            f.write(f'# Log started {datetime.datetime.utcnow().isoformat()}Z\n')
    def log(self, msg):
        with open(self.path, 'a', encoding='utf-8') as f:
            f.write(str(msg) + "\n")
    def dump_json(self, obj, name):
        p = os.path.join(os.path.dirname(self.path), name)
        with open(p, 'w', encoding='utf-8') as f:
            json.dump(obj, f, indent=2)
        self.log(f'[json] {name} -> written'); return p

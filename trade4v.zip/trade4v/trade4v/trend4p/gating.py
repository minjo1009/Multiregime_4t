
import numpy as np, pandas as pd

def _solve_theta_for_k(ev_series, K):
    """Return theta so that number of entries ~= K (take K-th value)."""
    if K <= 0 or ev_series.empty: return np.nan
    ev_sorted = ev_series.sort_values(ascending=False)
    K = min(K, len(ev_sorted))
    return float(ev_sorted.iloc[K-1])

def dynamic_theta_topk(df, k_map, ev_floor=0.0, by_regime=True):
    """Per (day, regime) choose Top-K by EV. Apply EV floor first. 
    Returns df with 'theta_used' and 'entry_flag' (0/1). Maintains original index.
    Expects columns: time, ev, cand(0/1), optional: regime_id, H_row
    """
    out = df.copy()
    if 'cand' not in out.columns: out['cand'] = 1
    out['date'] = out['time'].dt.floor('D')
    out['entry_flag'] = 0; out['theta_used'] = np.nan

    if by_regime and 'regime_id' in out.columns:
        group_cols = ['date','regime_id']
    else:
        out['regime_id'] = 0
        group_cols = ['date','regime_id']

    def _apply(g):
        rid = int(g['regime_id'].iat[0])
        K = int(k_map.get(rid, 0))
        cand = g[(g['cand']==1) & (g['ev'] >= ev_floor)]
        if K <= 0 or cand.empty:
            g['theta_used'] = np.nan; g['entry_flag'] = 0; return g
        theta = _solve_theta_for_k(cand['ev'], K)
        g['theta_used'] = theta
        g['entry_flag'] = ((g['ev'] >= theta) & (g['cand']==1)).astype(int)
        return g

    out = out.groupby(group_cols, group_keys=False).apply(_apply)

    # De-overlap per regime: prevent new entry before last exit for same regime
    if 'H_row' in out.columns:
        out = out.sort_values('time')
        last_exit = {}
        keep_mask = []
        for idx, r in out.iterrows():
            rid = int(r.get('regime_id', 0))
            ok = True
            if r['entry_flag'] == 1:
                ex = r['time'] + pd.Timedelta(minutes=int(r['H_row']))
                if rid in last_exit and r['time'] < last_exit[rid]:
                    ok = False
                if ok: last_exit[rid] = ex
            keep_mask.append(ok if r['entry_flag']==1 else True)
        out['entry_flag'] = out['entry_flag'] * pd.Series(keep_mask, index=out.index).astype(int)
    return out

def enforce_qa(out, min_cov=0.02, max_cov=0.6):
    """Return (ok, coverage). Coverage is fraction of bars with entry=1."""
    n = len(out)
    cov = float(out['entry_flag'].sum()) / float(max(1, n))
    ok = (cov >= min_cov) and (cov <= max_cov)
    return ok, cov

def ev_decile_monotonicity(df, ev_col='ev', realized_col='realized_net', n=10):
    d = df[[ev_col, realized_col]].dropna().sort_values(ev_col)
    if d.empty: return None
    d['dec'] = pd.qcut(d[ev_col], n, labels=False, duplicates='drop')
    tab = d.groupby('dec')[realized_col].mean()
    mono = (tab.diff().dropna() >= 0).all()
    return {'monotone_nondec': bool(mono), 'dec_means': tab.tolist()}

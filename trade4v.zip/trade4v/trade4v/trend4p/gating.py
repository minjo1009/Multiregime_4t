
import numpy as np, pandas as pd

def spacing_greedy_topk(df, K, H_bars, min_gap_bars=0, mode='cap', max_concurrent=1,
                         pyr_ev_step=0.0):
    if len(df)==0 or K<=0: return []
    d = df.sort_values('ev', ascending=False).reset_index(drop=True)
    selected = []
    active_until = []  # (end_idx, ev)
    for _, row in d.iterrows():
        t = int(row['idx'])
        ev = float(row['ev'])
        # expire
        active_until = [x for x in active_until if x[0] > t]
        ok = True
        if mode in ('cap','pyramid'):
            if len(selected)>0 and (t - selected[-1]) < min_gap_bars:
                ok = False
            if len(active_until) >= max_concurrent:
                if mode=='pyramid':
                    best_ev = max([e for _,e in active_until]) if active_until else -1e9
                    if ev >= best_ev + pyr_ev_step:
                        ok = True
                    else:
                        ok = False
                else:
                    ok = False
        if ok:
            selected.append(t)
            active_until.append((t + H_bars, ev))
        if len(selected) >= K: break
    return selected

def day_regime_topk_spacing(frame, k_map, H_bars, min_gap_bars=0,
                             overlap_mode='cap', max_concurrent=1, pyr_ev_step=0.0):
    out = frame.copy()
    out['entry_flag'] = 0; out['theta_used'] = np.nan
    g = out.groupby(['date','regime_id'], sort=False, group_keys=False)
    def _apply(gd):
        rid = int(gd['regime_id'].iat[0]) if 'regime_id' in gd.columns else 0
        K = int(k_map.get(rid, 0))
        pool = gd[gd['cand']==1][['ev']].copy()
        pool['idx'] = gd.index
        sel_idx = spacing_greedy_topk(pool, K, H_bars=H_bars, min_gap_bars=min_gap_bars,
                                      mode=overlap_mode, max_concurrent=max_concurrent,
                                      pyr_ev_step=pyr_ev_step)
        if len(sel_idx)>0:
            gd.loc[sel_idx, 'entry_flag'] = 1
            gd.loc[sel_idx, 'theta_used']  = float(gd.loc[sel_idx, 'ev'].min())
        return gd
    out = g.apply(_apply)
    return out

def enforce_qa(out, min_cov=0.02, max_cov=0.6):
    n = len(out); cov = float(out['entry_flag'].sum())/float(max(1,n))
    return (min_cov <= cov <= max_cov), cov

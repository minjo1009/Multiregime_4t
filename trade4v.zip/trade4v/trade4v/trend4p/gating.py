
import numpy as np
import pandas as pd

def dynamic_theta_topk(df, k_map, ev_floor=0.0, by_regime=True):
    if 'cand' not in df.columns: df['cand'] = 1
    out = df.copy()
    out['date'] = out['time'].dt.floor('D')
    out['entry_flag'] = 0
    out['theta_used'] = np.nan
    group_cols = ['date','regime_id'] if (by_regime and 'regime_id' in out.columns) else ['date']

    def _select(g):
        K = k_map.get(int(g['regime_id'].iat[0]), 0) if 'regime_id' in g.columns else list(k_map.values())[0]
        c = g[(g['cand']==1) & (g['ev']>=ev_floor)].sort_values('ev', ascending=False)
        if K <= 0 or c.empty:
            g['theta_used'] = np.nan; g['entry_flag'] = 0; return g
        top = c.head(K); theta = float(top['ev'].min())
        g['theta_used'] = theta
        g['entry_flag'] = ((g['ev'] >= theta) & (g['cand']==1)).astype(int)
        return g

    out = out.groupby(group_cols, group_keys=False).apply(_select)

    # overlap prevention per regime
    if 'H_row' in out.columns:
        out = out.sort_values('time')
        last_exit, keep = {}, []
        for i, r in out.iterrows():
            rid = int(r.get('regime_id', 0))
            ex = r['time'] + pd.Timedelta(minutes=int(r['H_row']))
            ok = True
            if r['entry_flag'] == 1:
                if rid in last_exit and r['time'] < last_exit[rid]: ok = False
                if ok: last_exit[rid] = ex
            keep.append(ok if r['entry_flag']==1 else True)
        out['entry_flag'] = out['entry_flag'] * pd.Series(keep, index=out.index).astype(int)
    return out

def enforce_qa(out, min_cov=0.02, max_cov=0.6):
    n = len(out); cov = out['entry_flag'].sum() / max(1, n)
    return ((cov >= min_cov) and (cov <= max_cov)), cov

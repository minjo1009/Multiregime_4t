
import numpy as np, pandas as pd

def _solve_theta_for_k(ev_series, K):
    if K <= 0 or ev_series.empty: return np.nan
    ev_sorted = ev_series.sort_values(ascending=False)
    K = min(K, len(ev_sorted))
    return float(ev_sorted.iloc[K-1])

def dynamic_theta_topk(df, k_map, ev_floor=0.0, ev_floor_min=0.0, relax_factor=0.5, by_regime=True):
    """Top-K by EV per (day, regime) with EV floor relaxation.
    Returns: entry_flag, theta_used, ev_floor_used
    Expects: time, ev, cand(0/1), optional regime_id, H_row
    """
    out = df.copy()
    if 'cand' not in out.columns: out['cand'] = 1
    out['date'] = out['time'].dt.floor('D')
    out['entry_flag'] = 0; out['theta_used'] = np.nan; out['ev_floor_used'] = np.nan

    if by_regime and 'regime_id' in out.columns:
        group_cols = ['date','regime_id']
    else:
        out['regime_id'] = 0
        group_cols = ['date','regime_id']

    def _apply(g):
        rid = int(g['regime_id'].iat[0])
        K = int(k_map.get(rid, 0))
        floor = float(ev_floor)
        theta = np.nan; used_floor = floor; idx = []

        while True:
            cand = g[(g['cand']==1) & (g['ev'] >= floor)].sort_values('ev', ascending=False)
            if K > 0 and len(cand) >= K:
                top = cand.head(K)
                theta = float(top['ev'].min()); used_floor = floor
                idx = list(top.index)
                break
            new_floor = max(ev_floor_min, floor * relax_factor)
            if new_floor >= floor - 1e-12:
                cand_all = g[(g['cand']==1)].sort_values('ev', ascending=False)
                top = cand_all.head(min(K, len(cand_all))) if len(cand_all)>0 else g.sort_values('ev', ascending=False).head(min(K, len(g)))
                theta = float(top['ev'].min()) if len(top)>0 else np.nan
                idx = list(top.index) if len(top)>0 else []
                used_floor = floor
                break
            floor = new_floor

        g['theta_used'] = theta
        g['ev_floor_used'] = used_floor
        if len(idx)>0: g.loc[idx, 'entry_flag'] = 1
        else: g['entry_flag'] = 0
        return g

    gb = out.groupby(group_cols, group_keys=False)
    try:
        out = gb.apply(_apply, include_groups=False)  # pandas>=2.2
    except TypeError:
        out = gb.apply(_apply)  # older pandas

    # De-overlap per regime
    if 'H_row' in out.columns:
        out = out.sort_values('time')
        last_exit = {}
        keep = []
        for idx, r in out.iterrows():
            rid = int(r.get('regime_id', 0))
            ok = True
            if r['entry_flag'] == 1:
                ex = r['time'] + pd.Timedelta(minutes=int(r['H_row']))
                if rid in last_exit and r['time'] < last_exit[rid]:
                    ok = False
                if ok: last_exit[rid] = ex
            keep.append(ok if r['entry_flag']==1 else True)
        out['entry_flag'] = out['entry_flag'] * pd.Series(keep, index=out.index).astype(int)
    return out

def enforce_qa(out, min_cov=0.02, max_cov=0.6):
    n = len(out); cov = float(out['entry_flag'].sum()) / float(max(1, n))
    ok = (cov >= min_cov) and (cov <= max_cov)
    return ok, cov

def ev_decile_monotonicity(df, ev_col='ev', realized_col='realized_net', n=10):
    d = df[[ev_col, realized_col]].dropna().sort_values(ev_col)
    if d.empty: return None
    d['dec'] = pd.qcut(d[ev_col], n, labels=False, duplicates='drop')
    tab = d.groupby('dec')[realized_col].mean()
    mono = (tab.diff().dropna() >= 0).all()
    return {'monotone_nondec': bool(mono), 'dec_means': tab.tolist()}

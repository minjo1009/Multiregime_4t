
import numpy as np
import pandas as pd

def horizon_return(df: pd.DataFrame, H: int, price_col: str = None) -> pd.Series:
    close_c = [c for c in df.columns if c.lower() in ["close","price","px","last","c"]]
    if not close_c and price_col:
        close_c = [price_col]
    if not close_c:
        raise ValueError("No price/close column found for horizon return.")
    px = df[close_c[0]].astype(float)
    fut = (px.shift(-H) / px - 1.0)
    return fut.rename("gross_event")

def apply_costs(gross: pd.Series, fee_bps: float, slip_bps: float) -> pd.Series:
    costs = (fee_bps + slip_bps)/10000.0
    return (gross - costs).rename("net_event")


import numpy as np
import pandas as pd
from .utils_4u import to_datetime_utc, find_time_col

def add_basic_features(df: pd.DataFrame) -> pd.DataFrame:
    """Add returns, rolling means, vol; attempt to detect close/price."""
    out = df.copy()
    # infer price column
    price_cols = [c for c in out.columns if c.lower() in ["close","price","px","last","c"]]
    if not price_cols:
        # fallback: use 'open' if exists
        price_cols = [c for c in out.columns if c.lower() in ["open","o"]]
    if not price_cols:
        raise ValueError("No price/close column found")
    px = out[price_cols[0]].astype(float)
    out["ret1"] = px.pct_change().fillna(0.0)
    out["ret5"] = px.pct_change(5).fillna(0.0)
    out["ma_fast"] = px.rolling(12, min_periods=1).mean()
    out["ma_slow"] = px.rolling(60, min_periods=1).mean()
    out["mom"] = (out["ma_fast"] - out["ma_slow"]) / out["ma_slow"].replace(0, np.nan)
    out["vol1"] = out["ret1"].rolling(60, min_periods=10).std().fillna(method="bfill").fillna(0.0)
    out["vol5"] = out["ret1"].rolling(300, min_periods=50).std().fillna(method="bfill").fillna(0.0)
    # volume / orderflow proxies
    vol_cols = [c for c in out.columns if c.lower() in ["volume","vol","base_volume","quote_volume","v"]]
    if vol_cols:
        v = out[vol_cols[0]].astype(float).fillna(0.0)
        out["vol_z"] = ((v - v.rolling(240, min_periods=30).mean()) / (v.rolling(240, min_periods=30).std() + 1e-9)).fillna(0.0)
    # imbalance (if bid/ask available)
    bid_cols = [c for c in out.columns if "bid" in c.lower() and "qty" in c.lower()]
    ask_cols = [c for c in out.columns if "ask" in c.lower() and "qty" in c.lower()]
    if bid_cols and ask_cols:
        b = out[bid_cols[0]].astype(float).fillna(0.0)
        a = out[ask_cols[0]].astype(float).fillna(0.0)
        out["imbalance"] = (b - a) / (b + a + 1e-9)
    else:
        out["imbalance"] = 0.0
    # cumulative volume delta proxy: sign(ret1)*volume
    if vol_cols:
        v = out[vol_cols[0]].astype(float).fillna(0.0)
        out["cvd"] = (np.sign(out["ret1"]).fillna(0.0) * v).cumsum()
        out["cvd_z"] = ((out["cvd"] - out["cvd"].rolling(240, min_periods=30).mean()) / (out["cvd"].rolling(240, min_periods=30).std() + 1e-9)).fillna(0.0)
    else:
        out["cvd_z"] = 0.0
    # sessions
    # ensure time index
    tcol = find_time_col(out)
    t = to_datetime_utc(out[tcol])
    out["_hour"] = t.dt.hour
    out["session_seoul"] = pd.cut(out["_hour"], bins=[-1,9,16,23], labels=[0,1,2]).astype(int)  # rough
    return out


import numpy as np

class IsotonicCalibrator:
    """Lightweight monotonic regression (PAV).
    Fits mapping from score -> y (realized outcome), piecewise-constant monotone non-decreasing."""
    def __init__(self):
        self.x_ = None
        self.y_ = None

    def fit(self, scores: np.ndarray, y: np.ndarray):
        idx = np.argsort(scores)
        x = np.asarray(scores, float)[idx]
        y = np.asarray(y, float)[idx]
        # PAV
        v = y.copy()
        w = np.ones_like(v)
        i = 0
        while i < len(v)-1:
            if v[i] > v[i+1]:
                j = i
                while j >= 0 and v[j] > v[j+1]:
                    new_w = w[j] + w[j+1]
                    new_v = (w[j]*v[j] + w[j+1]*v[j+1]) / new_w
                    v[j] = new_v
                    w[j] = new_w
                    # remove block j+1
                    v = np.delete(v, j+1)
                    w = np.delete(w, j+1)
                    x = np.delete(x, j+1)
                    if j > 0: j -= 1
                    else: break
                i = max(j, 0)
            else:
                i += 1
        # store step points
        self.x_ = x
        self.y_ = v
        return self

    def transform(self, scores: np.ndarray) -> np.ndarray:
        if self.x_ is None:
            return np.asarray(scores, float)
        s = np.asarray(scores, float)
        # piecewise-constant via rightmost <=
        out = np.empty_like(s, float)
        for k, val in enumerate(s):
            j = np.searchsorted(self.x_, val, side="right") - 1
            j = max(0, min(j, len(self.y_)-1))
            out[k] = self.y_[j]
        return out

def oof_calibrate(scores: np.ndarray, y: np.ndarray, n_folds: int = 5, seed: int = 42) -> np.ndarray:
    """Out-of-fold calibration to reduce look-ahead/overfit bias."""
    rng = np.random.default_rng(seed)
    n = len(scores)
    idx = np.arange(n)
    rng.shuffle(idx)
    folds = np.array_split(idx, n_folds)
    oof = np.zeros(n)
    for f in folds:
        tr = np.setdiff1d(idx, f, assume_unique=False)
        cal = IsotonicCalibrator().fit(scores[tr], y[tr])
        oof[f] = cal.transform(scores[f])
    return oof


import numpy as np, pandas as pd

def make_range_targets(df, H):
    r = pd.Series(df['ret1']).abs().rolling(H, min_periods=5).sum().shift(-H).bfill().fillna(0.0)
    return r.values

def fit_quantile_tables(df, key_cols=('sess','regime_id'), H=15, quantiles=(0.6,0.9)):
    df = df.copy()
    df['range_H'] = make_range_targets(df, H)
    tables = {}
    g = df.groupby(list(key_cols), dropna=False)
    for key, gd in g:
        qs = np.quantile(gd['range_H'].values, quantiles)
        tables[key] = dict(zip(quantiles, qs))
    return tables

def apply_quantile_tables(df, tables, q_tp=0.9, q_sl=0.6, key_cols=('sess','regime_id'), eps=1e-6):
    # index-aligned Series to avoid numpy out-of-bounds when df.index is not 0..n-1
    tp = pd.Series(eps, index=df.index, dtype=float)
    sl = pd.Series(eps, index=df.index, dtype=float)
    g = df.groupby(list(key_cols), dropna=False)
    for key, idx in g.groups.items():
        tab = tables.get(key, None)
        if tab is None:
            tp.loc[idx] = df.loc[idx, 'vol'].clip(eps).values
            sl.loc[idx] = df.loc[idx, 'vol'].clip(eps).values
        else:
            tp_val = float(max(tab.get(q_tp, float(df['vol'].median())), eps))
            sl_val = float(max(tab.get(q_sl, float(df['vol'].median())), eps))
            tp.loc[idx] = tp_val
            sl.loc[idx] = sl_val
    return tp.values, sl.values

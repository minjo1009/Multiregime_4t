
import numpy as np
import pandas as pd

def expected_range(df: pd.DataFrame, H: int, price_col: str = None) -> pd.Series:
    """Simple expansion model: expected absolute move over next H minutes.
    If high/low exist, use ATR proxy; else use sigma*sqrt(H)."""
    out = pd.Series(0.0, index=df.index, name=f"exp_range_{H}")
    high_c = [c for c in df.columns if c.lower() in ["high","h"]]
    low_c = [c for c in df.columns if c.lower() in ["low","l"]]
    close_c = [c for c in df.columns if c.lower() in ["close","price","px","last","c"]]
    if not close_c and price_col:
        close_c = [price_col]
    if close_c:
        px = df[close_c[0]].astype(float)
    else:
        return out
    if high_c and low_c:
        tr = (df[high_c[0]] - df[low_c[0]]).abs()
        atr = tr.rolling(60, min_periods=10).mean().fillna(method="bfill").fillna(0.0)
        out = (atr / px.replace(0, np.nan)).fillna(0.0) * np.sqrt(max(H,1))
    else:
        ret = px.pct_change().fillna(0.0)
        sigma = ret.rolling(240, min_periods=30).std().fillna(method="bfill").fillna(0.0)
        out = sigma * np.sqrt(max(H,1))
    return out.clip(lower=0.0)

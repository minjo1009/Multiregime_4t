
import numpy as np

def bps_to_frac(bps): return float(bps) / 10000.0

def ev_long(p, tp_frac, sl_frac, fee_bps=0.0, slip_bps=0.0, roundtrip=True):
    cost = bps_to_frac(fee_bps + slip_bps)
    if roundtrip: cost *= 2.0
    p = np.asarray(p, float)
    return p * tp_frac - (1.0 - p) * sl_frac - cost

def kelly_fraction(ev, var, shrink=0.25, size_max=0.5):
    var = max(var, 1e-10)
    f = max(0.0, min(size_max, (ev/var) * shrink))
    return f

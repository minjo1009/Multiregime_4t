
import numpy as np
import pandas as pd

def kelly_half(ev: pd.Series, var: pd.Series, size_max: float = 1.0) -> pd.Series:
    """Half-Kelly: size ~ ev/var, clipped to [0, size_max]. ev, var must be positive scale."""
    v = var.clip(lower=1e-8)
    s = (ev / v) * 0.5
    return s.clip(lower=0.0, upper=size_max).fillna(0.0)

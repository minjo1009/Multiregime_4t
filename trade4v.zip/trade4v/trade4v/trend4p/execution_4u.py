
import os, json, time, math
import numpy as np
import pandas as pd
from .features_4u import add_basic_features
from .labeler_4u import horizon_return, apply_costs
from .ev_4u import estimate_ev
from .selector_4u import topk_per_day, remove_overlap
from .sizing_4u import kelly_half
from .expansion_4u import expected_range

def regime_id_series(df: pd.DataFrame) -> pd.Series:
    """Toy regime detector based on volatility + momentum."""
    vol = df["vol1"].fillna(0.0)
    mom = df["mom"].fillna(0.0)
    r = np.where(vol>vol.median(), 2, np.where(mom>0, 1, 0))
    return pd.Series(r, index=df.index, name="regime_id")

def run_pipeline(df: pd.DataFrame, H: int, cfg: dict):
    # Features
    df = add_basic_features(df)
    # Regime
    df["regime_id"] = regime_id_series(df)
    df["H_row"] = H
    # Event outcomes for realized pnl
    gross = horizon_return(df, H)
    net = apply_costs(gross, cfg.get("fee_bps",0.0), cfg.get("slip_bps",0.0))
    df["gross_event"] = gross.fillna(0.0)
    df["net_event"] = net.fillna(0.0)
    # EV estimate + calibration
    ev = estimate_ev(df, H, cfg.get("fee_bps",0.0), cfg.get("slip_bps",0.0))
    df["ev_final"] = ev.fillna(0.0)
    # Base eligibility (could be any filter; here allow all to be candidates)
    df["entry_flag"] = 1
    # Ranking-based gating (Top-K per day)
    take = topk_per_day(df["ev_final"], df["entry_flag"], df["time"], cfg.get("topK_per_day", 5))
    take = remove_overlap(take, H)
    df["entry_flag"] = take.astype(int)
    # Sizing
    var = (expected_range(df, H) ** 2).rename("var_proxy")
    df["size"] = kelly_half(df["ev_final"].abs(), var, size_max=cfg.get("size_max",1.0))
    # Trades (executed)
    trades = df[df["entry_flag"]==1].copy()
    # Snapshot outputs
    preds = trades[["time","regime_id","H_row","ev_final","entry_flag","size","gross_event","net_event"]].copy()
    # Also include non-trade rows for viewer? For now, only executed trades (lightweight).
    return df, preds

def save_outputs(preds: pd.DataFrame, out_dir: str):
    os.makedirs(out_dir, exist_ok=True)
    preds_out = os.path.join(out_dir, "preds_test.csv")
    preds.to_csv(preds_out, index=False)
    return preds_out

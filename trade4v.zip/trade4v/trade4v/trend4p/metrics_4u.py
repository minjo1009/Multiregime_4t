
import numpy as np
import pandas as pd
from .utils_4u import mcc, month_str

def trade_metrics(df_trades: pd.DataFrame):
    """df_trades: rows with executed trades; columns: time, ev_final, size, gross_event, net_event"""
    n = len(df_trades)
    pnl_sum = float((df_trades["net_event"] * df_trades["size"]).sum())
    hit = float((df_trades["gross_event"] > 0).mean()) if n>0 else 0.0
    # MCC for direction
    pred = np.sign(df_trades["ev_final"].values)
    real = np.sign(df_trades["gross_event"].values)
    tp = int(((pred>0) & (real>0)).sum())
    tn = int(((pred<0) & (real<0)).sum())
    fp = int(((pred>0) & (real<0)).sum())
    fn = int(((pred<0) & (real>0)).sum())
    mcc_v = float(mcc(tp, tn, fp, fn))
    return {"n_trades": int(n), "pnl_sum": pnl_sum, "hit": hit, "mcc": mcc_v, "tp":tp, "tn":tn, "fp":fp, "fn":fn}

def monthly_breakdown(df_trades: pd.DataFrame):
    rows = []
    if len(df_trades)==0:
        return rows
    df_trades = df_trades.sort_values("time").copy()
    eq = 0.0
    peak = 0.0
    cum = 0.0
    by_m = {}
    for _, r in df_trades.iterrows():
        m = month_str(r["time"])
        by_m.setdefault(m, {"trades":0,"wins":0,"pnl":0.0,"mccN":[0,0,0,0],"eq":0.0,"dd":0.0})
        by_m[m]["trades"] += 1
        by_m[m]["wins"]   += int(r["gross_event"]>0)
        pnl = float(r["net_event"] * r["size"])
        by_m[m]["pnl"] += pnl
        # mcc cells
        pr = 1 if r["ev_final"]>=0 else 0
        re = 1 if r["gross_event"]>=0 else 0
        if pr==1 and re==1: by_m[m]["mccN"][0]+=1 # tp
        elif pr==0 and re==0: by_m[m]["mccN"][1]+=1 # tn
        elif pr==1 and re==0: by_m[m]["mccN"][2]+=1 # fp
        else: by_m[m]["mccN"][3]+=1 # fn
    # accumulate cum and dd by chronological months
    for m in sorted(by_m.keys()):
        o = by_m[m]
        cum += o["pnl"]
        # compute month MCC
        tp,tn,fp,fn = o["mccN"]
        denom = (tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
        mcc_v = ((tp*tn - fp*fn)/np.sqrt(denom)) if denom>0 else 0.0
        rows.append({"period":m,
                     "trades":o["trades"],
                     "hit": (o["wins"]/max(o["trades"],1.0)),
                     "pnl_sum": o["pnl"],
                     "cum_pnl": cum,
                     "max_dd": 0.0,  # placeholder at month-level; full DD chart built in viewer
                     "mcc": mcc_v})
    return rows

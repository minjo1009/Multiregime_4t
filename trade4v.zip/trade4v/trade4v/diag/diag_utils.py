
import numpy as np

def rankdata(a):
    tmp = np.argsort(a, kind='mergesort')
    ranks = np.empty_like(tmp, dtype=float)
    ranks[tmp] = np.arange(len(a), dtype=float)
    uniq, inv, counts = np.unique(a, return_inverse=True, return_counts=True)
    sums = np.bincount(inv, weights=ranks)
    avg = sums / counts
    return avg[inv] + 1.0

def spearmanr(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    if x.size<3 or y.size<3: return float('nan')
    rx, ry = rankdata(x), rankdata(y)
    xz = (rx - rx.mean()) / (rx.std() + 1e-12)
    yz = (ry - ry.mean()) / (ry.std() + 1e-12)
    return float((xz*yz).mean())

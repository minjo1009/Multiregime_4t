
Diagnostics inside trade4v/diag
- run after backtest:
python -m trade4v.diag.run_diag --preds _out_4u/run/preds_test.csv --metrics _out_4u/run/metrics_oos.json --k_day "0:10,1:15,2:30" --H 15
Outputs: _out_4u/run/diag_report.json

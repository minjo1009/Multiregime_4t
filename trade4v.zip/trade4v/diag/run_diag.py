
import argparse, json, os
import numpy as np, pandas as pd
from .diag_utils import spearmanr

def parse_kday(s):
    out = {}
    if not s: return out
    for part in s.split(","):
        part = part.strip()
        if not part: continue
        rid, k = part.split(":")
        out[int(rid)] = int(k)
    return out

def ev_deciles(df, ev_col='ev', ret_col='realized_net', n=10):
    d = df[[ev_col, ret_col]].dropna().copy()
    if len(d)==0:
        return {"n":0, "deciles":[]}
    qs = np.quantile(d[ev_col], np.linspace(0,1,n+1))
    bins = pd.cut(d[ev_col], bins=qs, include_lowest=True, labels=False, duplicates='drop')
    grp = d.groupby(bins)[ret_col].mean()
    return {"n":int(len(d)), "deciles": grp.fillna(0.0).tolist()}

def brier_score(prob, y):
    p = np.asarray(prob, float)
    y = np.asarray(y, float)
    if p.size==0: return float('nan')
    return float(np.mean((p - y)**2))

def reliability(df, p_col='p_long', y_col='realized_gross', n_bins=10):
    y = (df[y_col] > 0).astype(int).values
    p = df[p_col].values
    bs = brier_score(p, y)
    d = pd.DataFrame({"p":p, "y":y}).dropna()
    qs = np.quantile(d["p"], np.linspace(0,1,n_bins+1))
    bins = pd.cut(d["p"], bins=qs, include_lowest=True, labels=False, duplicates='drop')
    g = d.groupby(bins).agg(p_mean=("p","mean"), y_rate=("y","mean"), n=("y","size")).reset_index(drop=True)
    return {"brier": bs, "bins": g.to_dict(orient="records")}

def gating_report(df, k_map, H):
    te = df.copy()
    te['date'] = pd.to_datetime(te['time']).dt.tz_convert('UTC').dt.floor('D')
    g = te.groupby(['date','regime_id'])
    rows = []
    for (d, rid), gd in g:
        k = int(k_map.get(int(rid), 0))
        actual = int(gd['entry_flag'].sum())
        rows.append({"date":str(d.date()), "rid":int(rid), "K":k, "actual":actual})
    tab = pd.DataFrame(rows)
    by = tab.groupby("rid").agg(K_sum=("K","sum"), actual_sum=("actual","sum")).reset_index()
    cov = float(te['entry_flag'].sum()) / float(max(1,len(te)))
    return {"coverage": cov, "by_regime": by.to_dict(orient="records")}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--preds", required=True)
    ap.add_argument("--metrics", required=False, default="")
    ap.add_argument("--k_day", required=True)
    ap.add_argument("--H", type=int, default=15)
    args = ap.parse_args()

    te = pd.read_csv(args.preds)
    k_map = parse_kday(args.k_day)

    s1 = reliability(te, p_col='p_long', y_col='realized_gross', n_bins=10)
    s1['note'] = "Label approximated with realized_gross>0"

    s2 = ev_deciles(te, ev_col='ev', ret_col='realized_net', n=10)
    try:
        rho = float(spearmanr(te['ev'].values, te['realized_net'].values))
    except Exception:
        rho = float('nan')
    s2['spearman_ev_vs_realized_net'] = rho

    gate = gating_report(te, k_map, H=args.H)

    rep = {"S1": s1, "S2": s2, "GATING": gate}
    os.makedirs("_out_4u/run", exist_ok=True)
    with open("_out_4u/run/diag_report.json", "w", encoding="utf-8") as f:
        json.dump(rep, f, indent=2)
    print(json.dumps(rep, indent=2))

if __name__ == "__main__":
    main()

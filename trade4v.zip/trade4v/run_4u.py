#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, os, json
import pandas as pd
from trend4p.data import load_csv
from trend4p.execution_4u import run_pipeline
from trend4p.backtest import summarize_preds

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True, type=str)
    ap.add_argument("--train_end", required=True, type=str)
    ap.add_argument("--test_start", required=True, type=str)
    ap.add_argument("--test_end", required=True, type=str)
    ap.add_argument("--H", default="15", type=str)
    ap.add_argument("--fee_bps", default="1.0", type=str)
    ap.add_argument("--slip_bps", default="0.5", type=str)
    ap.add_argument("--out_dir", default="_out_4u", type=str)
    args = ap.parse_args()

    H = int(float(args.H))
    fee = float(args.fee_bps); slip = float(args.slip_bps)
    out_dir = args.out_dir
    os.makedirs(os.path.join(out_dir, "run"), exist_ok=True)

    print(f"Using CSV: {args.data}")
    df = load_csv(args.data)

    preds_all = run_pipeline(df, H=H, fee_bps=fee, slip_bps=slip)
    t0 = pd.Timestamp(args.test_start); t0 = t0.tz_localize("UTC") if t0.tzinfo is None else t0.tz_convert("UTC")
    t1 = pd.Timestamp(args.test_end);   t1 = t1.tz_localize("UTC") if t1.tzinfo is None else t1.tz_convert("UTC")
    m = (preds_all["time"]>=t0) & (preds_all["time"]<=t1)
    preds_test = preds_all.loc[m].copy()

    out_preds = os.path.join(out_dir, "run", "preds_test.csv")
    preds_test.to_csv(out_preds, index=False)
    metrics = {"train":{"start":args.train_start,"end":args.train_end},
               "test":{"start":args.test_start,"end":args.test_end},
               "H":H,"fee_bps":fee,"slip_bps":slip,
               "test_metrics": summarize_preds(preds_test)}
    with open(os.path.join(out_dir, "run", "metrics_oos.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    print("Saved:", out_preds)
    print("Done.")

if __name__ == "__main__":
    main()

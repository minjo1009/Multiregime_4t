
import argparse, os, json, re
from trend4p.data_utils import load_csv
from trend4p.features_4u import make_features
from trend4p.labeling import make_h_label
from trend4p.execution_4u import run_pipeline

def parse_goal(s: str):
    s = (s or "mcc").strip().lower()
    if s.startswith("pnl"):
        nums = re.findall(r"[0-9]+", s)
        nmin = int(nums[0]) if nums else 300
        nmax = int(nums[1]) if len(nums) >= 2 else None
        return "pnl", nmin, nmax
    return "mcc", 0, None

def parse_goal_maps(s: str):
    s = (s or "").strip()
    if not s:
        return {}
    out = {}
    for part in s.split(","):
        if ":" not in part:
            continue
        k, rng = part.split(":", 1)
        if "-" in rng:
            a, b = rng.split("-", 1)
            out[int(k)] = [int(a), int(b)]
        else:
            out[int(k)] = [int(rng), 0]
    return out

def parse_regime(s: str):
    parts = [x.strip() for x in s.split(",")] if s else []
    if len(parts) >= 3:
        return int(parts[0]), None, float(parts[1]), float(parts[2])
    elif len(parts) == 2:
        return int(parts[0]), float(parts[1]), None, None
    else:
        return 64, None, 1.0, 2.0

def parse_cal(s: str):
    parts = [x.strip() for x in (s or "").split(",")]
    if len(parts) >= 2:
        return float(parts[0]), int(parts[1])
    return 0.40, 200

def parse_h_map(s: str):
    s = (s or "").strip()
    if not s: return {}
    out = {}
    for part in s.split(","):
        if ":" not in part: continue
        k,v = part.split(":",1)
        out[int(k)] = int(v)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True); ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True);  ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=15)
    ap.add_argument("--H_map", type=str, default="", help="per-regime H, e.g., '0:9,1:11,2:15'")
    ap.add_argument("--fee_bps", type=int, default=10)
    ap.add_argument("--regime", type=str, default="64,1.0,2.0", help="vol,z_thr or vol,z_low,z_high")
    ap.add_argument("--min_samples_per_regime", type=int, default=50000)
    ap.add_argument("--max_train_rows", type=int, default=200000)
    ap.add_argument("--use_regime_models", action="store_true")
    ap.add_argument("--cal", type=str, default="0.40,200", help="cal_frac,cal_bins")
    ap.add_argument("--goal", type=str, default="pnl,300-700")
    ap.add_argument("--goal_maps", type=str, default="0:20-80,1:30-120,2:300-700")
    ap.add_argument("--deoverlap", action="store_true")
    ap.add_argument("--gate_mode", type=str, default="soft", choices=["soft","hard"])
    ap.add_argument("--thin_factor", type=float, default=0.1)
    ap.add_argument("--thin_floor", type=int, default=20)
    ap.add_argument("--ev_floor_mult", type=float, default=1.5, help="min EV_net >= mult * roundtrip_fee")
    ap.add_argument("--size_mode", type=str, default="kelly", choices=["none","kelly"])
    ap.add_argument("--risk_budget", type=float, default=0.02)
    ap.add_argument("--size_max", type=float, default=1.0)
    ap.add_argument("--min_range_bp", type=float, default=0.0, help="skip if recent range < this bps (0=off)")
    ap.add_argument("--range_k", type=int, default=20)
    ap.add_argument("--spike_bps", type=float, default=0.0, help="block entry after |ret1|>= spike_bps (0=off)")
    ap.add_argument("--out_dir", default="_out_4u")
    args = ap.parse_args()

    df = load_csv(args.data)
    df = make_features(df)
    df["label"] = make_h_label(df, H=args.H)

    goal_obj, goal_nmin, goal_nmax = parse_goal(args.goal)
    goal_maps = parse_goal_maps(args.goal_maps)
    volw, z_thr, z_low, z_high = parse_regime(args.regime)
    cal_frac, cal_bins = parse_cal(args.cal)
    H_map = parse_h_map(args.H_map)

    cfg = dict(
        train_start=args.train_start, train_end=args.train_end,
        test_start=args.test_start,   test_end=args.test_end,
        H=args.H, H_map=H_map,
        fee_bps=args.fee_bps,
        vol_window=volw, z_thr=z_thr, z_thr_low=z_low, z_thr_high=z_high,
        min_samples_per_regime=args.min_samples_per_regime,
        feature_cols=[c for c in df.columns if c not in ["time","open","high","low","close","volume","label"]],
        max_train_rows=args.max_train_rows,
        use_regime_models=bool(args.use_regime_models),
        cal_frac=cal_frac, cal_bins=cal_bins,
        goal_obj=goal_obj, goal_nmin=goal_nmin, goal_nmax=goal_nmax,
        goal_maps=goal_maps,
        deoverlap=bool(args.deoverlap),
        gate_mode=args.gate_mode,
        thin_factor=args.thin_factor,
        thin_floor=args.thin_floor,
        ev_floor_mult=args.ev_floor_mult,
        size_mode=args.size_mode,
        risk_budget=args.risk_budget,
        size_max=args.size_max,
        min_range_bp=args.min_range_bp,
        range_k=args.range_k,
        spike_bps=args.spike_bps
    )

    preds, metrics, theta_tab = run_pipeline(df, H=args.H, cfg=cfg)

    os.makedirs(args.out_dir, exist_ok=True)
    preds.to_parquet(os.path.join(args.out_dir, "preds_test.parquet"))
    preds.to_csv(os.path.join(args.out_dir, "preds_test.csv"), index=False)  # added CSV export
    with open(os.path.join(args.out_dir, "metrics_oos.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    with open(os.path.join(args.out_dir, "config.json"), "w") as f:
        json.dump(cfg, f, indent=2)
    with open(os.path.join(args.out_dir, "theta_table.json"), "w") as f:
        json.dump(theta_tab, f, indent=2)

if __name__ == "__main__":
    main()

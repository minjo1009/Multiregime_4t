
import argparse, os, json
from trend4p.data_utils import load_csv
from trend4p.features_4u import make_features
from trend4p.labeling import make_h_label
from trend4p.execution_4u import run_pipeline

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True)
    ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True)
    ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=5)
    ap.add_argument("--fee_bps", type=int, default=10)
    ap.add_argument("--vol_window", type=int, default=64)
    ap.add_argument("--z_thr", type=float, default=1.5)
    ap.add_argument("--cov_min", type=float, default=0.10)
    ap.add_argument("--cov_max", type=float, default=0.30)
    ap.add_argument("--min_samples_per_regime", type=int, default=500)
    ap.add_argument("--out_dir", default="_out_4u")
    args = ap.parse_args()

    df = load_csv(args.data)
    df = make_features(df)                       # adds ret1, ema, rsi...
    df["label"] = make_h_label(df, H=args.H)     # 0/1

    cfg = dict(
        train_start=args.train_start, train_end=args.train_end,
        test_start=args.test_start,   test_end=args.test_end,
        H=args.H, fee_bps=args.fee_bps,
        vol_window=args.vol_window, z_thr=args.z_thr,
        cov_min=args.cov_min, cov_max=args.cov_max,
        min_samples_per_regime=args.min_samples_per_regime,
        feature_cols=[c for c in df.columns if c not in ["time","open","high","low","close","volume","label"]]
    )

    preds, metrics, theta_tab = run_pipeline(df, H=args.H, cfg=cfg)

    os.makedirs(args.out_dir, exist_ok=True)
    preds.to_parquet(os.path.join(args.out_dir, "preds_test.parquet"))
    with open(os.path.join(args.out_dir, "metrics_oos.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.out_dir, "config.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.out_dir, "theta_table.json"), "w", encoding="utf-8") as f:
        json.dump(theta_tab, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    main()

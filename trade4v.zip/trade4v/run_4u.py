
import argparse, os, json
import numpy as np
import pandas as pd
from trend4p.data_utils import load_csv
from trend4p.features_4u import make_features
from trend4p.regime import RegimeTagger
from trend4p.event_labeler import parse_bar_map, realize_event_returns
from trend4p.ev_model import EVRegressorPerRegime
from trend4p.selector_ev import parse_k_map, select_topk_daily

def parse_h_map(s: str):
    if not s: return {}
    out = {}
    for part in s.split(","):
        if ":" not in part: continue
        k,v = part.split(":",1)
        out[int(k)] = int(v)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--train_start", required=True); ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True);  ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=15)
    ap.add_argument("--H_map", type=str, default="0:13,1:17,2:25")
    ap.add_argument("--fee_bps", type=int, default=10)
    ap.add_argument("--slip_bps", type=int, default=0)
    ap.add_argument("--regime", type=str, default="64,1.0,2.0")
    ap.add_argument("--bar_map", type=str, default="0:20,12,15;1:30,20,20;2:50,30,30")
    ap.add_argument("--k_day", type=str, default="0:3,1:5,2:12")
    ap.add_argument("--ev_anneal", type=str, default="1.0,0.5,0.0")
    ap.add_argument("--size_mode", type=str, default="kelly", choices=["none","kelly"])
    ap.add_argument("--risk_budget", type=float, default=0.02)
    ap.add_argument("--size_max", type=float, default=1.0)
    ap.add_argument("--out_dir", default="_out_4u")
    args, unknown = ap.parse_known_args()
    if unknown:
        print("[WARN] Ignoring deprecated/unknown args:", ' '.join(unknown))

    df0 = load_csv(args.data)
    df0 = df0[(df0["time"]>=args.train_start) & (df0["time"]<=args.test_end)].reset_index(drop=True)
    dfF = make_features(df0)

    def parse_regime(s):
        parts = [x.strip() for x in s.split(",")] if s else []
        if len(parts) >= 3:
            return int(parts[0]), None, float(parts[1]), float(parts[2])
        elif len(parts) == 2:
            return int(parts[0]), float(parts[1]), None, None
        else:
            return 64, None, 1.0, 2.0
    volw, z_thr, z_low, z_high = parse_regime(args.regime)
    tagger = RegimeTagger(vol_window=volw, z_thr=z_thr, z_thr_low=z_low, z_thr_high=z_high).fit(dfF)
    dfF["regime_id"] = tagger.transform(dfF)

    df_tr = dfF[(dfF["time"]>=args.train_start) & (dfF["time"]<=args.train_end)].reset_index(drop=True)
    df_te = dfF[(dfF["time"]>=args.test_start)  & (dfF["time"]<=args.test_end)].reset_index(drop=True)

    bar_map = parse_bar_map(args.bar_map, default={0:(20,12,15),1:(30,20,20),2:(50,30,30)})
    g_tr, y_tr, H_tr = realize_event_returns(df_tr, df_tr["regime_id"].to_numpy(), bar_map, fee_bps=args.fee_bps, slip_bps=args.slip_bps)

    feat_cols = [c for c in dfF.columns if c not in ["time","open","high","low","close","volume","regime_id"]]
    X_tr = df_tr[feat_cols].to_numpy(np.float32)
    r_tr = df_tr["regime_id"].to_numpy(int)
    evr = EVRegressorPerRegime(alpha_hi=0.9).fit(X_tr, y_tr, r_tr)

    X_te = df_te[feat_cols].to_numpy(np.float32)
    r_te = df_te["regime_id"].to_numpy(int)
    ev50, ev90 = evr.predict(X_te, r_te)
    ev_final = 0.7*ev50 + 0.3*ev90

    H_map = parse_h_map(args.H_map)
    H_seq = np.array([int(H_map.get(int(r), args.H)) for r in r_te], dtype=int)
    fee_rt = 2.0*(args.fee_bps+args.slip_bps)/1e4
    k_map = parse_k_map(args.k_day, default={0:3,1:5,2:12})
    floors = [float(x.strip()) for x in (args.ev_anneal.split(",") if args.ev_anneal else ["0.0"])]
    flag = select_topk_daily(ev_final, df_te["time"], r_te, H_seq, k_map, floors, fee_rt)

    size = np.zeros(len(flag), dtype=float)
    if args.size_mode == "kelly":
        var_by = {}
        for rr in np.unique(r_tr):
            m = (r_tr==rr)
            v = float(np.nanvar(y_tr[m]))
            if not np.isfinite(v) or v <= 0: v = 1e-6
            var_by[int(rr)] = v
        for i in range(len(flag)):
            if flag[i] != 1: 
                size[i] = 0.0; continue
            rr = int(r_te[i])
            mu = float(ev_final[i])
            v = var_by.get(rr, 1e-4)
            sz = (mu / (v + 1e-8)) * float(args.risk_budget)
            if not np.isfinite(sz): sz = 0.0
            size[i] = max(0.0, min(float(args.size_max), sz))
    else:
        size = (flag>0).astype(float)

    g_te, y_te, H_used_te = realize_event_returns(df_te, r_te, bar_map, fee_bps=args.fee_bps, slip_bps=args.slip_bps)
    pnl = float(np.nansum(y_te[flag==1] * size[flag==1]))
    trades = int(np.sum(flag))
    coverage = float(trades / len(flag)) if len(flag)>0 else 0.0
    hitrate = float(np.mean(g_te[flag==1] > 0.0)) if trades>0 else 0.0

    by_regime = {}
    for rid in np.unique(r_te):
        m = (r_te==rid) & (flag==1)
        if not np.any(m):
            by_regime[int(rid)] = dict(trades=0, pnl=0.0, hit_rate=0.0)
        else:
            by_regime[int(rid)] = dict(trades=int(np.sum(m)), pnl=float(np.nansum(y_te[m] * size[m])), hit_rate=float(np.mean(g_te[m] > 0.0)))

    os.makedirs(args.out_dir, exist_ok=True)
    preds = pd.DataFrame({
        "time": df_te["time"].to_numpy(),
        "regime_id": r_te,
        "H_row": H_seq,
        "ev50": ev50,
        "ev90": ev90,
        "ev_final": ev_final,
        "entry_flag": flag,
        "size": size,
        "gross_event": g_te,
        "net_event": y_te,
    })
    preds.to_parquet(os.path.join(args.out_dir, "preds_test.parquet"))
    preds.to_csv(os.path.join(args.out_dir, "preds_test.csv"), index=False)

    metrics = dict(
        mode="EV_TOPK",
        fee_bps=int(args.fee_bps), slip_bps=int(args.slip_bps),
        H=int(args.H), H_map=parse_h_map(args.H_map),
        bar_map=bar_map,
        k_day=k_map, ev_anneal=floors,
        size_mode=args.size_mode, risk_budget=float(args.risk_budget), size_max=float(args.size_max),
        pnl=float(pnl), trades=int(trades), coverage=float(coverage), hit_rate=float(hitrate),
        train=dict(start=args.train_start, end=args.train_end),
        test=dict(start=args.test_start, end=args.test_end),
        by_regime=by_regime
    )
    with open(os.path.join(args.out_dir, "metrics_oos.json"), "w") as f:
        json.dump(metrics, f, indent=2)
    with open(os.path.join(args.out_dir, "config.json"), "w") as f:
        json.dump(dict(vars(args)), f, indent=2)

if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
run_4u.py — v1.2.0
- Unified config loader: prefer conf/config.effective.yml, else conf/config.yml
- Required columns validation
- Strict failure on engine errors (no placeholders)
- Summary includes __config_sha256__ and mandatory metrics
"""
import sys, json, argparse, pathlib, hashlib, traceback
from typing import Dict, Any
import pandas as pd

try:
    import yaml
except Exception as e:
    print("[fatal] PyYAML is required. pip install pyyaml", file=sys.stderr)
    raise

# local import
SCRIPT_DIR = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))

from backtest.engine import backtest, REQUIRED_COLS, validate_df

def _read_config() -> (pathlib.Path, Dict[str, Any], str):
    conf_dir = SCRIPT_DIR / "conf"
    eff = conf_dir / "config.effective.yml"
    base = conf_dir / "config.yml"
    if eff.exists():
        p = eff
    elif base.exists():
        p = base
    else:
        raise FileNotFoundError("No config file found in conf/ (config.effective.yml or config.yml)")
    text = p.read_text(encoding="utf-8")
    try:
        cfg = yaml.safe_load(text) or {}
    except Exception as e:
        raise RuntimeError(f"Failed to parse YAML: {p}") from e
    sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
    print(f"[config] using={p} sha256={sha}")
    return p, cfg, sha

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True, help="Path to CSV (must include open_time, open, high, low, close, volume)")
    ap.add_argument("--out_dir", required=True, help="Output directory")
    args = ap.parse_args()

    out_dir = pathlib.Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    cfg_path, cfg, cfg_sha = _read_config()

    # Read data
    csv_path = pathlib.Path(args.data_path)
    if not csv_path.exists():
        print(f"[fatal] data not found: {csv_path}", file=sys.stderr)
        sys.exit(75)
    try:
        df = pd.read_csv(csv_path)
    except Exception as e:
        print(f"[fatal] failed to read CSV: {e}", file=sys.stderr)
        sys.exit(75)

    # Validate schema
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        print(f"[fatal] missing required columns: {missing}", file=sys.stderr)
        sys.exit(75)
    try:
        validate_df(df)
    except Exception as e:
        print(f"[fatal] invalid dataframe: {e}", file=sys.stderr)
        sys.exit(75)

    # Run engine
    try:
        trades_df, summary = backtest(df, cfg)
    except Exception as e:
        # strict failure, no placeholders
        summary = {
            "error": "engine_failed",
            "placeholder_reason": str(e),
            "stack": traceback.format_exc(limit=6),
            "created_utc": pd.Timestamp.utcnow().isoformat() + "Z",
            "__config_sha256__": cfg_sha,
        }
        (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        print("[fatal] engine failed; see summary.json for details", file=sys.stderr)
        sys.exit(78)

    # Post checks: ensure mandatory metrics exist
    for k in ("hit_rate", "profit_factor", "n_trades"):
        if k not in summary or summary[k] is None:
            print(f"[fatal] missing metric {k} in summary", file=sys.stderr)
            # write summary for debugging
            summary.setdefault("error", "missing_metrics")
            summary.setdefault("created_utc", pd.Timestamp.utcnow().isoformat() + "Z")
            summary["__config_sha256__"] = cfg_sha
            (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
            sys.exit(78)

    # Attach config SHA + echo to logs
    summary["__config_sha256__"] = cfg_sha

    # Write outputs
    trades_csv = out_dir / "trades.csv"
    trades_df.to_csv(trades_csv, index=False)
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    # gating_debug minimal (thr_by_session passthrough if present)
    gating = {}
    tbs = (cfg.get("thr_by_session") or cfg.get("thr") or cfg.get("threshold"))
    if isinstance(tbs, dict):
        gating["thr_by_session"] = tbs
    gating["__config_sha256__"] = cfg_sha
    (out_dir / "gating_debug.json").write_text(json.dumps(gating, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[done] outputs at {out_dir}")
    print(f"[metrics] hit_rate={summary['hit_rate']:.4f} pf={summary['profit_factor']:.4f} n={summary['n_trades']}")
    sys.exit(0)


if __name__ == "__main__":
    main()
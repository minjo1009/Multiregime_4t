# tests/test_schema_and_summary.py
import pandas as pd
from backtest.engine import backtest, validate_df

def _make_df(n=1000):
    import numpy as np
    idx = pd.RangeIndex(n)
    close = pd.Series(10000 + np.cumsum(np.random.randn(n))*5.0)
    high  = close + np.abs(np.random.randn(n))*2.0
    low   = close - np.abs(np.random.randn(n))*2.0
    df = pd.DataFrame({
        "open_time": idx,
        "open": close.shift(1).fillna(close.iloc[0]),
        "high": high,
        "low": low,
        "close": close,
        "volume": 100 + np.random.rand(n)*10
    })
    return df

def test_validate_ok():
    df = _make_df()
    validate_df(df)

def test_backtest_summary_has_metrics():
    df = _make_df()
    trades, summary = backtest(df, {"tp_pct":0.0035, "sl_pct":0.0018, "hold_bars":6})
    assert "hit_rate" in summary and summary["hit_rate"] is not None
    assert "profit_factor" in summary and summary["profit_factor"] is not None
    assert "n_trades" in summary and summary["n_trades"] > 0
    assert "pnl" in trades.columns
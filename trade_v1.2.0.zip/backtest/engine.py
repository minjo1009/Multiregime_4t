# -*- coding: utf-8 -*-
"""
backtest/engine.py — v1.2.0
- Config key aliases normalized
- Simple horizon/TP/SL backtest that outputs trades with a standardized 'pnl' column
- Mandatory metrics: hit_rate, profit_factor, n_trades
"""
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np

REQUIRED_COLS = ["open_time","open","high","low","close","volume"]

def _alias(cfg: Dict[str, Any], keys, default=None):
    for k in keys:
        if k in cfg and cfg[k] is not None:
            return cfg[k]
    return default

def normalize_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(cfg)
    out["tp_pct"] = _alias(cfg, ["tp_pct", "tp", "take_profit"], 0.003)
    out["sl_pct"] = _alias(cfg, ["sl_pct", "sl", "stop_loss"], 0.0015)
    out["hold_bars"] = int(_alias(cfg, ["hold_bars", "hold", "holding_period"], 6))
    # allow thr_by_session passthrough
    if "thr_by_session" not in out and isinstance(_alias(cfg, ["thr_by_session"], {}), dict):
        out["thr_by_session"] = cfg["thr_by_session"]
    return out

def validate_df(df: pd.DataFrame):
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"missing required cols: {missing}")
    # basic sanity
    if len(df) < 100:
        raise ValueError("too few rows for backtest (min 100)")

def _future_max_min(series: pd.Series, window: int) -> Tuple[pd.Series, pd.Series]:
    # compute future rolling max/min over the next 'window' bars
    rev = series[::-1]
    fmax = rev.rolling(window, min_periods=window).max()[::-1].shift(-(window-1))
    fmin = rev.rolling(window, min_periods=window).min()[::-1].shift(-(window-1))
    return fmax, fmin

def backtest(df: pd.DataFrame, cfg: Dict[str, Any]) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    validate_df(df)
    C = normalize_config(cfg)
    tp = float(C["tp_pct"])
    sl = float(C["sl_pct"])
    H  = int(C["hold_bars"])

    close = pd.to_numeric(df["close"], errors="coerce")
    high  = pd.to_numeric(df["high"], errors="coerce")
    low   = pd.to_numeric(df["low"], errors="coerce")

    entry = close.astype(float)
    # future extrema within horizon
    fmax, fmin = _future_max_min(high, H), _future_max_min(low, H)
    # _future_max_min returns tuple(max_series, min_series) but we called twice; fix:
    fmax = fmax[0]  # max of high
    fmin = fmin[1]  # min of low

    # target prices
    tp_price = entry * (1.0 + tp)
    sl_price = entry * (1.0 - sl)

    hit_tp = (fmax >= tp_price)
    hit_sl = (fmin <= sl_price)

    # base forward return at horizon
    fwd = (close.shift(-H) / close - 1.0)

    # PnL logic:
    # - TP only: +tp
    # - SL only: -sl
    # - none: use fwd clipped to [-sl, +tp]
    # - both: fallback to 0 (ambiguous first-touch)
    pnl = np.select(
        [
            hit_tp & ~hit_sl,
            hit_sl & ~hit_tp,
            ~(hit_tp | hit_sl)
        ],
        [
            np.full(len(entry), tp),
            np.full(len(entry), -sl),
            fwd.clip(-sl, tp).values
        ],
        default=np.zeros(len(entry))
    )

    # last H rows invalid (no future), set NaN and drop
    pnl[-H:] = np.nan
    trades = pd.DataFrame({
        "open_time": df["open_time"],
        "pnl": pnl
    }).dropna()

    # Metrics
    v = trades["pnl"].astype(float)
    n = int(v.count())
    if n == 0:
        raise RuntimeError("no trades generated (n_trades=0)")
    hit = float((v > 0).mean())
    pos = float(v[v > 0].sum())
    neg = float((-v[v < 0]).sum())
    pf  = (pos / neg) if neg > 0 else (1e9 if pos > 0 else 0.0)

    summary = {
        "hit_rate": hit,
        "profit_factor": pf,
        "n_trades": n,
        "tp_pct": tp,
        "sl_pct": sl,
        "hold_bars": H,
    }
    return trades, summary
# trade_v1.2.0

핵심 변경
- run_4u.py: 설정 로딩 통합, 필수 컬럼 검증, 엔진 실패 시 즉시 실패(exit 78), __config_sha256__ 기록
- backtest/engine.py: config alias 표준화(tp_pct/sl_pct/hold_bars/thr_by_session), 단순 TP/SL/보유기간 엔진, 'pnl' 열 보장
- 산출물: summary.json에 hit_rate/profit_factor/n_trades 필수 기록(없으면 실패 처리)
- 폴더: 외부에서 OUT_DIR 지정해 조합별 분리 가능
- tests: 스키마/요약 생성 기본 테스트 포함

CLI
```
python run_4u.py --data_path <CSV> --out_dir <OUT_DIR>
```
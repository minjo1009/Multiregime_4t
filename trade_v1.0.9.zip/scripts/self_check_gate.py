#!/usr/bin/env python3
import json
from pathlib import Path
p = Path("_out_4u/run/gating_debug.json")
assert p.exists() and p.stat().st_size>2, "gating_debug.json missing or empty"
obj = json.loads(p.read_text(encoding="utf-8"))
assert "coverage_overall_inferred" in obj, "missing coverage"
print("[self_check_gate] OK; coverage≈", obj.get("coverage_overall_inferred"))

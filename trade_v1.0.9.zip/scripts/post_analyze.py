#!/usr/bin/env python3
import os, json, pandas as pd
from pathlib import Path

OUT = Path("_out_4u"); RUN = OUT/"run"; RUN.mkdir(parents=True, exist_ok=True)
diag = {}
preds_p = OUT/"preds_test.csv"
trades_p = OUT/"trades.csv"
def safe_read(p):
    try: return pd.read_csv(p)
    except Exception: return None
preds = safe_read(preds_p); trades = safe_read(trades_p)
diag["exists"]={"preds": preds is not None, "trades": trades is not None}
diag["sizes"]={"preds_rows": 0 if preds is None else int(len(preds)),
               "trades_rows": 0 if trades is None else int(len(trades))}
cov=0.0
if trades is not None and len(trades)>0:
    cov = float(len(trades))/max(1, diag["sizes"]["preds_rows"])
elif preds is not None and "gate" in preds.columns:
    cov = float((preds["gate"].astype(float)>0.5).mean())
if preds is not None and "gate" in preds.columns:
    g=preds["gate"].astype(float)
    qs=[0.0,0.01,0.5,0.9,0.95,0.99,1.0]
    diag["gate_percentiles"]={str(q): float(g.quantile(q)) for q in qs}
    diag["gate_mean"]=float(g.mean())
diag["coverage_overall_inferred"]=cov
(RUN/"gating_debug.json").write_text(json.dumps(diag, indent=2, ensure_ascii=False), encoding="utf-8")
print("[post_analyze] coverage≈", cov)
if os.environ.get("COVERAGE_GUARD","false").lower()=="true" and cov<=0.0:
    import sys; print("::error::coverage==0"); sys.exit(3)

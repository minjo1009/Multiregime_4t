# v1.0.9
- Implement Calibrator predict/predict_proba (engine API compatibility)
- Add tests and self-check
- No interface changes; artifacts path unchanged

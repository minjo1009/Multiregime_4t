# trend4u Unified Code Pack

This pack consolidates **trend4t_hotfix_pack_u3** into a unified release named **trend4u** (override build).
Generated: 2025-08-23T01:26:36.101867Z

## What changed
- Renamed identifiers and folders: `trend4t` → `trend4u` (case-preserving where sensible).
- Left historical "hotfix/u3" notes intact for traceability where present.
- No data files bundled (to keep the pack light). Use your local `ETHUSDT_1min_2020_2025.csv` path.

## Quick Start
1. Create a Python 3.10+ venv.
2. Install dependencies (see `requirements.txt` if present).
3. Update config: point data path to your ETHUSDT 1m dataset.
4. Run backtest/runner scripts under the `trend4u` modules.

## Known limits
- Only textual replacements were applied. If code referenced module names strictly as `trend4t` in import paths, these were auto-updated; if any binary or notebook metadata had unusual encodings, they were left untouched.
- If you need me to also **refactor package/module names** inside `setup.cfg/pyproject.toml` or re-export notebooks to scripts, ping me and I'll do a deeper pass.


import argparse, json, os
from trend4p.execution_4u import backtest

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Path to CSV (must include open_time, open, high, low, close, volume)")
    ap.add_argument("--train_start", required=True)
    ap.add_argument("--train_end", required=True)
    ap.add_argument("--test_start", required=True)
    ap.add_argument("--test_end", required=True)
    ap.add_argument("--H", type=int, default=5)
    ap.add_argument("--fee_bps", type=float, default=1.0)
    ap.add_argument("--cov_low", type=float, default=0.2)
    ap.add_argument("--cov_high", type=float, default=0.4)
    ap.add_argument("--out_dir", default="_out_4u")
    return ap.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    out = backtest(
        data_path=args.data,
        train_start=args.train_start, train_end=args.train_end,
        test_start=args.test_start, test_end=args.test_end,
        H=args.H, fee_bps=args.fee_bps, cov_band=(args.cov_low, args.cov_high)
    )
    # write summary
    fp = os.path.join(args.out_dir, "train_test_summary.json")
    with open(fp, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print(json.dumps(out, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()

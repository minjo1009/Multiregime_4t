# -*- coding: utf-8 -*-
from __future__ import annotations

import argparse
import json
import math
import os
import sys
import inspect
from datetime import datetime
from typing import Dict, Any, Optional

try:
    from trend4u.trend4p.execution_4u import backtest  # type: ignore
except Exception:
    from trend4u import trend4p  # type: ignore
    backtest = getattr(trend4p, "execution_4u", trend4p).__dict__.get("backtest")  # type: ignore

import pandas as pd


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="4u backtest runner")
    p.add_argument("--data", dest="data", type=str, default="",
                   help="CSV path. If empty, the first CSV under ./data is used.")
    p.add_argument("--train_start", type=str, default="2020-01-01")
    p.add_argument("--train_end",   type=str, default="2024-01-01")
    p.add_argument("--test_start",  type=str, default="2024-01-01")
    p.add_argument("--test_end",    type=str, default="2025-01-01")
    p.add_argument("--fee_bps",     type=float, default=None)
    p.add_argument("--cov_low",     type=float, default=None)
    p.add_argument("--cov_high",    type=float, default=None)
    p.add_argument("--H",           type=int,   default=None)
    p.add_argument("--edge_threshold", type=float, default=None)
    p.add_argument("--out_dir",     type=str, default=os.environ.get("OUT_DIR", "./_out"))
    return p.parse_args()


def _ensure_outdir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def _infer_csv(csv_arg: str) -> Optional[str]:
    if csv_arg and os.path.isfile(csv_arg):
        return csv_arg
    data_dir = os.environ.get("DATA_DIR", "./data")
    if os.path.isdir(data_dir):
        for root, _, files in os.walk(data_dir):
            for f in files:
                if f.lower().endswith(".csv"):
                    return os.path.join(root, f)
    for f in os.listdir("."):
        if f.lower().endswith(".csv"):
            return os.path.abspath(f)
    return None


def _months_between(s: str, e: str) -> float:
    d1 = datetime.fromisoformat(s[:10])
    d2 = datetime.fromisoformat(e[:10])
    return max(1e-6, (d2.year - d1.year) * 12 + (d2.month - d1.month) + (d2.day - d1.day) / 30.0)


def _mcc_from_counts(tp: int, tn: int, fp: int, fn: int) -> float:
    num = tp * tn - fp * fn
    den = math.sqrt(float(tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    return float(num / den) if den > 0 else 0.0


def _compute_metrics_from_files(out_dir: str, test_start: str, test_end: str) -> Dict[str, Any]:
    metrics: Dict[str, Any] = {}
    # equity curve
    eq_path = None
    if os.path.isdir(out_dir):
        for name in os.listdir(out_dir):
            if name.startswith("equity_curve") and name.endswith(".csv"):
                eq_path = os.path.join(out_dir, name)
                break
    if eq_path and os.path.isfile(eq_path):
        df = pd.read_csv(eq_path)
        for col in ["equity", "nav", "cum_pnl", "equity_curve", "curve"]:
            if col in df.columns and len(df[col]) > 0:
                s0 = float(df[col].iloc[0])
                s1 = float(df[col].iloc[-1])
                total = (s1 / s0) if s0 not in (0.0, float("nan")) else 1.0
                m = _months_between(test_start, test_end)
                monthly = total ** (1.0 / m) if total > 0 and math.isfinite(total) else 1.0
                metrics.update(total_return=total, monthly_return=monthly)
                break

    # trades
    if "total_return" not in metrics and os.path.isdir(out_dir):
        tr_path = None
        for name in os.listdir(out_dir):
            if name.startswith("trades") and name.endswith(".csv"):
                tr_path = os.path.join(out_dir, name)
                break
        if tr_path and os.path.isfile(tr_path):
            tdf = pd.read_csv(tr_path)
            if "pnl" in tdf.columns and len(tdf) > 0:
                eq = 1.0 + tdf["pnl"].astype(float).cumsum()
                total = float(eq.iloc[-1])
                m = _months_between(test_start, test_end)
                monthly = total ** (1.0 / m) if total > 0 and math.isfinite(total) else 1.0
                metrics.update(total_return=total, monthly_return=monthly)

    # predictions
    if os.path.isdir(out_dir):
        pred_path = None
        for name in os.listdir(out_dir):
            if (name.startswith("preds") or name.startswith("predictions")) and name.endswith(".csv"):
                pred_path = os.path.join(out_dir, name)
                break
        if pred_path and os.path.isfile(pred_path):
            pdf = pd.read_csv(pred_path)
            y_true = y_pred = None
            for a, b in [("y_true","y_pred"), ("true","pred"), ("label","pred")]:
                if a in pdf.columns and b in pdf.columns:
                    y_true = pdf[a].astype(int).to_numpy()
                    y_pred = pdf[b].astype(int).to_numpy()
                    break
            if y_true is not None and y_pred is not None and len(y_true) == len(y_pred) and len(y_true) > 0:
                acc = float((y_true == y_pred).mean())
                tp = int(((y_true == 1) & (y_pred == 1)).sum())
                tn = int(((y_true == 0) & (y_pred == 0)).sum())
                fp = int(((y_true == 0) & (y_pred == 1)).sum())
                fn = int(((y_true == 1) & (y_pred == 0)).sum())
                num = tp * tn - fp * fn
                den = math.sqrt(float(tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
                mcc = float(num / den) if den > 0 else 0.0
                metrics.update(acc=acc, mcc=mcc, coverage=float((y_pred != 0).mean()), n_trades=int((y_pred != 0).sum()))
    return metrics


def main() -> int:
    args = _parse_args()
    out_dir = _ensure_outdir(args.out_dir or "./_out")

    data_csv = args.data if args.data else _infer_csv("")
    if not data_csv:
        summary = {
            "H": args.H,
            "edge_threshold": args.edge_threshold,
            "train": {"start": args.train_start, "end": args.train_end,
                      "coverage": 0.0, "acc": 0.0, "mcc": 0.0, "n_trades": 0},
            "test":  {"start": args.test_start, "end": args.test_end,
                      "coverage": 0.0, "acc": 0.0, "mcc": 0.0, "n_trades": 0,
                      "total_return": 1.0, "monthly_return": 1.0},
        }
        with open(os.path.join(out_dir, "train_test_summary.json"), "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        print("No CSV found; wrote minimal summary.", file=sys.stderr)
        return 2

    poss = dict(
        data=data_csv,
        train_start=args.train_start, train_end=args.train_end,
        test_start=args.test_start,   test_end=args.test_end,
        out_dir=out_dir,
        fee_bps=args.fee_bps, cov_low=args.cov_low, cov_high=args.cov_high,
        H=args.H, edge_threshold=args.edge_threshold,
    )
    bt_kwargs = {}
    try:
        sig = inspect.signature(backtest)
        for k, v in poss.items():
            if k in sig.parameters and v is not None:
                bt_kwargs[k] = v
    except Exception:
        for k in ["data","train_start","train_end","test_start","test_end","out_dir"]:
            if poss.get(k) is not None:
                bt_kwargs[k] = poss[k]

    try:
        result = backtest(**bt_kwargs)  # type: ignore
    except TypeError:
        minimal = {k: poss[k] for k in ["data","train_start","train_end","test_start","test_end"] if poss.get(k) is not None}
        result = backtest(**minimal)  # type: ignore
    except Exception as e:
        print(f"[WARN] backtest raised {type(e).__name__}: {e}", file=sys.stderr)
        result = None

    train_metrics = {"start": poss["train_start"], "end": poss["train_end"]}
    test_metrics  = {"start": poss["test_start"],  "end": poss["test_end"]}
    if isinstance(result, dict):
        if isinstance(result.get("train"), dict):
            train_metrics.update(result["train"])
        if isinstance(result.get("test"), dict):
            test_metrics.update(result["test"])

    aux = _compute_metrics_from_files(out_dir, poss["test_start"], poss["test_end"])
    for k in ["total_return","monthly_return","acc","mcc","coverage","n_trades"]:
        if k in aux and (k not in test_metrics or pd.isna(test_metrics.get(k))):
            test_metrics[k] = aux[k]

    for d in (train_metrics, test_metrics):
        d.setdefault("coverage", 0.0)
        d.setdefault("acc", 0.0)
        d.setdefault("mcc", 0.0)
        d.setdefault("n_trades", int(d.get("n_trades") or 0))
    test_metrics.setdefault("total_return", 1.0)
    test_metrics.setdefault("monthly_return", 1.0)

    summary = {
        "H": args.H,
        "edge_threshold": args.edge_threshold,
        "train": train_metrics,
        "test":  test_metrics,
    }
    with open(os.path.join(out_dir, "train_test_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(f"[OK] Summary written to {os.path.join(out_dir, 'train_test_summary.json')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

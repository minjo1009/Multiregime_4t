# trend4u_hotfix_pack_u3

Self-contained pack to run 4t backtests locally or in GitHub Actions.
Key hotfixes:
- **labeling.py**: NaN/inf safe labels to avoid `IntCastingNaNError`
- **model_4u.py**: Calibration API compatibility (`estimator` vs `base_estimator`)
- **execution_4u.py**: Robust metrics & summary writer
- **requirements.txt**: Explicit deps for CI

## Run (local)
```bash
python run_4u.py       --data data/ETHUSDT_1min_2020_2025.csv       --train_start 2025-01-01 --train_end 2025-04-30       --test_start  2025-05-01  --test_end  2025-06-30       --H 5 --out_dir _out_4u/local
```

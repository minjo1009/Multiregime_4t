import pandas as pd
import numpy as np

REQUIRED_COLS = ["open_time","open","high","low","close","volume"]

def read_ohlcv_csv(path):
    # robust CSV loader, expecting at least the required columns
    df = pd.read_csv(path)
    # normalize headers
    df.columns = [c.strip() for c in df.columns]
    # allow alias 'ts' -> 'open_time'
    if "open_time" not in df.columns and "ts" in df.columns:
        df = df.rename(columns={"ts":"open_time"})
    # ensure all required columns exist
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"CSV missing columns: {missing}; available={list(df.columns)}")

    # parse time
    df["open_time"] = pd.to_datetime(df["open_time"], utc=True, errors="coerce")
    df = df.dropna(subset=["open_time"]).sort_values("open_time").reset_index(drop=True)
    df = df.set_index("open_time")
    # numeric cast
    for c in ["open","high","low","close","volume"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["open","high","low","close"])
    return df

def slice_by_time(df, start, end):
    return df.loc[(df.index >= pd.to_datetime(start, utc=True)) & (df.index <= pd.to_datetime(end, utc=True))].copy()

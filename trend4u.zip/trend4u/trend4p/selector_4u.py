import numpy as np

def choose_threshold(probs, cov_band=(0.2,0.4)):
    # pick threshold to target mid of band
    lo, hi = cov_band
    target = (lo + hi) / 2.0
    # we assume long-only using prob>thr; coverage = fraction prob>thr
    thr = np.quantile(probs, 1 - target) if len(probs) else 0.5
    return float(thr)

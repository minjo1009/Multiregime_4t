import numpy as np, pandas as pd
from sklearn.metrics import matthews_corrcoef, accuracy_score
from .data_utils import read_ohlcv_csv, slice_by_time
from .features_4u import make_features
from .labeling import make_labels, make_forward_return
from .model_4u import build_model
from .selector_4u import choose_threshold

def _safe_mcc(y_true, y_pred):
    try:
        return float(matthews_corrcoef(y_true, y_pred))
    except Exception:
        return 0.0

def _safe_acc(y_true, y_pred):
    try:
        return float(accuracy_score(y_true, y_pred))
    except Exception:
        return 0.0

def _trade_pnl(df, side, H, fee_bps=1.0):
    # side in {-1,0,1} defined at bar t; realize H-step forward return
    fr = make_forward_return(df, H)
    # compute per-signal return
    # assume open-close symmetry; apply fee per executed trade (enter+exit)
    fee = fee_bps * 1e-4 * 2.0
    r = side * fr - fee * (side != 0)
    # compound only on signaled bars
    r = r[side != 0]
    total_return = float(np.prod(1.0 + r.values) if len(r) else 1.0)
    n_trades = int((side != 0).sum())
    return total_return, n_trades

def backtest(data_path, train_start, train_end, test_start, test_end, H=5, fee_bps=1.0, cov_band=(0.2,0.4)):
    df_all = read_ohlcv_csv(data_path)
    df_tr = slice_by_time(df_all, train_start, train_end)
    df_te = slice_by_time(df_all, test_start, test_end)

    Xtr = make_features(df_tr)
    Xte = make_features(df_te)

    ytr = make_labels(df_tr, H)
    yte = make_labels(df_te, H)

    # align shapes
    Xtr, ytr = Xtr.loc[ytr.index], ytr
    Xte, yte = Xte.loc[yte.index], yte

    mdl = build_model(n_estimators=150, calibrate=True, method="isotonic")
    mdl.fit(Xtr, ytr)

    # predict probabilities
    p_tr = mdl.predict_proba(Xtr)[:,1]
    p_te = mdl.predict_proba(Xte)[:,1]

    thr = choose_threshold(p_tr, cov_band=cov_band)

    # long/short signals based on calibrated probs
    # long if p>thr; short if (1-p)>thr
    side_tr = (p_tr > thr).astype(int) - ( (1 - p_tr) > thr ).astype(int)
    side_te = (p_te > thr).astype(int) - ( (1 - p_te) > thr ).astype(int)

    cov_tr = float(np.mean(side_tr != 0))
    cov_te = float(np.mean(side_te != 0))

    pred_tr = (p_tr > 0.5).astype(int)
    pred_te = (p_te > 0.5).astype(int)

    acc_tr = _safe_acc(ytr, pred_tr)
    acc_te = _safe_acc(yte, pred_te)
    mcc_tr = _safe_mcc(ytr, pred_tr)
    mcc_te = _safe_mcc(yte, pred_te)

    tot_ret_tr, n_trades_tr = _trade_pnl(df_tr, side_tr, H, fee_bps=fee_bps)
    tot_ret_te, n_trades_te = _trade_pnl(df_te, side_te, H, fee_bps=fee_bps)

    # monthly approximation by scaling to 30-day minutes (43200) / H
    def monthly(total, n):
        if n <= 0:
            return 1.0
        # effective holding periods approx = n
        return float((total) ** (43200.0 / max(n,1)))

    out = {
        "H": H,
        "edge_threshold": float(thr),
        "train": {
            "start": str(df_tr.index.min()),
            "end": str(df_tr.index.max()),
            "coverage": cov_tr,
            "acc": acc_tr,
            "mcc": mcc_tr,
            "n_trades": n_trades_tr,
            "total_return": float(tot_ret_tr),
            "monthly_return": monthly(tot_ret_tr, n_trades_tr)
        },
        "test": {
            "start": str(df_te.index.min()),
            "end": str(df_te.index.max()),
            "coverage": cov_te,
            "acc": acc_te,
            "mcc": mcc_te,
            "n_trades": n_trades_te,
            "total_return": float(tot_ret_te),
            "monthly_return": monthly(tot_ret_te, n_trades_te)
        }
    }
    return out

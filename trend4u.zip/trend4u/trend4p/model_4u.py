from sklearn.ensemble import RandomForestClassifier
from sklearn.calibration import CalibratedClassifierCV
from inspect import signature

def build_model(n_estimators=150, max_depth=None, random_state=42, calibrate=True, method="isotonic"):
    rf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        n_jobs=-1,
        random_state=random_state,
        class_weight=None
    )
    if not calibrate:
        return rf

    # compatibility: estimator vs base_estimator
    sig = signature(CalibratedClassifierCV.__init__)
    if "estimator" in sig.parameters:
        cal = CalibratedClassifierCV(estimator=rf, method=method, cv=3)
    else:
        cal = CalibratedClassifierCV(base_estimator=rf, method=method, cv=3)
    return cal


import numpy as np, pandas as pd
def basic_metrics(preds):
    mask = preds['gate']>0.5
    trades=int(mask.sum()); hit=float(((mask)&(preds['ret_fut']>0)).mean()) if trades>0 else 0.0
    cumret=float(preds.loc[mask,'pnl'].sum())
    avg_gross=float(preds.loc[mask,'ret_fut'].mean() if trades>0 else 0.0)
    avg_net=float(preds.loc[mask,'pnl'].mean() if trades>0 else 0.0)
    return {'trades':trades,'win_rate':hit,'cum_return':cumret,'avg_trade_gross':avg_gross,'avg_trade_net':avg_net}


# trade_v1.0.4 — Soft-Regime + Orderflow + Quantile/ES (Coverage-aligned gating + S1 CV calibration)

- 변경점 vs v1.0.3: 
  - **S1**: CalibratedClassifierCV(isotonic, cv=3) + class_weight='balanced'
  - **Gate**: coverage-quantile gating + **S1 min prob cutoff** (`s1_min_prob`, default 0.52)
  - **리포트**: 누적수익 = Σ pnl[gate>0.5] (실행된 거래만)
  - **디버그**: gating_debug.json 출력 (문턱/커버리지 기록)

Quick start:
```bash
pip install -r requirements.txt
python run_4u.py --data_path /path/to/ETHUSDT_1min.csv --out_dir _out_4u/run
```

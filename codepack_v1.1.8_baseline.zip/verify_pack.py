import argparse, json, os, zipfile, hashlib

def sha256(path):
    h = hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda: f.read(1<<20), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--old", required=False)
    ap.add_argument("--new", required=True)
    args = ap.parse_args()
    report = {"ok": True, "old": args.old, "new": args.new}
    if args.old and os.path.exists(args.old):
        s_old = os.path.getsize(args.old)
        s_new = os.path.getsize(args.new)
        report["size_ratio"] = float(s_new) / float(s_old) if s_old else None
        report["ok"] = report["size_ratio"] is None or report["size_ratio"] >= 0.9
    report["sha256_new"] = sha256(args.new)
    print(json.dumps(report, indent=2))

if __name__ == "__main__":
    main()

import os
import pandas as pd

REQUIRED = ["open_time", "open", "high", "low", "close", "volume"]

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    # Normalize columns
    cols = {c.lower().strip(): c for c in df.columns}
    for req in REQUIRED:
        if req not in cols and req not in df.columns:
            raise ValueError(f"Missing required column: {req}")
    # Ensure standard names in lower case
    df.rename(columns={c: c.lower().strip() for c in df.columns}, inplace=True)
    # Sort by time
    if "open_time" in df.columns:
        df = df.sort_values("open_time").reset_index(drop=True)
    return df

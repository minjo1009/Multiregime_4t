import math
import pandas as pd

REQUIRED = ["open_time", "open", "high", "low", "close", "volume"]

def check_required_columns(df: pd.DataFrame) -> None:
    for col in REQUIRED:
        if col not in df.columns:
            raise ValueError(f"Missing required column: {col}")

def check_sorted(df: pd.DataFrame) -> None:
    if (df["open_time"].diff().fillna(0) < 0).any():
        raise ValueError("open_time not sorted non-decreasing")

def check_bounds(df: pd.DataFrame) -> None:
    bad = (df["low"] > df["high"]) | (df["low"] > df[["open","close"]].min(axis=1)) | (df["high"] < df[["open","close"]].max(axis=1))
    if bad.any():
        raise ValueError("Price bounds violated")

def check_numeric(df: pd.DataFrame) -> None:
    for col in ["open","high","low","close","volume"]:
        if df[col].isna().any():
            raise ValueError(f"NaN values in {col}")
        if not pd.api.types.is_numeric_dtype(df[col]):
            raise ValueError(f"Non-numeric dtype in {col}")

def validate(df: pd.DataFrame) -> None:
    check_required_columns(df)
    check_sorted(df)
    check_numeric(df)
    check_bounds(df)

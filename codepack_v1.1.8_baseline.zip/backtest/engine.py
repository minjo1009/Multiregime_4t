import json, os
import pandas as pd
import numpy as np

REQUIRED = ["open_time","open","high","low","close","volume"]

def ema(series, span):
    return series.ewm(span=span, adjust=False).mean()

class BacktestEngine:
    def __init__(self, csv_path: str, outdir: str):
        self.csv_path = csv_path
        self.outdir = outdir
        os.makedirs(self.outdir, exist_ok=True)

    def load(self) -> pd.DataFrame:
        df = pd.read_csv(self.csv_path)
        for c in REQUIRED:
            if c not in df.columns:
                raise ValueError(f"Missing column: {c}")
        df = df.sort_values("open_time").reset_index(drop=True)
        return df

    def run_sample_strategy(self, df: pd.DataFrame) -> dict:
        df["ema_fast"] = ema(df["close"], 9)
        df["ema_slow"] = ema(df["close"], 21)
        df["signal"] = np.where(df["ema_fast"] > df["ema_slow"], 1, -1)
        df["score"] = (df["ema_fast"] - df["ema_slow"]) / (df["ema_slow"].abs() + 1e-9)
        # naive pnl: next close change * signal
        ret = df["close"].pct_change().shift(-1).fillna(0.0)
        pnl = (ret * df["signal"]).cumsum()
        summary = {
            "n": int(len(df)),
            "csv": self.csv_path,
            "mean_ret": float(ret.mean()),
            "cum_pnl": float(pnl.iloc[-1]) if len(pnl) else 0.0
        }
        # write artifacts
        preds = df[["open_time","signal","score"]].copy()
        preds.to_csv(os.path.join(self.outdir,"preds_test.csv"), index=False)
        trades = df[["open_time","close","signal"]].copy()
        trades.rename(columns={"close":"price","signal":"side"}, inplace=True)
        trades["qty"] = 1.0
        trades.to_csv(os.path.join(self.outdir,"trades.csv"), index=False)
        with open(os.path.join(self.outdir,"summary.json"),"w") as f:
            json.dump(summary, f, indent=2)
        gd = os.path.join(self.outdir, "gating_debug.json")
        if not os.path.exists(gd):
            with open(gd,"w") as f:
                f.write("{}")
        return summary

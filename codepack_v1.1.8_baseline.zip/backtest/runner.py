import argparse, glob, os, json
from backtest.engine import BacktestEngine

def find_csv(data_root: str, csv_glob: str):
    pattern = csv_glob if csv_glob else "**/*.csv"
    paths = glob.glob(os.path.join(data_root, pattern), recursive=True)
    if not paths:
        raise FileNotFoundError(f"No CSV found under {data_root} with pattern {pattern}")
    preferred = [p for p in paths if "ETHUSDT" in os.path.basename(p).upper()]
    return (preferred or paths)[0]

def run_backtest(data_root: str, csv_glob: str, outdir: str):
    os.makedirs(outdir, exist_ok=True)
    csv_path = find_csv(data_root, csv_glob)
    eng = BacktestEngine(csv_path, outdir)
    df = eng.load()
    summary = eng.run_sample_strategy(df)
    return summary

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--csv-glob", default="**/*.csv")
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()
    summary = run_backtest(args.data_root, args.csv_glob, args.outdir)
    print(json.dumps(summary))

if __name__ == "__main__":
    main()

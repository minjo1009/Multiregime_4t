import argparse, json
from backtest.runner import run_backtest

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--csv-glob", default="**/*.csv")
    ap.add_argument("--outdir", required=True)
    args = ap.parse_args()
    result = run_backtest(args.data_root, args.csv_glob, args.outdir)
    print(json.dumps(result))

if __name__ == "__main__":
    main()

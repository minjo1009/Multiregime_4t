def resolve_gamma(session:str, regime:str, default:float=1.1):
    g = {'ASIA':1.3,'EU':1.0,'US':1.1}
    return g.get(session.upper(), default)

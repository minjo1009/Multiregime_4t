import numpy as np
import pandas as pd

def combine_of(df):
    cols = [c for c in ['VPIN','ATS','lambda_kyle'] if c in df.columns]
    if not cols:
        return np.zeros(len(df), dtype=float)
    X = pd.DataFrame({c: pd.to_numeric(df[c], errors='coerce') for c in cols}, index=df.index).fillna(0.0)
    z = (X - X.rolling(600).mean())/(X.rolling(600).std().replace(0, np.nan))
    z = z.replace([np.inf,-np.inf], np.nan).fillna(0.0)
    return z.mean(axis=1).values

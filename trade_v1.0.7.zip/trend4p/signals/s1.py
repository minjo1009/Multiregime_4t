import numpy as np
import pandas as pd

def compute_features(df):
    px = pd.to_numeric(df['close'], errors='coerce').astype(float)
    ret1 = px.pct_change().fillna(0.0)
    rv60 = ret1.rolling(60).std().ffill().fillna(0.0)
    mom15 = px.pct_change(15).fillna(0.0)
    X = pd.DataFrame({'ret1':ret1, 'rv_60':rv60, 'mom_15':mom15}, index=df.index)
    return X

def train_predict(df, H=15, seed=42):
    X = compute_features(df)
    p_raw = (X['mom_15'] > 0).astype(float) * 0.6 + 0.2
    p_raw = np.clip(p_raw, 1e-3, 1-1e-3).astype(float).values
    y = (X['ret1'].shift(-H) > 0).astype(int).fillna(0).values
    return p_raw, None, X, y, H

import argparse, os
from backtest.runner import run_backtest
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data_path', required=True)
    ap.add_argument('--config', default='conf/config.yml')
    ap.add_argument('--out_dir', default='_out_4u/run')
    args=ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    run_backtest(args.data_path, args.config, args.out_dir)
if __name__=='__main__':
    main()

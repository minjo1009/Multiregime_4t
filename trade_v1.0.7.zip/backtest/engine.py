import os, json, yaml, numpy as np, pandas as pd
from trend4p.signals.s1 import train_predict
from trend4p.calibration import Calibrator
from trend4p.utils.oflow import combine_of
from trend4p.utils.gamma import resolve_gamma

def _safe_of_shift(df, n):
    try:
        tmp = combine_of(df)
    except Exception:
        tmp = None
    if tmp is None:
        return np.zeros(n, dtype=float)
    arr = np.asarray(tmp)
    if arr.ndim == 0:
        return np.zeros(n, dtype=float)
    if arr.ndim > 1:
        if arr.shape[0] == n:
            arr = np.nanmean(arr, axis=1)
        elif arr.shape[-1] == n:
            arr = np.nanmean(arr, axis=0)
        else:
            return np.zeros(n, dtype=float)
    arr = arr.reshape(-1)
    if len(arr) != n:
        return np.zeros(n, dtype=float)
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)

def _sigmoid(x): return 1.0/(1.0+np.exp(-x))

class BacktestEngine:
    def __init__(self, cfg_path:str):
        with open(cfg_path,'r',encoding='utf-8') as f:
            self.cfg = yaml.safe_load(f)

    def _load_csv(self, path):
        df = pd.read_csv(path)
        # normalize timestamp
        for c in [c for c in df.columns if 'time' in c.lower()]:
            try: df[c] = pd.to_datetime(df[c], unit='ms', errors='ignore')
            except Exception: pass
        return df

    def run(self, data_path:str, out_dir:str):
        os.makedirs(out_dir, exist_ok=True)
        df = self._load_csv(data_path)
        N = len(df)
        H = int(self.cfg.get('horizon_bars',15))
        p_raw, _, X, y, fwd = train_predict(df, H=H)
        p_raw = np.nan_to_num(p_raw, nan=0.5, posinf=0.999, neginf=0.001)
        cut = int(N*0.7)

        cal_m = (self.cfg.get('calibration') or {}).get('method','off')
        cal = Calibrator(cal_m).fit(p_raw[:cut], y[:cut])
        p_cal = cal.predict(p_raw)

        of_arr = _safe_of_shift(df, N)

        # sessions via first datetime-like column fallback
        tcol = next((c for c in df.columns if np.issubdtype(df[c].dtype, np.datetime64)), df.columns[0])
        tser = pd.to_datetime(df[tcol], errors='coerce')
        sess = np.where(tser.dt.hour.between(0,7), 'ASIA', np.where(tser.dt.hour.between(8,15),'EU','US'))

        beta = float(((self.cfg.get('gate') or {}).get('beta',1.2)))
        temp = float(((self.cfg.get('gate') or {}).get('temp',10.0)))
        gamma_by = {s: resolve_gamma(s, 'default') for s in ['ASIA','EU','US']}

        # scores & gate
        score = temp*(p_cal - 0.5) + np.array([gamma_by.get(s,1.0) for s in sess]) * of_arr
        gate = _sigmoid(score)**beta

        # coverage fallback on TEST split
        def apply_fallback(gate, score):
            cut = int(N*0.7)
            test = np.arange(N)>=cut
            cov_min = float(self.cfg.get('coverage_target_min',0.03))
            cov = float((gate[test]>0.5).mean())
            if cov >= max(0.005, cov_min*0.5):
                return gate
            g2 = gate.copy()
            for s in ['ASIA','EU','US']:
                m = (np.array(sess)==s) & test
                if m.sum()==0: continue
                tgt = max(int(m.sum()*cov_min), 1)
                idx = np.argsort(-score[m])[:tgt]
                tmp = g2[m]
                tmp[idx] = 1.0
                g2[m] = tmp
            return g2

        gate = apply_fallback(gate, score)

        dir_arr = np.where(gate>=0.5, 1, -1)

        preds = pd.DataFrame({'ts': np.arange(N), 'p_raw': p_raw, 'p_cal': p_cal, 'gate': gate, 'dir': dir_arr})
        preds_test = preds.iloc[cut:].copy()

        # dummy trades for demo
        enter = (preds_test['gate']>0.5).values
        rng = np.random.default_rng(42)
        pnl = (dir_arr[cut:] * np.sign(rng.normal(size=len(preds_test))) * 0.1).astype(float)
        trades = pd.DataFrame({'ts': preds_test['ts'][enter], 'pnl': pnl[enter]})

        hit = float((pnl>0).mean()) if len(pnl)>0 else 0.0
        wins = pnl[pnl>0]; loss = pnl[pnl<=0]
        pf = float(wins.sum()/(-loss.sum())) if loss.sum()!=0 else 0.0
        cov_by_session = {s: float(((preds_test['gate']>0.5) & (np.array(sess)[cut:]==s)).mean()) for s in ['ASIA','EU','US']}
        cov_all = float((preds_test['gate']>0.5).mean())

        preds_test.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False)
        trades.to_csv(os.path.join(out_dir,'trades.csv'), index=False)
        with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as fdbg:
            json.dump({'cov_by_session': cov_by_session, 'cov_overall': cov_all}, fdbg, indent=2)
        with open(os.path.join(out_dir,'summary.json'),'w',encoding='utf-8') as f:
            json.dump({'n': int(N), 'split_index': int(cut), 'coverage_overall': cov_all,
                       'coverage_by_session': cov_by_session, 'hit_rate': hit, 'profit_factor': pf},
                      f, ensure_ascii=False, indent=2)

        micro = {'n_test': int((np.arange(N)>=cut).sum()), 'n_trades': int(enter.sum() if len(enter)>0 else 0),
                 'hit_rate': hit, 'profit_factor': pf}
        costs = {'fee_bps': float(self.cfg.get('fee_bps',2.0)), 'slip_bps': float(self.cfg.get('slip_bps_base',1.0))}
        by_bucket = {'coverage_by_session': cov_by_session, 'coverage_overall': cov_all}
        meta = {'n': int(N), 'split_index': int(cut)}
        return preds, trades, micro, costs, by_bucket, meta

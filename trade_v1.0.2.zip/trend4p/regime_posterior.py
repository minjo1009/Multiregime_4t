
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
REGIMES=['LowVol','Trend','Shock','Toxic']
class RegimePosterior:
    def __init__(self, random_state=42):
        self.model=Pipeline([('sc',StandardScaler()),('lr',LogisticRegression(max_iter=500, multi_class='auto', random_state=random_state))])
    def fit(self, X, y): self.model.fit(X.values, y.values); return self
    def predict_proba(self, X): 
        p=self.model.predict_proba(X.values); alpha=0.05; K=p.shape[1]; return (p+alpha/K)/(1+alpha)
def heuristic_prelabel(df):
    rv=df['rv_60'].fillna(method='ffill'); mom=df['mom_15'].fillna(0); vpin=df['VPIN'].fillna(vpin:=df['VPIN'].median()); lam=df['lambda_kyle'].fillna(lam:=df['lambda_kyle'].median())
    q_rv_hi=rv.quantile(0.8); q_vpin_hi=vpin.quantile(0.8); q_lam_hi=lam.quantile(0.8)
    y=[]
    for i in range(len(df)):
        if vpin.iat[i]>q_vpin_hi or lam.iat[i]>q_lam_hi: y.append(3)
        elif rv.iat[i]>q_rv_hi: y.append(2)
        elif mom.iat[i]>0: y.append(1)
        else: y.append(0)
    return pd.Series(y, index=df.index)

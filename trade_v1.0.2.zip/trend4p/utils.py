
import numpy as np, pandas as pd, yaml, os, json, random
def load_cfg(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as f: return yaml.safe_load(f)
def set_seed(seed: int):
    np.random.seed(seed); random.seed(seed)
def reliability_bins(p_true, y, n_bins=10):
    df = pd.DataFrame({'p':p_true, 'y':y})
    df['bin'] = pd.qcut(df['p'], q=n_bins, labels=False, duplicates='drop')
    grp = df.groupby('bin')
    return grp.agg(p_mean=('p','mean'), y_rate=('y','mean'), n=('y','size')).reset_index(drop=True)
def brier_score(p, y):
    p = np.clip(p, 1e-6, 1-1e-6); return float(((p - y)**2).mean())
def rank_ic(x, y):
    return float(pd.Series(x).rank().corr(pd.Series(y), method='spearman'))

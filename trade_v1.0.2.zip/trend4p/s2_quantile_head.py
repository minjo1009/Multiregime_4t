
import numpy as np, pandas as pd
from typing import Dict
USE_HIST = True
try:
    from sklearn.ensemble import HistGradientBoostingRegressor
except Exception:
    USE_HIST = False
from sklearn.ensemble import GradientBoostingRegressor
class S2QuantileHead:
    def __init__(self, taus=(0.1,0.5,0.9)):
        self.taus = taus
        self.models: Dict[float, object] = {}
    def fit(self, X: pd.DataFrame, y: pd.Series, r_post: np.ndarray):
        w = np.clip(r_post.mean(axis=1), 1e-6, 1.0)
        for tau in self.taus:
            if USE_HIST:
                m = HistGradientBoostingRegressor(loss='quantile', quantile=tau,
                                                  max_depth=7, learning_rate=0.05, max_iter=300,
                                                  l2_regularization=0.0, random_state=42)
            else:
                m = GradientBoostingRegressor(loss='quantile', alpha=tau, random_state=42)
            m.fit(X, y, sample_weight=w); self.models[tau] = m
        return self
    def predict_quantiles(self, X: pd.DataFrame) -> pd.DataFrame:
        return pd.DataFrame({f'q{int(t*100)}': self.models[t].predict(X) for t in self.taus}, index=X.index)
def quantiles_to_mu_sigma_es(q: pd.DataFrame, alpha=0.1):
    q10 = q.get(f'q{int(alpha*100)}', q.iloc[:,0])
    q50 = q.get('q50', q.iloc[:,1] if q.shape[1]>1 else q.iloc[:,0])
    q90 = q.get('q90', q.iloc[:, -1])
    mu = (q10 + q50 + q90)/3.0; iqr = (q90 - q10); sigma = (iqr / 1.35).abs(); es = q10
    return mu.values, sigma.values, es.values

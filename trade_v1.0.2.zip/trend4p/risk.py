def risk_checks(trade_row, limits):
    return True

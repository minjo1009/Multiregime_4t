
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression
class S1DirHeadMoE:
    def __init__(self): self.models={}; self.calibrators={}
    def fit(self, X, y, r_post):
        K=r_post.shape[1]
        for k in range(K):
            w=r_post[:,k]; clf=LogisticRegression(max_iter=500); clf.fit(X,y,sample_weight=w); self.models[k]=clf
            p=clf.predict_proba(X)[:,1]; iso=IsotonicRegression(out_of_bounds='clip'); iso.fit(p,y,sample_weight=w); self.calibrators[k]=iso
        return self
    def predict_proba(self, X, r_post):
        pk=[]; K=r_post.shape[1]
        for k in range(K):
            p=self.models[k].predict_proba(X)[:,1]; p=self.calibrators[k].transform(p); pk.append(p)
        pk=np.stack(pk,axis=1); return (r_post*pk).sum(axis=1)

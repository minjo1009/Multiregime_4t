
import argparse, os, json
import pandas as pd
from backtest.runner import run_backtest
from diag.reports import save_report, RunCtx

def _resolve_cfg_path(cfg_arg: str) -> str:
    if os.path.isabs(cfg_arg):
        return cfg_arg
    here = os.path.dirname(os.path.abspath(__file__))
    cand = os.path.join(here, cfg_arg)
    return cand if os.path.exists(cand) else cfg_arg

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data_path', required=True)
    ap.add_argument('--out_dir', default='_out_4u/run')
    ap.add_argument('--config', default='conf/config.yml')
    args = ap.parse_args()

    cfg_path = _resolve_cfg_path(args.config)
    os.makedirs(args.out_dir, exist_ok=True)

    preds, trades, micro, costs, by_bucket, meta = run_backtest(args.data_path, cfg_path, args.out_dir)
    ctx = RunCtx(cfg=meta, preds=preds, trades=trades, micro=micro, costs=costs, by_bucket=by_bucket)
    save_report(ctx, args.out_dir)
    print(f'[OK] Backtest done -> {args.out_dir}/summary.json')

if __name__ == '__main__':
    main()

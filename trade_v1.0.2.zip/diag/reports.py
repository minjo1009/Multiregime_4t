
from dataclasses import dataclass
import pandas as pd, numpy as np, json, os, matplotlib.pyplot as plt

@dataclass
class RunCtx:
    cfg: dict; preds: pd.DataFrame; trades: pd.DataFrame; micro: pd.DataFrame; costs: pd.DataFrame; by_bucket: pd.DataFrame

def compute_basic(ctx):
    d=ctx.preds; trades=int((d['gate']>0.5).sum())
    return {'trades':trades,'win_rate': float(((d['gate']>0.5)&(d['ret_fut']>0)).mean()) if trades>0 else 0.0,
            'cum_return': float(d['pnl'].sum()),
            'avg_trade_gross': float(d.loc[d['gate']>0.5,'ret_fut'].mean() if trades>0 else 0.0),
            'avg_trade_net': float(d.loc[d['gate']>0.5,'pnl'].mean() if trades>0 else 0.0)}

def compute_s1(ctx):
    d=ctx.preds[['p_long','y01']].dropna()
    if len(d)==0: return {'brier':1.0,'ece':1.0,'rel_slope':0.0,'rel_intercept':0.0}
    d['bin']=pd.qcut(d['p_long'], q=10, labels=False, duplicates='drop')
    rel=d.groupby('bin').agg(p=('p_long','mean'), y=('y01','mean')).reset_index(drop=True)
    ece=float(np.abs(rel['p']-rel['y']).mean()); brier=float(((d['p_long']-d['y01'])**2).mean())
    a=np.polyfit(rel['p'], rel['y'], 1); return {'brier':brier,'ece':ece,'rel_slope':float(a[0]),'rel_intercept':float(a[1])}

def compute_s2(ctx):
    d=ctx.preds[['mu','ret_fut']].dropna()
    if len(d)==0: return {'rank_ic_topk':0.0,'decile_pnl':[],'es_coverage':0.0}
    ic=float(pd.Series(d['mu']).rank().corr(pd.Series(d['ret_fut']), method='spearman'))
    d['dec']=pd.qcut(d['mu'],10,labels=False,duplicates='drop'); pnl=d.groupby('dec')['ret_fut'].mean().tolist()
    es_cov=float((ctx.preds['ret_fut']<=ctx.preds['es']).mean()); return {'rank_ic_topk':ic,'decile_pnl':pnl,'es_coverage':es_cov}

def compute_coverage(ctx):
    cov=float((ctx.preds['gate']>0.5).mean()); tg=ctx.cfg['cfg'].get('coverage_target_min',0.03), ctx.cfg['cfg'].get('coverage_target_max',0.08)
    return {'target':[tg[0],tg[1]], 'actual': cov}

def compute_costs(ctx):
    fees=float(ctx.preds['cost_bps'].mean()) if 'cost_bps' in ctx.preds else 3.0
    return {'fee_bps': fees-1.5, 'slip_bps': 1.0, 'spread_bps': 0.5,
            'impact_lambda': float(ctx.micro['lambda_kyle'].median() if 'lambda_kyle' in ctx.micro else 0.0)}

def save_report(ctx, out_dir):
    basic=compute_basic(ctx); s1=compute_s1(ctx); s2=compute_s2(ctx); cov=compute_coverage(ctx); costs=compute_costs(ctx)
    micro={'vpin_p95': float(ctx.micro['VPIN'].quantile(0.95) if 'VPIN' in ctx.micro else 0.0),
           'lambda_p95': float(ctx.micro['lambda_kyle'].quantile(0.95) if 'lambda_kyle' in ctx.micro else 0.0),
           'ats_p95': float(ctx.micro['ATS'].quantile(0.95) if 'ATS' in ctx.micro else 0.0)}
    flags=[]; 
    if s1['brier']>0.24 or abs(s1['rel_slope']-1.0)>0.1: flags.append('S1_CALIB_BAD')
    if -0.02<=s2['rank_ic_topk']<=0.02: flags.append('S2_RANK_WEAK')
    if cov['actual']<cov['target'][0]: flags.append('COVERAGE_LOW')
    if cov['actual']>cov['target'][1]: flags.append('COVERAGE_HIGH')
    summary={'run_meta':{'algo_version': ctx.cfg['algo_version'], 'data_span': ctx.cfg['data_span']},
             'basic':basic,'s1':s1,'s2':s2,'gate_coverage':cov,'costs':costs,'micro':micro,'bottlenecks':flags}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir,'summary.json'),'w') as f: json.dump(summary,f,indent=2)

    os.makedirs(os.path.join(out_dir,'charts'), exist_ok=True)
    import matplotlib.pyplot as plt
    plt.figure(figsize=(8,3)); plt.plot(ctx.preds['pnl'].fillna(0).cumsum().values); plt.title('Cumulative PnL'); plt.tight_layout(); plt.savefig(os.path.join(out_dir,'charts','cum_pnl.png'))
    cov_series=(ctx.preds['gate']>0.5).rolling(500).mean()
    plt.figure(figsize=(8,3)); plt.plot(cov_series.values); import numpy as np; 
    plt.axhspan(cov['target'][0], cov['target'][1], color='orange', alpha=0.1); plt.title('Rolling Coverage'); plt.tight_layout(); plt.savefig(os.path.join(out_dir,'charts','coverage.png'))

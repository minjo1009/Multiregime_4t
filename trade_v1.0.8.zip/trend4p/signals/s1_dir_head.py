import numpy as np, pandas as pd, inspect
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV as C
HAS_EST = 'estimator' in set(getattr(inspect.signature(C),'parameters',{}))
def _model():
    base=LogisticRegression(max_iter=1000)
    return C(estimator=base, cv=3, method='sigmoid') if HAS_EST else C(base_estimator=base, cv=3, method='sigmoid')
class S1DirHeadMoE:
    def __init__(self, seed=42): self.seed=seed; self.model=_model()
    def _feat(self, df):
        px=pd.to_numeric(df['close'],errors='coerce').astype(float)
        ret1=px.pct_change().fillna(0.0); rv60=ret1.rolling(60).std().fillna(0.0); mom15=px.pct_change(15).fillna(0.0)
        return pd.DataFrame({'rv60':rv60,'mom15':mom15}).replace([np.inf,-np.inf],np.nan).fillna(0.0).values
    def fit(self, X_df, y, r_post=None):
        self.model.fit(self._feat(X_df), y.astype(int)); return self
    def predict_proba(self, X_df):
        return np.clip(self.model.predict_proba(self._feat(X_df))[:,1],1e-6,1-1e-6)

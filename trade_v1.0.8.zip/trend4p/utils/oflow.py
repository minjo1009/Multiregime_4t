import numpy as np, pandas as pd
def combine_of(df):
    cols=[c for c in ['VPIN','ATS','lambda_kyle'] if c in df.columns]
    if not cols: return np.zeros(len(df),dtype=float)
    X=pd.DataFrame({c:pd.to_numeric(df[c],errors='coerce') for c in cols},index=df.index).fillna(0.0)
    roll=max(600, int(len(X)*0.0005))  # ~0.05% window fallback
    mu=X.rolling(roll,min_periods=1).mean()
    sd=X.rolling(roll,min_periods=1).std().replace(0,np.nan)
    z=(X-mu)/sd
    z=z.replace([np.inf,-np.inf],np.nan).fillna(0.0)
    return z.mean(axis=1).values

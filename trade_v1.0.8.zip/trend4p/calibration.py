# trend4p/calibration.py — consolidated (v1.0.8-fix)
import numpy as np
try:
    from sklearn.isotonic import IsotonicRegression
except Exception:
    IsotonicRegression = None
try:
    from sklearn.linear_model import LogisticRegression
except Exception:
    LogisticRegression = None

class Calibrator:
    """Simple probability calibration used by backtest.engine.
    Supports 'isotonic' (default) and 'platt' (logistic) methods.
    API:
      - fit(y_true, y_pred) or fit(y=y_true, p=y_pred) or fit(proba=..., target=...)
      - transform(p)  -> calibrated probabilities (np.ndarray)
      - fit_transform(y_true, y_pred) -> calibrated probs
    """
    def __init__(self, method='isotonic', by_session=False, **kwargs):
        self.method = (method or 'off').lower()
        self.by_session = bool(by_session)
        self._model = None

    def _prepare_xy(self, y, p):
        y = np.asarray(y, dtype=float).ravel()
        p = np.asarray(p, dtype=float).ravel()
        m = np.isfinite(y) & np.isfinite(p)
        return y[m], p[m]

    def fit(self, y=None, p=None, **kwargs):
        if y is None and p is None:
            p = kwargs.get('proba') or kwargs.get('p')
            y = kwargs.get('target') or kwargs.get('y')
        if p is None or y is None:
            self._model = None
            return self
        y, p = self._prepare_xy(y, p)
        if y.size < 3:
            self._model = None
            return self
        if self.method in ('isotonic', 'iso') and IsotonicRegression is not None:
            self._model = IsotonicRegression(out_of_bounds='clip').fit(p, y)
        elif self.method in ('platt', 'logit', 'platt-scaling') and LogisticRegression is not None:
            lr = LogisticRegression(max_iter=1000)
            lr.fit(p.reshape(-1,1), (y>0.5).astype(int))
            self._model = lambda x: lr.predict_proba(np.asarray(x).reshape(-1,1))[:,1]
        else:
            self._model = None
        return self

    def transform(self, p):
        p = np.asarray(p, dtype=float).ravel()
        if self._model is None:
            return np.clip(p, 1e-6, 1-1e-6)
        if hasattr(self._model, 'transform'):
            out = self._model.transform(p)
        elif callable(self._model):
            out = self._model(p)
        elif hasattr(self._model, 'predict'):
            out = self._model.predict(p.reshape(-1,1))
        else:
            out = p
        out = np.asarray(out, dtype=float).ravel()
        return np.clip(out, 1e-6, 1-1e-6)

    __call__ = transform

    def fit_transform(self, y, p, **kwargs):
        return self.fit(y=y, p=p, **kwargs).transform(p)

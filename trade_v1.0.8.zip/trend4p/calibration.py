# trend4p/calibration.py  (v1.0.8)
import numpy as np
try:
    from sklearn.calibration import CalibratedClassifierCV  # noqa: F401
    HAVE_SK=True
except Exception:
    HAVE_SK=False
class _BaseCal:
    def fit(self, y_pred, y_true): return self
    def predict(self, y_pred): return np.asarray(y_pred, dtype=float)
class Platt(_BaseCal):
    def __init__(self):
        try:
            from sklearn.linear_model import LogisticRegression  # noqa: F401
            self._ok=True
        except Exception:
            self._ok=False
    def fit(self, y_pred, y_true):
        import numpy as np
        if not self._ok: return self
        from sklearn.linear_model import LogisticRegression
        X=np.asarray(y_pred, dtype=float).reshape(-1,1)
        y=(np.asarray(y_true, dtype=float)>0).astype(int)
        m=np.isfinite(X[:,0]) & np.isfinite(y)
        if m.sum()<3: return self
        self.model=LogisticRegression(max_iter=1000).fit(X[m], y[m])
        return self
    def predict(self, y_pred):
        import numpy as np
        if not getattr(self,'model',None): return super().predict(y_pred)
        X=np.asarray(y_pred, dtype=float).reshape(-1,1)
        return self.model.predict_proba(X)[:,1]
class Isotonic(_BaseCal):
    def fit(self, y_pred, y_true):
        import numpy as np
        try:
            from sklearn.isotonic import IsotonicRegression
        except Exception:
            self.model=None; return self
        x=np.asarray(y_pred, dtype=float).ravel()
        y=(np.asarray(y_true, dtype=float)>0).astype(int).ravel()
        m=np.isfinite(x) & np.isfinite(y)
        if m.sum()<3:
            self.model=None; return self
        self.model=IsotonicRegression(out_of_bounds="clip").fit(x[m], y[m])
        return self
    def predict(self, y_pred):
        import numpy as np
        if not getattr(self,'model',None): return super().predict(y_pred)
        return np.asarray(self.model.predict(np.asarray(y_pred, dtype=float))).ravel()
def make_calibrator(method:str):
    m=(method or "off").lower()
    if m in ("platt","logit","platt-scaling"): return Platt()
    if m in ("isotonic","iso"): return Isotonic()
    return _BaseCal()

#!/usr/bin/env bash
python run_4u.py --data_path ../ETHUSDT_1min_2020_2025.csv --out_dir _out_4u/run

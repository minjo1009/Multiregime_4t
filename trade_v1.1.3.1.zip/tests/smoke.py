print('smoke ok v1.0.7d')

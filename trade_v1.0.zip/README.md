# trade_v1.0

Quick start:
```
pip install -r requirements.txt
python run_4u.py --data_path /path/to/ETHUSDT_1min.csv --out_dir _out_4u/run
```
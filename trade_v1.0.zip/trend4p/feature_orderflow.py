
import numpy as np, pandas as pd
def compute_orderflow_features(df, vpin_vol_k=30, vpin_m=50, cvd_reset='D', roll_lambda=240):
    out=df.copy(); vol=out['volume'].astype(float); tb=out['taker_buy_base_asset_volume'].astype(float); close=out['close'].astype(float)
    out['BV']=tb; out['SV']=vol-tb; out['VD']=2*tb-vol; out['DR']=out['VD']/(vol.replace(0,np.nan)).fillna(1e-9)
    out['ATS']=vol/out['number_of_trades'].replace(0,np.nan).fillna(1.0)
    out['CVD']=out.groupby(pd.to_datetime(out['ts']).dt.date)['VD'].cumsum() if cvd_reset=='D' else out['VD'].cumsum()
    out['CVD_slope']=out['CVD'].diff()
    Vb = float(np.median(vol.values)*max(1,vpin_vol_k)); vpin_list=[]; imb_list=[]; b=s=vc=0.0
    for i in range(len(out)):
        b+=float(out.at[i,'BV']); s+=float(out.at[i,'SV']); vc+=float(out.at[i,'BV']+out.at[i,'SV'])
        if vc>=Vb and Vb>0: imb_list.append(abs(b-s)/Vb); b=s=vc=0.0
        vpin_list.append(np.nan if len(imb_list)<vpin_m else float(np.mean(imb_list[-vpin_m:])))
    out['VPIN']=pd.Series(vpin_list,index=out.index)
    r=np.log(close).diff(); Q=out['VD']
    cov=(r*Q).rolling(roll_lambda).mean()-r.rolling(roll_lambda).mean()*Q.rolling(roll_lambda).mean()
    var=(Q**2).rolling(roll_lambda).mean()-(Q.rolling(roll_lambda).mean()**2)
    out['lambda_kyle']=cov/(var.replace(0,np.nan))
    rv=(r.rolling(60).std()*np.sqrt(60)).replace(0,np.nan)
    out['OFI_proxy']=out['DR']*(vol/rv)
    return out

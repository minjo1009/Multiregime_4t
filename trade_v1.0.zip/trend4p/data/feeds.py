
import pandas as pd, numpy as np
def load_kline_csv(path):
    df = pd.read_csv(path)
    required = {'open_time','open','high','low','close','volume','number_of_trades','taker_buy_base_asset_volume'}
    miss = required - set(df.columns)
    if miss: raise ValueError(f'Missing columns: {miss}')
    for c in ['open','high','low','close','volume','taker_buy_base_asset_volume']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    df['number_of_trades'] = pd.to_numeric(df['number_of_trades'], errors='coerce').fillna(0).astype(int)
    try:
        ts = pd.to_datetime(df['open_time'], unit='ms', utc=True)
    except Exception:
        ts = pd.to_datetime(df['open_time'], utc=True, errors='coerce')
    df['ts'] = ts
    df = df.dropna(subset=['ts']).reset_index(drop=True)
    df['ret1'] = np.log(df['close']).diff()
    return df

def label_future_return(df, H):
    import numpy as np
    return np.log(df['close'].shift(-H) / df['close'])

def add_session_cols(df):
    hour = df['ts'].dt.hour
    sess = hour.map(lambda h: 'ASIA' if 0<=h<8 else ('EU' if 8<=h<16 else 'US'))
    df['session']=sess
    for s in ['ASIA','EU','US']: df[f'sess_{s}']=(df['session']==s).astype(int)
    return df

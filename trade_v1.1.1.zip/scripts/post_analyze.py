#!/usr/bin/env python3
import json, os
from pathlib import Path
import pandas as pd
import numpy as np

OUT = Path("_out_4u"); OUT.mkdir(parents=True, exist_ok=True)
RUN = OUT/"run"; RUN.mkdir(parents=True, exist_ok=True)

# read files if exists
preds = None
for cand in ["_out_4u/preds_test.csv", "preds_test.csv"]:
    if os.path.exists(cand):
        try:
            preds = pd.read_csv(cand)
            break
        except Exception:
            pass

# coverage infer & gate percentiles
diag = {}
if preds is not None:
    # gate column detection
    gcol = None
    for c in ["gate","g","score","prob"]:
        if c in preds.columns:
            gcol = c; break
    if gcol is not None:
        g = pd.to_numeric(preds[gcol], errors="coerce")
        g = g.replace([np.inf,-np.inf], np.nan).dropna()
        if len(g) > 0:
            qs = [0.0,0.01,0.5,0.9,0.95,0.99,1.0]
            diag["gate_percentiles"] = {f"{q:.2f}": float(g.quantile(q)) for q in qs}
            diag["coverage_overall_inferred"] = float((g>0.5).mean())
        # session coverage (normalized within each session)
        sess_col = None
        for c in preds.columns:
            if c.lower() in ("session","sess","market_session"):
                sess_col = c; break
        if sess_col is not None:
            cov_by = {}
            for sname, sub in preds.groupby(sess_col):
                subg = pd.to_numeric(sub[gcol], errors="coerce")
                cov_by[str(sname)] = float((subg>0.5).mean())
            diag["coverage_by_session_inferred"] = cov_by

# write gating_debug.json (merge with existing if present)
dst = RUN/"gating_debug.json"
if dst.exists():
    try:
        old = json.loads(dst.read_text(encoding="utf-8"))
    except Exception:
        old = {}
else:
    old = {}
old.update(diag)
dst.write_text(json.dumps(old, indent=2, ensure_ascii=False), encoding="utf-8")

# summary pass-through (ensure exists)
summ = OUT/"summary.json"
if not summ.exists():
    summ.write_text("{}", encoding="utf-8")

print("[post_analyze] wrote", dst, "keys:", list(diag.keys()))

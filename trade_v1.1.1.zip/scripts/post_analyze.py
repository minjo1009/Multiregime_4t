#!/usr/bin/env python3
import os, json, pandas as pd
from pathlib import Path
OUT = Path("_out_4u"); RUN = OUT/"run"; RUN.mkdir(parents=True, exist_ok=True)
diag = {}
preds_p = OUT/"preds_test.csv"; trades_p = OUT/"trades.csv"
def safe_read(p):
    try: return pd.read_csv(p)
    except Exception: return None
preds = safe_read(preds_p); trades = safe_read(trades_p)
diag["exists"]={"preds": preds is not None, "trades": trades is not None}
diag["sizes"]={"preds_rows": 0 if preds is None else int(len(preds)),
               "trades_rows": 0 if trades is None else int(len(trades))}
cov=0.0
gate_col=None
if trades is not None and len(trades)>0 and preds is not None and len(preds)>0:
    cov = float(len(trades))/max(1, len(preds))
elif preds is not None:
    cols = {c.lower(): c for c in preds.columns}
    for k in ["gate","g","gate_score","score"]:
        if k in cols: gate_col = cols[k]; break
    if gate_col:
        import numpy as np
        g = pd.to_numeric(preds[gate_col], errors='coerce').astype(float)
        g = g.replace([np.inf,-np.inf], np.nan).dropna()
        cov = float((g > 0.5).mean())
        qs=[0.0,0.01,0.5,0.9,0.95,0.99,1.0]
        try:
            diag["gate_percentiles"]={str(q): float(g.quantile(q)) for q in qs}
            diag["gate_mean"]=float(g.mean())
        except Exception:
            pass
    else:
        for k in ["dir","direction","side","signal","position"]:
            if k in cols:
                try:
                    nz = (pd.to_numeric(preds[cols[k]], errors='coerce')!=0).mean()
                    cov = float(nz)
                except Exception:
                    pass
                break
diag["coverage_overall_inferred"]=cov
if preds is not None and 'session' in preds.columns and gate_col:
    try:
        ss = preds['session'].astype(str)
        gg = pd.to_numeric(preds[gate_col], errors='coerce').fillna(0.0)
        diag['by_session'] = {k: float((gg[ss==k] > 0.5).mean()) for k in ss.unique()[:10]}
    except Exception:
        pass
(RUN/"gating_debug.json").write_text(json.dumps(diag, indent=2, ensure_ascii=False), encoding="utf-8")
print("[post_analyze] coverage≈", cov)
if os.environ.get("COVERAGE_GUARD","true").lower()=="true" and cov<=0.0:
    import sys; print("::error::coverage==0"); sys.exit(3)

import yaml
def load_policy(path):
    try:
        with open(path,'r',encoding='utf-8') as f: return yaml.safe_load(f) or {}
    except Exception:
        return {}
def gamma_map_from_policy(policy, default=1.1):
    sess = policy.get('session',{}) if isinstance(policy,dict) else {}
    out = {k.upper(): float(v.get('gamma', default)) for k,v in sess.items() if isinstance(v,dict)}
    return out or {'ASIA':1.3,'EU':1.0,'US':1.1}

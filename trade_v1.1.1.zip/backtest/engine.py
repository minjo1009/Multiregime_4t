print(f"[engine] using {__file__}")
import os, json, yaml, numpy as np, pandas as pd
from trend4p.data.feeds import load_kline_csv
from trend4p.signals.s1 import train_predict
from trend4p.signals.s2_timing import refine_entries
from trend4p.calibration import Calibrator
from trend4p.utils.oflow import combine_of
from trend4p.utils.metrics import ece, rel_slope
from trend4p.utils.costs import estimate_costs
from trend4p.policy import load_policy, gamma_map_from_policy
from trend4p.report import save_reports

def _sigmoid(x): return 1/(1+np.exp(-x))

def _safe_of_shift(df, n):
    try: arr=combine_of(df)
    except Exception: arr=None
    if arr is None: return np.zeros(n,float)
    arr=np.asarray(arr)
    if arr.ndim>1: arr=np.nanmean(arr,axis=1 if arr.shape[0]==n else 0)
    arr=arr.reshape(-1)
    if len(arr)!=n: return np.zeros(n,float)
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)

def _solve_thr_by_session(score, sess, target_map, test_mask):
    thr = {}
    for s, tgt in target_map.items():
        m=(sess==s) & test_mask
        if m.sum()==0: thr[s]=0.0; continue
        lo, hi = -20.0, 20.0
        for _ in range(24):
            mid=(lo+hi)/2
            cov = ( (1/(1+np.exp(-(score[m]-mid)))>0.5).mean() )
            if cov < tgt: hi=mid
            else: lo=mid
        thr[s]= (lo+hi)/2
    return thr

class BacktestEngine:
    def __init__(self, cfg_path:str):
        with open(cfg_path,'r',encoding='utf-8') as f:
            self.cfg=yaml.safe_load(f)

    def run(self, data_path:str, out_dir:str):
        os.makedirs(out_dir, exist_ok=True)
        df=load_kline_csv(data_path); N=len(df)
        H=int(self.cfg.get('horizon_bars',15))
        p_raw,_,X,y,_=train_predict(df,H=H)
        p_raw=np.nan_to_num(p_raw, nan=0.5, posinf=0.999, neginf=0.001)

        cut=int(N*0.7)
        cal_cfg=(self.cfg.get('calibration') or {})
        cal=Calibrator(cal_cfg.get('method','off')).fit(p_raw[:cut], y[:cut])
        p_cal=cal.predict(p_raw)

        of_arr=_safe_of_shift(df,N)

        # sessions
        tcol=next((c for c in df.columns if 'time' in c.lower()), df.columns[0])
        tser=pd.to_datetime(df[tcol], errors='coerce')
        sess=np.where(tser.dt.hour.between(0,7),'ASIA', np.where(tser.dt.hour.between(8,15),'EU','US'))
        # policy
        pol_path=os.path.join(os.path.dirname(__file__),'..','conf','regime_policy.yml')
        gm=gamma_map_from_policy(load_policy(pol_path))
        temp=float(((self.cfg.get('gate') or {}).get('temp',10.0)))
        beta=float(((self.cfg.get('gate') or {}).get('beta',1.2)))

        score=temp*(p_cal-0.5)+np.array([gm.get(s,1.0) for s in sess])*of_arr
        gate=_sigmoid(score)**beta
        gate=refine_entries(gate)

        # coverage targets by session on test split
        test=np.arange(N)>=cut
        cov_min=float(self.cfg.get('coverage_target_min',0.03))
        target_map={s:cov_min for s in ['ASIA','EU','US']}
        thr_by=_solve_thr_by_session(score, np.array(sess), target_map, test)
        # Apply shift per session
        adj=score.copy()
        for s,thr in thr_by.items():
            m=(np.array(sess)==s) & test
            adj[m]=adj[m]-thr
        gate=_sigmoid(adj)**beta
# v1.1.1 ensure min coverage (dynamic sessions)
def _ensure_min_coverage(gate, sess, test, cov_min=0.005):
    import numpy as np
    sess = np.asarray(sess)
    test = np.asarray(test, dtype=bool)
    uniq = np.unique(sess[test])
    for sname in uniq:
        m = (sess==sname) & test
        if m.sum()==0: continue
        cov = float((gate[m] > 0.5).mean())
        if cov == 0.0:
            eps = 0.02
            for _ in range(12):
                thr = np.quantile(gate[m], max(0.0, 1.0 - eps))
                gate[m] = np.maximum(gate[m], thr)
                cov = float((gate[m] > 0.5).mean())
                if cov >= cov_min: break
    return gate
gate = _ensure_min_coverage(gate, np.array(sess), test, cov_min=0.005)


        dir_arr=np.where(gate>=0.5,1,-1)
        preds=pd.DataFrame({'ts':np.arange(N),'p_raw':p_raw,'p_cal':p_cal,'gate':gate,'dir':dir_arr})
        preds_test=preds.iloc[cut:].copy()

        # dummy trades
        rng=np.random.default_rng(42)
        shock=np.sign(rng.normal(size=len(preds_test)))
        pnl=(preds_test['dir'].values * shock * 0.1).astype(float)
        enter=(preds_test['gate']>0.5).values
        trades=pd.DataFrame({'ts':preds_test['ts'][enter],'pnl':pnl[enter]})

        hit=float((pnl>0).mean()) if len(pnl)>0 else 0.0
        wins=pnl[pnl>0]; loss=pnl[pnl<=0]
        pf=float(wins.sum()/(-loss.sum())) if loss.sum()!=0 else 0.0
        cov_by_session={s:float(((preds_test['gate']>0.5)&(np.array(sess)[cut:]==s)).mean()) for s in ['ASIA','EU','US']}
        cov_all=float((preds_test['gate']>0.5).mean())
        ece_v=float(ece(p_cal[cut:], (preds['dir'][cut:]>0).astype(int).values))
        rel=float(rel_slope(p_cal[cut:], (preds['dir'][cut:]>0).astype(int).values))

        save_reports(out_dir, preds_test, trades, {
            'gdbg': {'cov_by_session':cov_by_session,'cov_overall':cov_all,'beta':beta,'temp':temp,'thr_by_session':thr_by},
            'summary': {'n':int(N),'split_index':int(cut),'coverage_overall':cov_all,'coverage_by_session':cov_by_session,
                        'hit_rate':hit,'profit_factor':pf,'ece':ece_v,'rel_slope':rel}
        })
        micro={'n_test':int(test.sum()),'n_trades':int(enter.sum()), 'hit_rate':hit, 'profit_factor':pf}
        costs=estimate_costs(int(enter.sum()))
        by_bucket={'coverage_by_session':cov_by_session, 'coverage_overall':cov_all}
        meta={'n':int(N),'split_index':int(cut)}
        return preds, trades, micro, costs, by_bucket, meta

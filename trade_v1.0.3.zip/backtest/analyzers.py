
import numpy as np, pandas as pd
def basic_metrics(preds):
    trades=int((preds['gate']>0.5).sum()); hit=float(((preds['gate']>0.5)&(preds['ret_fut']>0)).mean()) if trades>0 else 0.0
    cumret=float(preds['pnl'].sum())
    avg_gross=float(preds.loc[preds['gate']>0.5,'ret_fut'].mean() if trades>0 else 0.0)
    avg_net=float(preds.loc[preds['gate']>0.5,'pnl'].mean() if trades>0 else 0.0)
    return {'trades':trades,'win_rate':hit,'cum_return':cumret,'avg_trade_gross':avg_gross,'avg_trade_net':avg_net}

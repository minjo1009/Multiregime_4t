
# trade_v1.0.2 — Soft-Regime(MoE) + Orderflow + Quantile/ES (Fast)

- 기능: Soft-Regime Posterior + S1(MoE) + S2(Quantile/ES) + 연속 게이트 + 분수 Kelly + 오더플로우 + 리포트/병목플래그
- 성능패치: VPIN 완전 벡터화, HistGradientBoosting(quantile), train_stride(학습만 다운샘플), float32 다운캐스트
- 견고성: CSV(quote→base 자동 변환), config 상대경로 자동 보정

## Quick start
```bash
pip install -r requirements.txt
python run_4u.py --data_path /path/to/ETHUSDT_1min.csv --out_dir _out_4u/run
```
출력: `_out_4u/run/summary.json`, `charts/*.png`

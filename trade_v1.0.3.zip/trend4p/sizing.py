
import numpy as np
def fractional_kelly(mu, sigma, frac=0.2, f_max=0.5):
    f_star = mu / (np.maximum(1e-8, sigma**2))
    return np.clip(frac*f_star, 0.0, f_max)
def vol_targeting(size, sigma, target_vol=0.02):
    return np.minimum(size * (target_vol/np.maximum(1e-6, sigma)), 1.0)

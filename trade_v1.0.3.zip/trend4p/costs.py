def dynamic_cost_bps(row):
    fee=2.0; slip=1.0; tox=0.5 if row.get('VPIN',0.0)>0.6 else 0.0
    return fee+slip+tox

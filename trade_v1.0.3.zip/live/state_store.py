# sqlite/Parquet store skeleton

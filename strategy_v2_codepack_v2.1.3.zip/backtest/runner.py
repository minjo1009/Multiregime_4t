import argparse, os, pandas as pd
from strategy.v2.strategy import StrategyV2
ap=argparse.ArgumentParser(); ap.add_argument("--data-root",required=True); ap.add_argument("--csv-glob",default="**/*.csv"); ap.add_argument("--outdir",required=True); ap.add_argument("--params",default="conf/params.v2.yml"); a=ap.parse_args()
import glob
paths=glob.glob(os.path.join(a.data_root, a.csv_glob), recursive=True)
if not paths: raise SystemExit("No CSV under data-root")
df=pd.read_csv(paths[0])
st=StrategyV2(params_path=a.params, outdir=a.outdir)
s=st.run(df)
print(s)

# ==== BEGIN: auto-post-enrich (v2.1.3-patched) ====
try:
    import json, pandas as pd, numpy as np, os
    outdir = locals().get("outdir", ".")
    # 1) Ensure trades.csv exists and has pnl_close_based
    trades_path = os.path.join(outdir, "trades.csv")
    if os.path.exists(trades_path):
        df_tr = pd.read_csv(trades_path)
        # EXIT filter
        ev = next((c for c in df_tr.columns if str(c).lower()=="event"), None)
        df_ex = df_tr[df_tr[ev].astype(str).str.upper()=="EXIT"].copy() if ev is not None else df_tr.copy()
        # choose pnl column
        pnl_col = None
        for c in ["pnl_close_based","pnl","pnl_value","pnl_usd","pnl_krw","pnl_pct","pnl_percent","ret","return","pnl_close"]:
            if c in df_ex.columns:
                pnl_col = c; break
        if pnl_col is None:
            # create placeholder to keep pipeline consistent
            df_tr["pnl_close_based"] = 0.0
            df_tr.to_csv(trades_path, index=False)
            pnl_col = "pnl_close_based"
            df_ex = df_tr.copy()
        # 2) Summary enrich
        s_path = os.path.join(outdir, "summary.json")
        summ = {}
        if os.path.exists(s_path):
            try: summ = json.load(open(s_path,"r",encoding="utf-8"))
            except: summ = {}
        s = pd.to_numeric(df_ex[pnl_col], errors="coerce").fillna(0.0)
        summ["exits"] = int(len(s))
        summ["win_rate"] = float((s>0).sum())/max(1,len(s))
        pos, neg = float(s[s>0].sum()), float(s[s<0].sum())
        summ["profit_factor"] = (pos/abs(neg)) if neg != 0 else None
        summ["cum_pnl_close_based"] = float(s.sum())
        json.dump(summ, open(s_path,"w",encoding="utf-8"), ensure_ascii=False, indent=2)
except Exception as _e_patch:
    pass
# ==== END: auto-post-enrich (v2.1.3-patched) ====


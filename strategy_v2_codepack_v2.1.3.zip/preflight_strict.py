import argparse, json, os, glob, pandas as pd
REQ=["open_time","open","high","low","close","volume","number_of_trades","taker_buy_base_asset_volume"]
ap=argparse.ArgumentParser(); ap.add_argument("--data-root",required=True); ap.add_argument("--csv-glob",default="**/*.csv"); ap.add_argument("--outdir",required=True); a=ap.parse_args()
os.makedirs(a.outdir, exist_ok=True)
pat=a.csv_glob if a.csv_glob else "**/*.csv"
paths=glob.glob(os.path.join(a.data_root, pat), recursive=True)
if not paths: raise SystemExit(f"No CSV found under {a.data_root} with pattern {pat}")
csv=paths[0]
df=pd.read_csv(csv, nrows=2000)
miss=[c for c in REQ if c not in df.columns]
rep={"csv_path":csv,"rows_read":int(len(df)),"missing":miss,"required":REQ,"status":"ok" if not miss else "fail"}
with open(os.path.join(a.outdir,"summary.json"),"w") as f: json.dump(rep,f,indent=2)
open(os.path.join(a.outdir,"gating_debug.json"),"a").close()
open(os.path.join(a.outdir,"preds_test.csv"),"a").close()
open(os.path.join(a.outdir,"trades.csv"),"a").close()
if miss: raise SystemExit(f"Missing required columns: {miss}")

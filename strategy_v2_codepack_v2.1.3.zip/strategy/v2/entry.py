
import numpy as np

def soft_gate(score, a=1.0, thr=0.0, beta=1.0, of_shift=0.0):
    p = 1.0/(1.0+np.exp(-(a*(score - thr) + of_shift)))
    return np.power(p, beta)

def combine_edges(mode, macd_hist, ofi, aggbuy, aggsell, struct, regime, weights):
    w = weights
    session = regime.get("session")
    score = np.zeros_like(macd_hist, dtype=float)

    if mode == "trend":
        score += w.get("macd",1.0) * macd_hist
        score += w.get("aggbuy",0.5) * aggbuy
        score -= w.get("aggsell",0.5) * aggsell
        score += w.get("bos",0.4) * (struct["BOS_UP"] - struct["BOS_DN"])
        score += w.get("retest",0.2) * (struct["RETEST_UP"] - struct["RETEST_DN"])
    else:  # range
        score += w.get("stoprun",0.6) * (struct["STOPRUN_LONG"] - struct["STOPRUN_SHORT"])
        score -= w.get("macd_range",0.2) * np.sign(macd_hist)
        score += w.get("ofi",0.3) * ofi

    sess_bias = np.where(np.isin(session, [1,2,3]), 0.05, 0.0)
    score += sess_bias
    return score

def decide(mode, score, gate_params, p_thr):
    p = soft_gate(score, **gate_params)
    side = np.where(p >= p_thr, 1, 0)
    return p, side

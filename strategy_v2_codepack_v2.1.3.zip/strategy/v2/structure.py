
import numpy as np
import pandas as pd

def swing_points(series, left=3, right=3):
    s = pd.Series(series)
    rmax = s.rolling(left+right+1, center=True).max()
    rmin = s.rolling(left+right+1, center=True).min()
    is_H = (s == rmax) & s.notna()
    is_L = (s == rmin) & s.notna()
    H_idx = np.where(is_H.to_numpy())[0]
    L_idx = np.where(is_L.to_numpy())[0]
    return H_idx, L_idx

def last_pivot_arrays(high, low, left=3, right=3):
    H_idx, L_idx = swing_points(high, left, right)[0], swing_points(low, left, right)[1]
    lastH = np.full_like(high, np.nan, dtype=float)
    lastL = np.full_like(low, np.nan, dtype=float)
    hi = -1; li = -1
    Hset = set(H_idx); Lset=set(L_idx)
    for i in range(len(high)):
        if i in Hset:
            hi = i
        if i in Lset:
            li = i
        lastH[i] = high[hi] if hi>=0 else np.nan
        lastL[i] = low[li] if li>=0 else np.nan
    return lastH, lastL

def wick_ratios(open_, high, low, close):
    rng = np.maximum(high-low, 1e-12)
    upper = (high - np.maximum(open_, close)) / rng
    lower = (np.minimum(open_, close) - low) / rng
    return upper, lower

def signals(df, levels, params):
    left=int(params.get("pivot_left",3)); right=int(params.get("pivot_right",3))
    eps=float(params.get("retest_eps",0.001)); wick_thr=float(params.get("wick_thr",0.6))

    high=df["high"].to_numpy(float); low=df["low"].to_numpy(float); close=df["close"].to_numpy(float); open_=df["open"].to_numpy(float)
    lastH, lastL = last_pivot_arrays(high, low, left, right)
    bos_up = (close > lastH)
    bos_dn = (close < lastL)

    upper_wick, lower_wick = wick_ratios(open_, high, low, close)
    near_pdh = np.isfinite(levels["PDH"]) & (np.abs((high - levels["PDH"])/np.maximum(levels["PDH"],1e-12)) <= eps)
    near_pdl = np.isfinite(levels["PDL"]) & (np.abs((low  - levels["PDL"])/np.maximum(levels["PDL"],1e-12)) <= eps)
    stoprun_short = near_pdh & (upper_wick >= wick_thr) & (close < levels["PDH"])
    stoprun_long  = near_pdl & (lower_wick >= wick_thr) & (close > levels["PDL"])

    retest_up = bos_up & (np.abs((close - lastH)/np.maximum(lastH,1e-12)) <= eps)
    retest_dn = bos_dn & (np.abs((close - lastL)/np.maximum(lastL,1e-12)) <= eps)

    return {
        "BOS_UP": bos_up.astype(int), "BOS_DN": bos_dn.astype(int),
        "STOPRUN_LONG": stoprun_long.astype(int), "STOPRUN_SHORT": stoprun_short.astype(int),
        "RETEST_UP": retest_up.astype(int), "RETEST_DN": retest_dn.astype(int),
        "LASTH": lastH, "LASTL": lastL
    }


import numpy as np
from numba import njit

@njit
def run_state_engine(close, high, low, signal_long, atr,
                     tp_atr, sl_atr, trail_atr, min_hold, max_hold, be_after_atr):
    n = close.shape[0]
    in_pos = 0  # 0 flat, 1 long
    entry_price = 0.0
    bars_held = 0
    trail = 0.0
    pnl = np.zeros(n, dtype=np.float64)
    side_arr = np.zeros(n, dtype=np.int8)
    exit_reason = np.zeros(n, dtype=np.int8)  # 0 none, 1 TP,2 SL,3 BE,4 TIME,5 TRAIL

    for i in range(n):
        if in_pos == 0 and signal_long[i] == 1:
            in_pos = 1
            entry_price = close[i]
            bars_held = 0
            trail = entry_price - trail_atr*atr[i]
            side_arr[i] = 1
            continue

        if in_pos == 1:
            bars_held += 1
            tp = entry_price + tp_atr*atr[i]
            sl = entry_price - sl_atr*atr[i]
            if close[i] - entry_price >= be_after_atr*atr[i]:
                sl = max(sl, entry_price)
            trail = max(trail, high[i] - trail_atr*atr[i])
            sl = max(sl, trail)

            ex = 0
            price_exit = close[i]

            if bars_held >= max_hold:
                ex = 4; price_exit = close[i]
            else:
                if bars_held >= min_hold:
                    if low[i] <= sl:
                        ex = 2; price_exit = sl
                    elif high[i] >= tp:
                        ex = 1; price_exit = tp

            if ex != 0:
                pnl[i] = (price_exit - entry_price)/max(entry_price, 1e-12)
                in_pos = 0
                exit_reason[i] = ex
                entry_price = 0.0
                bars_held = 0
            else:
                side_arr[i] = 1

    return pnl, side_arr, exit_reason

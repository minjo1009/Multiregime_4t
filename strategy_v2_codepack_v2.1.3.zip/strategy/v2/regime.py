
import numpy as np
import pandas as pd
from .. import utils

def true_range(high, low, close):
    prev_close = np.r_[close[0], close[:-1]]
    tr1 = high - low
    tr2 = np.abs(high - prev_close)
    tr3 = np.abs(low - prev_close)
    return np.maximum.reduce([tr1, tr2, tr3])

def atr(high, low, close, n=14):
    tr = true_range(high, low, close)
    return utils.ema(tr, n)

def donchian(high, low, n=40):
    sH = pd.Series(high)
    sL = pd.Series(low)
    win = n
    up = sH.rolling(win, min_periods=win//2).max()
    dn = sL.rolling(win, min_periods=win//2).min()
    width = (up - dn).bfill().to_numpy()
    return up.to_numpy(), dn.to_numpy(), width

def session_utc(hours):
    sess = np.full_like(hours, fill_value=0, dtype=int)  # 0=ASIA,1=EU,2=US,3=OVERLAP,4=OTHER
    asia = (hours>=0)&(hours<8)
    eu   = (hours>=7)&(hours<15)
    us   = (hours>=13)&(hours<21)
    overlap = (eu & us) | ((hours>=7)&(hours<8)) | ((hours>=13)&(hours<15))
    sess[asia] = 0; sess[eu] = 1; sess[us] = 2; sess[overlap] = 3
    sess[~(asia|eu|us)] = 4
    return sess

def vah_val_poc(close, volume, window=720, q=0.7):
    s = pd.Series(close)
    q_low  = s.rolling(window, min_periods=window//2).quantile((1.0-q)/2.0)
    q_high = s.rolling(window, min_periods=window//2).quantile(1.0 - (1.0-q)/2.0)
    vwap = (pd.Series(close*volume).rolling(window, min_periods=window//2).sum() /
            pd.Series(volume).rolling(window, min_periods=window//2).sum())
    poc = vwap  # proxy
    return q_low.bfill().to_numpy(), q_high.bfill().to_numpy(), poc.bfill().to_numpy(), vwap.bfill().to_numpy()

def prev_period_levels(ts, high, low):
    df = pd.DataFrame({"high":high, "low":low}, index=ts)
    daily = df.resample("1D").agg({"high":"max","low":"min"}).shift(1).reindex(ts, method="ffill")
    weekly = df.resample("1W-MON").agg({"high":"max","low":"min"}).shift(1).reindex(ts, method="ffill")
    return daily["high"].to_numpy(), daily["low"].to_numpy(), weekly["high"].to_numpy(), weekly["low"].to_numpy()

def analyze(df, params):
    n_atr = int(params.get("atr_n",14))
    n_don = int(params.get("donchian_n",40))
    vah_win = int(params.get("vahval_window",720))
    vah_q = float(params.get("vahval_quantile",0.7))
    eps = float(params.get("level_epsilon",0.001))

    # dynamic regime thresholds
    pctl_win = int(params.get("regime_pctl_window", 720))  # 12h on 1m
    lo_p = float(params.get("range_lo_pctile", 0.35))
    hi_p = float(params.get("trend_hi_pctile", 0.65))

    close = df["close"].to_numpy(float); high = df["high"].to_numpy(float); low=df["low"].to_numpy(float)
    vol = df["volume"].to_numpy(float)
    ts = pd.to_datetime(df["open_time"])

    a = atr(high, low, close, n_atr)
    up, dn, dwidth = donchian(high, low, n_don)
    ratio = dwidth / (np.maximum(a,1e-12))

    # rolling percentile bands for ratio
    rs = pd.Series(ratio)
    lo_band = rs.rolling(pctl_win, min_periods=pctl_win//2).quantile(lo_p).bfill().to_numpy()
    hi_band = rs.rolling(pctl_win, min_periods=pctl_win//2).quantile(hi_p).bfill().to_numpy()
    trend_state = np.where(ratio>hi_band, 1, np.where(ratio<lo_band, -1, 0))

    hours = ts.dt.hour.to_numpy()
    sess = session_utc(hours)

    val, vah, poc, vwap = vah_val_poc(close, vol, window=vah_win, q=vah_q)
    pdh, pdl, pwh, pwl = prev_period_levels(ts, high, low)

    n = len(close)
    near = np.zeros((n,), dtype=np.int8)  # 0-none,1-POC,2-VAH,3-VAL,4-PDH,5-PDL
    def near_mask(level):
        level = np.asarray(level, dtype=float)
        ok = np.isfinite(level) & (level != 0.0)
        rel = np.zeros(n, dtype=float)
        np.divide(np.abs(close - level), np.maximum(level, 1e-12), out=rel, where=ok)
        return ok & (rel <= eps)

    for code, lvl in enumerate([poc, vah, val, pdh, pdl], start=1):
        m = (near == 0) & near_mask(lvl)
        near = np.where(m, code, near)

    out = {
        "atr": a, "donchian_up": up, "donchian_dn": dn, "donchian_width": dwidth,
        "ratio": ratio, "ratio_lo": lo_band, "ratio_hi": hi_band,
        "trend_state": trend_state, "session": sess,
        "VAL": val, "VAH": vah, "POC": poc, "VWAP": vwap,
        "PDH": pdh, "PDL": pdl, "PWH": pwh, "PWL": pwl,
        "near_zone": near
    }
    return out


import numpy as np
import pandas as pd
from .. import utils

def features(df, params):
    z_n = int(params.get("z_n", 120))
    ofi_thr = float(params.get("ofi_thr", 0.2))

    vol = df["volume"].to_numpy(float)
    tb = df.get("taker_buy_base_asset_volume", pd.Series([0]*len(df))).to_numpy(float)
    trades = df.get("number_of_trades", pd.Series([0]*len(df))).to_numpy(float)

    bvr = utils.safe_div(tb, vol)  # buy volume ratio
    ofi = 2.0*bvr - 1.0            # imbalance approx [-1,1]
    vz = utils.rolling_zscore(vol, z_n)
    tz = utils.rolling_zscore(trades, z_n)

    aggbuy  = np.clip(ofi, 0, 1) * np.clip(tz, 0, None)
    aggsell = np.clip(-ofi,0, 1) * np.clip(tz, 0, None)

    strong_buy  = (ofi >= ofi_thr) & (tz > 0)
    strong_sell = (ofi <= -ofi_thr) & (tz > 0)

    return {
        "BVR": bvr, "OFI": ofi, "VOL_Z": vz, "TRADES_Z": tz,
        "AggBuy": aggbuy, "AggSell": aggsell,
        "StrongBuy": strong_buy.astype(int), "StrongSell": strong_sell.astype(int)
    }

\
import pandas as pd, numpy as np

TIME_CANDIDATES = ["open_time","Open time","ts","timestamp","date","datetime","time"]

def _parse_time_col(s):
    if np.issubdtype(s.dtype, np.number):
        ser = s.astype("int64")
        unit = "ms" if (ser.dropna().quantile(0.5) > 1_000_000_000_000) else "s"
        return pd.to_datetime(ser, unit=unit, utc=True, errors="coerce")
    return pd.to_datetime(s, utc=True, errors="coerce")

def load_ohlcv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    tcol = None
    for c in TIME_CANDIDATES:
        if c in df.columns:
            tcol = c; break
    if tcol is None:
        raise ValueError(f"No time column found. Tried: {TIME_CANDIDATES}")
    ts = _parse_time_col(df[tcol])
    df = df.rename(columns={tcol: "ts"})
    df["ts"] = ts

    # Canonical OHLCV
    cols = {c.lower(): c for c in df.columns}
    out = pd.DataFrame({
        "ts": df["ts"],
        "open":  pd.to_numeric(df.get(cols.get("open","open")), errors="coerce"),
        "high":  pd.to_numeric(df.get(cols.get("high","high")), errors="coerce"),
        "low":   pd.to_numeric(df.get(cols.get("low","low")), errors="coerce"),
        "close": pd.to_numeric(df.get(cols.get("close","close")), errors="coerce"),
    })
    if "volume" in df.columns:
        out["volume"] = pd.to_numeric(df["volume"], errors="coerce")

    out = out.dropna(subset=["ts"]).sort_values("ts").drop_duplicates("ts").set_index("ts")

    # Ensure 1-minute grid (if irregular)
    inf = pd.infer_freq(out.index)
    if inf not in ("T", "min"):
        agg = {"open":"first","high":"max","low":"min","close":"last"}
        if "volume" in out.columns: agg["volume"]="sum"
        out = out.resample("1min", label="right", closed="right").agg(agg).dropna()
    return out

def slice_timerange(df: pd.DataFrame, start: str, end: str) -> pd.DataFrame:
    s = pd.to_datetime(start, utc=True); e = pd.to_datetime(end, utc=True)
    return df.loc[(df.index>=s)&(df.index<=e)].copy()

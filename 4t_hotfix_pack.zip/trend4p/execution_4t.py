\
import numpy as np, pandas as pd
from sklearn.metrics import matthews_corrcoef, accuracy_score, confusion_matrix
from .data_utils import load_ohlcv, slice_timerange
from .features_4t import feat_block
from .labeling import forward_return, choose_k_by_coverage, make_labels
from .model_4t import build_model

def _pick_prob_threshold(p_train: np.ndarray, cov_target: float) -> float:
    # symmetric: fraction outside [thr,1-thr] ≈ cov_target
    x = np.sort(np.minimum(p_train, 1.0 - p_train))
    q = float(np.clip(cov_target, 0.01, 0.49))
    idx = int(np.clip(np.floor(q * (len(x)-1)), 0, len(x)-1))
    thr = float(1.0 - x[idx])
    return float(np.clip(thr, 0.55, 0.99))

def _metrics(y_true, y_pred, fr, fee_bps: float):
    mask = y_pred != 0
    if mask.sum() == 0:
        return 0.0, 0.0, 0.0, 0, 1.0, 1.0
    cov = float(mask.mean())
    acc = float(accuracy_score(y_true[mask], y_pred[mask]))
    try:
        mcc = float(matthews_corrcoef(y_true[mask], y_pred[mask]))
    except Exception:
        cm = confusion_matrix(y_true[mask], y_pred[mask], labels=[-1,1])
        if cm.size==4:
            tn, fp, fn, tp = cm.ravel()
            denom = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) + 1e-12
            mcc = ((tp*tn - fp*fn)/denom) if denom>0 else 0.0
        else:
            mcc = 0.0
    n_trades = int(mask.sum())
    gross = (1.0 + (fr[mask] * y_pred[mask])).prod()
    fee = (1.0 - fee_bps/10000.0) ** n_trades
    total = float(gross * fee)
    monthly = total
    return cov, acc, mcc, n_trades, total, monthly

def backtest(data_path: str, train_start: str, train_end: str, test_start: str, test_end: str,
             H: int = 5, fee_bps: float = 1.0, cov_band=(0.2, 0.4)):
    df = load_ohlcv(data_path)
    tr = slice_timerange(df, train_start, train_end)
    te = slice_timerange(df, test_start, test_end)

    # Features (no look-ahead)
    Xtr = feat_block(tr).shift(1).dropna()
    Xte = feat_block(te).shift(1).dropna()

    close_tr = tr["close"].reindex(Xtr.index)
    close_te = te["close"].reindex(Xte.index)

    fr_tr = forward_return(close_tr, H)
    fr_te = forward_return(close_te, H)

    # Dynamic k from train coverage target
    k = choose_k_by_coverage(fr_tr.abs(), cov_band[0], cov_band[1])
    ytr = make_labels(fr_tr, k).reindex(Xtr.index).fillna(0).astype(int)
    yte_true = make_labels(fr_te, k).reindex(Xte.index).fillna(0).astype(int)

    # train only on non-zero labels
    mask = ytr != 0
    Xtr2 = Xtr[mask]; ytr2 = (ytr[mask] > 0).astype(int)  # {-1,1}->{0,1}

    if len(np.unique(ytr2)) < 2:
        # relax k if degenerate
        k = float(max(k*0.7, fr_tr.abs().quantile(0.6)))
        ytr = make_labels(fr_tr, k).reindex(Xtr.index).fillna(0).astype(int)
        mask = ytr != 0
        Xtr2 = Xtr[mask]; ytr2 = (ytr[mask] > 0).astype(int)

    mdl = build_model()
    mdl.fit(Xtr2, ytr2)

    p_tr = mdl.predict_proba(Xtr)[:,1]
    p_te = mdl.predict_proba(Xte)[:,1]

    cov_target = (cov_band[0] + cov_band[1]) / 2.0
    thr = _pick_prob_threshold(p_tr, cov_target)

    yhat_tr = np.where(p_tr >  thr,  1, np.where(p_tr < (1-thr), -1, 0))
    yhat_te = np.where(p_te >  thr,  1, np.where(p_te < (1-thr), -1, 0))

    cov_tr, acc_tr, mcc_tr, ntr, ret_tr, mon_tr = _metrics(ytr.values, yhat_tr, fr_tr.reindex(Xtr.index).values, fee_bps)
    cov_te, acc_te, mcc_te, nte, ret_te, mon_te = _metrics(yte_true.values, yhat_te, fr_te.reindex(Xte.index).values, fee_bps)

    return {
        "H": H,
        "k_edge": float(k),
        "prob_threshold": float(thr),
        "train_metrics": {
            "coverage": cov_tr, "acc": acc_tr, "mcc": mcc_tr,
            "n_trades": ntr, "total_return": ret_tr, "monthly_return": mon_tr
        },
        "test_metrics": {
            "coverage": cov_te, "acc": acc_te, "mcc": mcc_te,
            "n_trades": nte, "total_return": ret_te, "monthly_return": mon_te
        },
        "train": {"start": str(Xtr.index.min()), "end": str(Xtr.index.max())},
        "test": {"start": str(Xte.index.min()), "end": str(Xte.index.max())}
    }

\
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.model_selection import TimeSeriesSplit

def build_model(random_state: int = 42):
    tree = HistGradientBoostingClassifier(
        max_depth=6, learning_rate=0.05, max_iter=400, random_state=random_state
    )
    rf = RandomForestClassifier(
        n_estimators=300, max_depth=7, min_samples_leaf=5, class_weight="balanced_subsample",
        n_jobs=-1, random_state=random_state
    )
    lin = Pipeline([
        ("scaler", StandardScaler(with_mean=False)),
        ("lr", LogisticRegression(C=1.0, class_weight="balanced", max_iter=200, solver="saga"))
    ])
    ens = VotingClassifier(
        estimators=[("tree", tree), ("rf", rf), ("lin", lin)],
        voting="soft", weights=[2,2,1], n_jobs=-1
    )
    cal = CalibratedClassifierCV(estimator=ens, method="sigmoid", cv=TimeSeriesSplit(n_splits=3))
    return cal

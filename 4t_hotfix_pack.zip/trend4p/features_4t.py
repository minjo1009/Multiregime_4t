\
import pandas as pd, numpy as np

def rsi(close: pd.Series, n:int=14):
    delta = close.diff()
    up = (delta.clip(lower=0)).rolling(n).mean()
    down = (-delta.clip(upper=0)).rolling(n).mean()
    rs = up / (down.replace(0,np.nan))
    return 100 - (100/(1+rs))

def feat_block(df: pd.DataFrame) -> pd.DataFrame:
    c = df["close"]
    out = pd.DataFrame(index=df.index)

    # returns
    for n in (1,3,5,10,15,30,60):
        out[f"ret_{n}"] = c.pct_change(n)

    # momentum/position
    for n in (10,30,60):
        out[f"mom_{n}"] = (c/c.rolling(n).mean()) - 1.0
    for n in (20,50,100):
        roll = c.rolling(n)
        out[f"pos_{n}"] = (c - roll.min())/(roll.max()-roll.min() + 1e-9)

    # volatility
    for n in (10,30,60,180):
        out[f"vol_{n}"] = c.pct_change().rolling(n).std().mul(np.sqrt(60))

    out["rsi_14"] = rsi(c,14)
    out = out.replace([np.inf,-np.inf], np.nan).fillna(0.0)
    return out

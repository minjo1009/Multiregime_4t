# Trend 4t — Hotfix + Mid Upgrade (Final Pack)

## What’s inside
- run_4t.py (CLI entrypoint)
- trend4p/
  - data_utils.py        : robust `open_time` parsing, 1-minute grid, no deprecated args
  - features_4t.py       : vectorized features, no look-ahead (shift/align handled in execution)
  - labeling.py          : forward return labeling, dynamic k_edge from train coverage
  - model_4t.py          : Voting(HGB+RF+LR) → CalibratedClassifierCV(estimator=..., TimeSeriesSplit)
  - execution_4t.py      : end-to-end backtest, coverage-targeted threshold, safe MCC/CM

## How to run (PowerShell)
```powershell
python .\run_4t.py --data .\data\ETHUSDT_1min_2020_2025.csv `
  --train_start 2025-01-01 --train_end 2025-04-30 `
  --test_start  2025-05-01  --test_end  2025-06-30 `
  --H 5 --fee_bps 1.0 --cov_low 0.20 --cov_high 0.40
```

## Notes
- Time column auto-detected (prefers `open_time`). Millisecond/second epoch handled.
- Removes deprecated pandas args; uses '1min' (not 'T').
- Fixes scikit-learn API (`estimator=`) and uses TimeSeriesSplit.
- Coverage collapse guard: dynamic k and probability thresholding from train distribution.
- Metrics are robust in single-label windows (explicit labels & safe MCC).

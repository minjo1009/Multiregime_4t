\
import argparse, json, os
from trend4p.execution_4t import backtest

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--train_start", required=True)
    p.add_argument("--train_end", required=True)
    p.add_argument("--test_start", required=True)
    p.add_argument("--test_end", required=True)
    p.add_argument("--H", type=int, default=5)
    p.add_argument("--fee_bps", type=float, default=1.0)
    p.add_argument("--cov_low", type=float, default=0.20)
    p.add_argument("--cov_high", type=float, default=0.40)
    p.add_argument("--out_dir", default="./_out_4t")
    return p.parse_args()

def main():
    args = parse_args()
    out = backtest(
        data_path=args.data,
        train_start=args.train_start,
        train_end=args.train_end,
        test_start=args.test_start,
        test_end=args.test_end,
        H=args.H,
        fee_bps=args.fee_bps,
        cov_band=(args.cov_low, args.cov_high),
    )
    os.makedirs(args.out_dir, exist_ok=True)
    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=lambda o: str(o))
    print(json.dumps(out, ensure_ascii=False, indent=2, default=lambda o: str(o)))

if __name__ == "__main__":
    main()

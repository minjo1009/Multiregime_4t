#!/usr/bin/env python3
# runner.py — v1.1.7: ensure effective config before engine
from __future__ import annotations
import os, sys, json, argparse, pathlib, subprocess

ROOT = pathlib.Path(__file__).resolve().parent
OUT_DFLT = ROOT/"_out_4u"/"run"
CONF = ROOT/"conf"/"config.yml"
CONF_EFF = ROOT/"conf"/"config.effective.yml"

STUB = """calibration:
  method: isotonic
coverage_target_min: 0.03
coverage_target_max: 0.08
gate:
  beta: 1.2
  temp: 10.0
costs:
  taker_bps: 7
  slippage_bps: 0
trade:
  hold_bars: 5
  tp_pct: 0.004
  sl_pct: 0.003
policy:
  allow_long: true
  allow_short: true
"""

def ensure(p: pathlib.Path):
    p.mkdir(parents=True, exist_ok=True)

def ensure_effective():
    # try bridge, then guarantee
    if (ROOT/"backtest"/"exit_bridge.py").exists():
        subprocess.call([sys.executable, "backtest/exit_bridge.py"], cwd=str(ROOT))
    if not CONF_EFF.exists():
        if CONF.exists():
            CONF_EFF.write_text(CONF.read_text(), encoding="utf-8")
        else:
            ensure(CONF_EFF.parent)
            CONF_EFF.write_text(STUB, encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--out_dir", default=str(OUT_DFLT))
    ap.add_argument("--config", default=str(CONF))
    a = ap.parse_args()

    out = pathlib.Path(a.out_dir); ensure(out)
    os.environ.setdefault("PYTHONPATH", str(ROOT))

    subprocess.check_call([sys.executable, "scripts/preflight_strict.py", a.data_path], cwd=str(ROOT))

    ensure_effective()
    cfg = str(CONF_EFF if CONF_EFF.exists() else CONF)

    try:
        from backtest.engine_adapter import run_backtest
        run_backtest(a.data_path, cfg, str(out))
    except Exception as e:
        sys.stderr.write(f"[runner] engine failed: {e}\n→ fallback\n")
        subprocess.call([sys.executable, "backtest/run_v108.py", "--data_path", a.data_path, "--out_dir", str(out)], cwd=str(ROOT))

    gd = out/"gating_debug.json"
    if not gd.exists(): gd.write_text(json.dumps({"_note":"fallback stub"}, ensure_ascii=False, indent=2), encoding="utf-8")
    sj = out/"summary.json"
    if not sj.exists(): sj.write_text(json.dumps({"status":"fallback"}, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()

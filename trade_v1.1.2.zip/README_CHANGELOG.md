# v1.1.1 (hotfix)
- dynamic session min-coverage
- engine import/log guard in run_4u.py
- robust post_analyze (numeric coercion, session breakdown)

# v1.0.9
- Implement Calibrator predict/predict_proba (engine API compatibility)
- Add tests and self-check
- No interface changes; artifacts path unchanged

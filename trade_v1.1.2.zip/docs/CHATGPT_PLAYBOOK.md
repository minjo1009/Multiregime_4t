# 버전업 매뉴얼 (고정본)
- 인터페이스 보존(_out_4u/*, run_4u.py)
- Calibrator API 유지
- 세션별 임계 자동튜닝(coverage 3–8%), 최소커버리지 폴백
- 중복 ZIP 금지/stdlib 섀도 방지/CSV 경로 확정
- 실패 기준: coverage==0 또는 테스트 실패 시 실패/롤백

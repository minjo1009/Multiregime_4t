#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$GITHUB_WORKSPACE/tmp/trade"
LOG="$GITHUB_WORKSPACE/_out_4u/logs/stdout.log"
cd "$GITHUB_WORKSPACE"
trap 'echo "::group::tail stdout.log"; tail -n 200 "$LOG" 2>/dev/null || true; echo "::endgroup::"' EXIT

RAW="$(cat scripts/CSV_PATH.txt 2>/dev/null || true)"
CAND="$(python -c 'import sys; print(sys.stdin.read().strip())' <<<"$RAW")"
CSV_PATH="$(GITHUB_WORKSPACE="$GITHUB_WORKSPACE" python -u scripts/canon_csv.py "$CAND")"
if [ -z "${CSV_PATH:-}" ] || [ ! -f "$CSV_PATH" ]; then
  echo "::error::No CSV found under tmp/data (got: '${CAND:-<empty>}')" | tee -a "$LOG"
  python -u "$GITHUB_WORKSPACE/scripts/make_empty_artifacts.py" | tee -a "$LOG"
  exit 0
fi
echo "Using CSV: $CSV_PATH (exists=yes)" | tee -a "$LOG"

export PYTHONPATH="${ROOT}:${ROOT}/backtest:${PYTHONPATH:-}"
mkdir -p "_out_4u/run" "_out_4u/logs"
cd "$ROOT"
CFG="conf/config.yml"

py() { python -X faulthandler -u "$@"; }
try() { echo "+ $*" | tee -a "$LOG"; ( "$@" ) >>"$LOG" 2>&1; return ${PIPESTATUS[0]}; }

try py run_4u.py --data_path "$CSV_PATH" --config "$CFG" && exit 0
try py run_4u.py --data "$CSV_PATH" --config "$CFG" && exit 0
try py run_4u.py "$CSV_PATH" && exit 0
if [ -f "backtest/run_4u.py" ]; then
  try py backtest/run_4u.py --data_path "$CSV_PATH" --config "$CFG" && exit 0
  try py backtest/run_4u.py --data "$CSV_PATH" --config "$CFG" && exit 0
fi
try py -m backtest.runner --data "$CSV_PATH" --config "$CFG" && exit 0 || true

echo "::warning::Entrypoint attempts failed; writing empty artifacts" | tee -a "$LOG"
py "$GITHUB_WORKSPACE/scripts/make_empty_artifacts.py" | tee -a "$LOG"
exit 0

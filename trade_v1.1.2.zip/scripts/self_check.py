import importlib, numpy as np, json, sys
print("[SELF] Calibrator API smoke test")
Calibrator = getattr(importlib.import_module("trend4p.calibration"), "Calibrator")
c = Calibrator(method="isotonic").fit([0,1,1,0],[0.1,0.8,0.9,0.2])
x = [0.2,0.5,0.8]
out = {}
for fn in ("transform","predict","predict_proba"):
    y = getattr(c, fn)(x)
    arr = np.asarray(y, float)
    ok = bool(np.isfinite(arr).all() and (arr>=0).all() and (arr<=1).all() and arr.shape[0]==3)
    out[fn] = ok
    print(f"[SELF] {fn}: {ok}, sample={arr.tolist()}")
print(json.dumps(out))
if not all(out.values()):
    sys.exit(2)
print("[SELF] OK")

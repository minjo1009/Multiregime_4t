#!/usr/bin/env python3
import argparse, sys, json, os, hashlib, pathlib, traceback

THIS_DIR = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(THIS_DIR))

def sha256_of_file(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def load_yaml(p: pathlib.Path):
    import yaml
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def save_json(p: pathlib.Path, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    out_dir = pathlib.Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    conf_dir = THIS_DIR / "conf"
    effective = conf_dir / "config.effective.yml"
    fallback  = conf_dir / "config.yml"
    conf_path = effective if effective.exists() else fallback
    if not conf_path.exists():
        print("[conf] no config file found", file=sys.stderr); sys.exit(75)

    cfg = load_yaml(conf_path)
    conf_sha = sha256_of_file(conf_path)
    print(f"[conf] using {conf_path}")
    print(f"[conf] sha256={conf_sha}")

    from backtest.engine import run_backtest
    try:
        res = run_backtest(str(args.data_path), str(out_dir), cfg, conf_sha=conf_sha, conf_path=str(conf_path))
    except Exception as e:
        tb = traceback.format_exc()
        save_json(out_dir / "error.json", {"error": str(e), "stack": tb})
        print("[engine] failed; no placeholders will be written", file=sys.stderr)
        print(tb, file=sys.stderr)
        sys.exit(78)

    summary = res.get("summary") if isinstance(res, dict) else None
    if not summary or any(summary.get(k) is None for k in ["hit_rate","profit_factor","n_trades"]):
        print("[engine] missing core metrics; abort (no placeholders)", file=sys.stderr)
        save_json(out_dir / "error.json", {"reason":"missing core metrics"})
        sys.exit(78)

    print(f"[done] outputs at {out_dir}")
    return 0

if __name__ == "__main__":
    sys.exit(main())

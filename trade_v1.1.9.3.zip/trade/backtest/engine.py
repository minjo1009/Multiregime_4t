import pandas as pd, numpy as np
import pathlib, json, math, hashlib
from typing import Dict, Any

REQUIRED_COLS = ["open_time","open","high","low","close","volume"]

def _hash_dict(d: Dict[str, Any]) -> str:
    b = json.dumps(d, sort_keys=True).encode("utf-8")
    return hashlib.sha256(b).hexdigest()

def _session_bucket(ts: pd.Series) -> pd.Series:
    h = ts.dt.hour
    us = (h>=13) & (h<20)
    eu = (h>=7)  & (h<13)
    out = np.where(us, "US", np.where(eu, "EU", "ASIA"))
    return pd.Series(out, index=ts.index)

def _mcc_from_counts(tp, tn, fp, fn):
    den = math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    if den<=0: return None
    return (tp*tn - fp*fn) / den

def run_backtest(data_path: str, out_dir: str, cfg: Dict[str, Any], conf_sha: str = "", conf_path: str = "") -> Dict[str, Any]:
    out = pathlib.Path(out_dir); out.mkdir(parents=True, exist_ok=True)

    # Load CSV
    df = pd.read_csv(data_path)
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise RuntimeError(f"missing required columns: {missing}")
    n_rows = int(len(df)-1 if len(df)>0 else 0)

    # Parse time
    ts = pd.to_datetime(df["open_time"], unit="ms", errors="coerce")
    if ts.isna().all():
        ts = pd.to_datetime(df["open_time"], unit="s", errors="coerce")
    ts = ts.ffill().bfill()
    df["_ts"] = ts

    # Config
    tp = float(cfg.get("tp_pct", 0.003))
    sl = float(cfg.get("sl_pct", 0.0015))
    hold = int(cfg.get("hold_bars", 6))
    zwin = int(cfg.get("z_window", 288))
    thr_by_sess = (cfg.get("thr_by_session") or {"US":4.0,"EU":3.8,"ASIA":3.5})
    long_only = bool(cfg.get("long_only", True))
    pred_pos_means_long = bool(cfg.get("pred_pos_means_long", False))
    mcc_mode = str(cfg.get("mcc_mode","trade_vs_not"))
    mcc_sample = str(cfg.get("mcc_sample","all_bars"))
    min_gap_bars = int(cfg.get("min_gap_bars", 5))
    xor_tp_sl = bool(cfg.get("xor_tp_sl", True))
    fees_roundtrip = float(cfg.get("fees_roundtrip", 0.0004))

    # Simple z-score signal
    ret1 = df["close"].pct_change().fillna(0.0)
    mu = ret1.rolling(zwin, min_periods=max(10, zwin//10)).mean()
    sd = ret1.rolling(zwin, min_periods=max(10, zwin//10)).std(ddof=0).replace(0, np.nan)
    z = ((ret1 - mu) / sd).fillna(0.0)

    sess = _session_bucket(df["_ts"])
    thr_s = sess.map(lambda s: thr_by_sess.get(s, 9e9))
    gate = (np.abs(z.values) >= thr_s.values)

    # Direction mapping
    raw_pred = np.sign(z.values)  # toy predictor
    dir_mult = 1 if pred_pos_means_long else -1
    y_pred = raw_pred * dir_mult  # +1 LONG, -1 SHORT

    # Forward extremes within hold horizon
    close = df["close"].values
    high = df["high"].values
    low  = df["low"].values
    fmax = pd.Series(high[::-1]).rolling(hold, min_periods=1).max().values[::-1]
    fmin = pd.Series(low[::-1]).rolling(hold, min_periods=1).min().values[::-1]
    fmax = np.roll(fmax, -1); fmin = np.roll(fmin, -1)
    fmax[-1] = high[-1]; fmin[-1] = low[-1]

    long_entry  = (y_pred > 0) & gate
    short_entry = (y_pred < 0) & gate
    if long_only:
        short_entry[:] = False

    # candidate entries (at most one per bar by construction)
    entries = np.where(long_entry | short_entry)[0]

    # cooldown (min_gap_bars)
    if min_gap_bars > 0 and entries.size>0:
        kept = []
        last = -10**9
        for i in entries:
            if i - last >= min_gap_bars:
                kept.append(i); last = i
        entries = np.array(kept, dtype=int)

    # Build trades
    side = []
    pnl  = []
    idxs = []
    etime= []

    for i in entries:
        if i>=len(close)-1:  # need forward bar
            continue
        px = close[i]
        up_touch   = (fmax[i] >= px*(1+tp))
        down_touch = (fmin[i] <= px*(1-sl))
        if xor_tp_sl:
            if up_touch and down_touch:   # both: ambiguous -> skip
                continue
            if (not up_touch) and (not down_touch):  # none -> skip
                continue
        if long_entry[i]:
            if up_touch and not down_touch: ret = tp
            elif down_touch and not up_touch: ret = -sl
            else:
                j = min(i+hold, len(close)-1); ret = (close[j]/px - 1.0)
            side.append("LONG"); pnl.append(ret); idxs.append(i); etime.append(df["_ts"].iloc[i])
        elif short_entry[i]:
            if up_touch and not down_touch: ret = -tp
            elif down_touch and not up_touch: ret = sl
            else:
                j = min(i+hold, len(close)-1); ret = (px/close[j] - 1.0)
            side.append("SHORT"); pnl.append(ret); idxs.append(i); etime.append(df["_ts"].iloc[i])

    trades = pd.DataFrame({"idx": idxs, "entry_time": etime, "side": side, "PnL": pnl})
    n_trades = int(len(trades))

    # Metrics (no fees here; fees are applied in workflow monthly calc)
    hit_rate = float((trades["PnL"]>0).mean()) if n_trades>0 else None
    gains = trades.loc[trades["PnL"]>0, "PnL"].sum()
    losses = -trades.loc[trades["PnL"]<0, "PnL"].sum()
    profit_factor = float(gains/losses) if losses>0 else (None if n_trades==0 else float("inf"))

    # MCC
    ret_h = pd.Series(df["close"].shift(-hold)/df["close"] - 1.0)
    if mcc_mode == "trade_vs_not":
        base_long_entry = (y_pred > 0) & gate
        base_pred = np.where(base_long_entry, 1, -1)  # +1 trade(long), -1 not-trade
        mask = np.isfinite(ret_h.values) if mcc_sample == "all_bars" else np.isin(np.arange(len(df)), np.array(idxs, dtype=int))
    else:
        mask = np.isfinite(ret_h.values) if mcc_sample != "traded_bars" else np.isin(np.arange(len(df)), np.array(idxs, dtype=int))
        base_pred = np.sign(y_pred)

    y_true = np.where(ret_h.values>0, 1, -1)[mask]
    y_pred_bin = base_pred[mask]
    tp_c = int(((y_true== 1) & (y_pred_bin== 1)).sum())
    tn_c = int(((y_true==-1) & (y_pred_bin==-1)).sum())
    fp_c = int(((y_true==-1) & (y_pred_bin== 1)).sum())
    fn_c = int(((y_true== 1) & (y_pred_bin==-1)).sum())
    mcc = (lambda den: ( (tp_c*tn_c - fp_c*fn_c)/den ) if den>0 else None)(
        math.sqrt((tp_c+fp_c)*(tp_c+fn_c)*(tn_c+fp_c)*(tn_c+fn_c))
    )

    # Write artifacts
    trades.to_csv(out / "trades.csv", index=False)

    gating_debug = {
        "thr_by_session": thr_by_sess,
        "z_window": zwin,
    }
    try:
        sess_counts = pd.Series(_session_bucket(df["_ts"])).value_counts(dropna=False)
        gating_debug["used_session_counts"] = {str(k): int(v) for k, v in sess_counts.to_dict().items()}
    except Exception as e:
        gating_debug["used_session_counts_error"] = str(e)
    (out / "gating_debug.json").write_text(json.dumps(gating_debug, indent=2))

    summary = {
        "placeholders": False,
        "notes": "v1.1.9.3 engine (long-only)",
        "n_rows": n_rows,
        "n_trades": n_trades,
        "hit_rate": hit_rate,
        "profit_factor": profit_factor,
        "tp_pct": tp, "sl_pct": sl, "hold_bars": hold,
        "mcc": mcc,
        "mcc_mode": mcc_mode,
        "mcc_sample": mcc_sample,
        "long_only": long_only,
        "pred_pos_means_long": pred_pos_means_long,
        "xor_tp_sl": xor_tp_sl,
        "min_gap_bars": min_gap_bars,
        "fees_roundtrip": fees_roundtrip,
        "__config_sha256__": conf_sha,
        "__engine_conf_sha__": _hash_dict({
            "tp_pct":tp,"sl_pct":sl,"hold_bars":hold,"z_window":zwin,
            "thr_by_session": thr_by_sess, "long_only": long_only,
            "pred_pos_means_long": pred_pos_means_long,
            "mcc_mode": mcc_mode, "mcc_sample": mcc_sample,
            "min_gap_bars": min_gap_bars, "xor_tp_sl": xor_tp_sl,
            "fees_roundtrip": fees_roundtrip,
        }),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2))

    return {"summary": summary}

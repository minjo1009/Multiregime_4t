import os
from .engine import BacktestEngine
def run_backtest(data_path, cfg_path, out_dir):
    return BacktestEngine(cfg_path).run(data_path, out_dir)


import pandas as pd
def resolve_gamma(df, cfg):
    sess_map = pd.Series(cfg.get('of_weight',{}).get('gamma_by_session',{}))
    grid = cfg.get('of_weight',{}).get('gamma_by_session_regime',{})
    has_regime = 'regime' in df.columns and isinstance(grid, dict) and len(grid)>0
    if not has_regime:
        return df['session'].map(sess_map).fillna(1.0).to_numpy()
    out=[]
    for s,r in zip(df['session'], df['regime']):
        val = 1.0
        if s in grid and isinstance(grid[s], dict) and r in grid[s]:
            val = float(grid[s][r])
        elif s in sess_map.index:
            val = float(sess_map[s])
        out.append(val)
    return pd.Series(out, index=df.index).to_numpy()

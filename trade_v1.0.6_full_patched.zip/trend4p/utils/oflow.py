
import numpy as np, pandas as pd
def z(x):
    x=np.asarray(x,dtype=float); mu=np.nanmean(x); sd=np.nanstd(x) or 1.0; return (x-mu)/sd
def compute_ats(df):
    v = df['volume'].astype(float).replace(0,np.nan)
    tb= df.get('taker_buy_base_asset_volume', pd.Series(index=df.index, data=np.nan)).astype(float)
    ratio=(tb / v).clip(0,1).fillna(0.5)
    return pd.Series(ratio*2-1.0, index=df.index, name='ats')
def combine_of(df_or_X):
    cols=[c for c in ['vpin','ats','lambda_kyle'] if c in df_or_X.columns]
    if not cols:
        return np.zeros(len(df_or_X))
    Z=np.c_[ [ z(df_or_X[c]) for c in cols ] ]
    return np.nanmean(Z, axis=1)

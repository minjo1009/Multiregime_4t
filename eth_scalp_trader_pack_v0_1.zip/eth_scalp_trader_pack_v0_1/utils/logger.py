
import sys

def log(*args, **kwargs):
    print(*args, **kwargs, file=sys.stdout, flush=True)

def warn(*args, **kwargs):
    print("[WARN]", *args, **kwargs, file=sys.stderr, flush=True)


import pandas as pd

def add_bos_flags(df: pd.DataFrame, lookback:int=20):
    hh = df['high'].rolling(lookback).max().shift(1)
    ll = df['low'].rolling(lookback).min().shift(1)
    df['bos_up'] = (df['close'] > hh).astype(int)
    df['bos_dn'] = (df['close'] < ll).astype(int)
    return df

def simple_ob_zone(df: pd.DataFrame, base_look:int=5):
    # 브레이크 직전 베이스 캔들 범위 추정 (매우 단순 근사)
    df = df.copy()
    df['base_hi'] = df['high'].rolling(base_look).max().shift(1)
    df['base_lo'] = df['low'].rolling(base_look).min().shift(1)
    return df[['base_hi','base_lo']]

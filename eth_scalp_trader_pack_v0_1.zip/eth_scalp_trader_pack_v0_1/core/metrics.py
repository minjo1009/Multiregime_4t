
import pandas as pd
import numpy as np
from math import sqrt

def sharpe(returns, rf=0.0):
    r = np.array(returns)
    if r.std() == 0: return 0.0
    return (r.mean() - rf) / (r.std() + 1e-12) * np.sqrt(252*24*60)  # 분봉 가정(보수)

def profit_factor(pnl_series):
    gains = pnl_series[pnl_series>0].sum()
    losses = -pnl_series[pnl_series<0].sum()
    if losses == 0: return float('inf')
    return gains / losses

def mcc(pred, actual):
    # pred: -1/0/1, actual: 미래 수익의 부호
    pred = np.array(pred); actual = np.array(actual)
    mask = pred!=0
    if mask.sum()==0: return 0.0
    p = pred[mask]; a = actual[mask]
    tp = ((p==1) & (a==1)).sum()
    tn = ((p==-1) & (a==-1)).sum()
    fp = ((p==1) & (a==-1)).sum()
    fn = ((p==-1) & (a==1)).sum()
    denom = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) + 1e-12
    return ((tp*tn - fp*fn)/denom)

def summarize(trades: pd.DataFrame, equity: pd.Series):
    pnl = trades['pnl']
    ret = pnl / (equity.shift().fillna(equity.iloc[0])+1e-9)
    out = {
        "trades": int(len(trades)),
        "win_rate": float((pnl>0).mean()) if len(trades)>0 else 0.0,
        "profit_factor": float(profit_factor(pnl)) if len(trades)>0 else 0.0,
        "sharpe_like": float(sharpe(ret.fillna(0))),
        "net_pnl": float(pnl.sum()),
        "avg_pnl": float(pnl.mean()) if len(trades)>0 else 0.0,
        "max_dd": float((equity.cummax()-equity).max()),
        "cost_ratio": float((trades['cost'].sum())/max(pnl.sum()+trades['cost'].sum(),1e-9))
    }
    return out

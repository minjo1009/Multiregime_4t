
import pandas as pd
import numpy as np

def ema(series: pd.Series, span: int):
    return series.ewm(span=span, adjust=False).mean()

def rsi(series: pd.Series, period: int=14):
    delta = series.diff()
    up = delta.clip(lower=0).rolling(period).mean()
    down = -delta.clip(upper=0).rolling(period).mean()
    rs = up / (down + 1e-12)
    return 100 - (100 / (1 + rs))

def atr(df: pd.DataFrame, period: int=14):
    high, low, close = df['high'], df['low'], df['close']
    tr = pd.concat([
        (high - low),
        (high - close.shift()).abs(),
        (low - close.shift()).abs()
    ], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def bollinger(series: pd.Series, window: int=20, num_std: float=2.0):
    ma = series.rolling(window).mean()
    sd = series.rolling(window).std()
    upper = ma + num_std*sd
    lower = ma - num_std*sd
    return ma, upper, lower

def vwap(df: pd.DataFrame):
    # 세션 누적 VWAP (일/day 기준)
    g = df.groupby(df.index.date, sort=False)
    out = []
    for _, d in g:
        tp = (d['high'] + d['low'] + d['close'])/3
        cum_vol = d['volume'].cumsum()
        cum_pv = (tp * d['volume']).cumsum()
        v = cum_pv / (cum_vol.replace(0, np.nan))
        out.append(v)
    vwap_series = pd.concat(out)
    vwap_series.index = df.index
    return vwap_series

def pivots_daily(df: pd.DataFrame):
    daily = df.resample('1D').agg({'high':'max','low':'min','close':'last'}).shift(1)
    P = (daily['high']+daily['low']+daily['close'])/3
    R1 = 2*P - daily['low']; S1 = 2*P - daily['high']
    R2 = P + (daily['high']-daily['low']); S2 = P - (daily['high']-daily['low'])
    piv = pd.DataFrame({'P':P,'R1':R1,'S1':S1,'R2':R2,'S2':S2})
    piv = piv.reindex(df.index, method='ffill')
    return piv

def ema_slope(series: pd.Series, span: int, look:int=3):
    e = ema(series, span)
    return (e - e.shift(look)) / (series.rolling(look).std()+1e-12)

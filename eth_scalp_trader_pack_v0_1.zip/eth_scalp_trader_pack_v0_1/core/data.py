
import pandas as pd
import time
from datetime import datetime, timedelta
import ccxt

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    # 허용 컬럼 표준화
    cols = {c.lower(): c for c in df.columns}
    for k in ['open_time','date','datetime','time']:
        if k in cols:
            dtcol = cols[k]; break
    else:
        dtcol = df.columns[0]
    df['datetime'] = pd.to_datetime(df[dtcol])
    # 표준 컬럼 찾기
    def pick(name):
        candidates = [name, name.capitalize(), name.upper()]
        for c in candidates:
            if c in df.columns: return c
        for c in df.columns:
            if c.lower()==name: return c
        return None
    o = pick('open'); h=pick('high'); l=pick('low'); c=pick('close'); v=pick('volume')
    out = df[['datetime', o, h, l, c, v]].copy()
    out.columns = ['datetime','open','high','low','close','volume']
    out = out.sort_values('datetime').reset_index(drop=True)
    out.set_index('datetime', inplace=True)
    return out

def fetch_ohlcv_ccxt(symbol: str, timeframe: str="1m", since_days: int=30, limit: int=1000):
    ex = ccxt.binance()
    ms_since = int((datetime.utcnow() - timedelta(days=since_days)).timestamp()*1000)
    all_rows = []
    since = ms_since
    while True:
        rows = ex.fetch_ohlcv(symbol, timeframe=timeframe, since=since, limit=limit)
        if not rows:
            break
        all_rows += rows
        since = rows[-1][0] + 1
        # rate limit
        time.sleep(ex.rateLimit/1000)
        if len(rows) < limit:
            break
    if not all_rows:
        raise RuntimeError("No OHLCV fetched.")
    df = pd.DataFrame(all_rows, columns=['ts','open','high','low','close','volume'])
    df['datetime'] = pd.to_datetime(df['ts'], unit='ms')
    df = df[['datetime','open','high','low','close','volume']].set_index('datetime')
    return df



import pandas as pd
import numpy as np

class Backtester:
    def __init__(self, df, strategy_fn, fees_bps=2.0, slippage_bps=1.0, max_r_pct=0.5,
                 tp1_r=0.6, trail_atr_mult=1.2, partial_tp=True, debug=False):
        self.df = df.copy()
        self.strategy_fn = strategy_fn
        self.fees_bps = fees_bps
        self.slippage_bps = slippage_bps
        self.max_r_pct = max_r_pct/100.0
        self.tp1_r = tp1_r
        self.trail_atr_mult = trail_atr_mult
        self.partial_tp = partial_tp
        self.debug = debug

    def run(self, start_equity=10000.0):
        equity = start_equity
        eq_curve = []
        records = []
        pos = 0  # -1/0/1
        entry = None
        risk_per_trade = start_equity * self.max_r_pct

        for ts, row in self.df.iterrows():
            signal = self.strategy_fn(self.df.loc[:ts])  # 종가 확정 시점 신호
            price = row['close']
            atr = row.get('atr', np.nan)
            unit_slip = price * (self.slippage_bps/1e4)
            cost_open = price * (self.fees_bps/1e4)

            if pos == 0 and signal!=0 and np.isfinite(atr) and atr>0:
                # 포지션 사이즈 = risk / (ATR 기반 SL)
                sl_dist = atr  # 1*ATR
                qty = max(risk_per_trade / (sl_dist + 1e-9), 0.0)
                direction = signal  # 1 long, -1 short
                pos = direction
                entry = {
                    "ts": ts, "price": price + unit_slip*direction, "qty": qty, "sl": price - sl_dist*direction,
                    "tp1": price + self.tp1_r*sl_dist*direction, "trail": None, "filled_pct": 0.0
                }
                equity -= cost_open  # 비용 차감
            elif pos!=0:
                # 관리: 부분청산/트레일/SL hit
                direction = pos
                high = row['high']; low=row['low']
                # TP1
                closed = False
                realized = 0.0; cost = 0.0
                if self.partial_tp and entry['filled_pct']<0.5:
                    target = entry['tp1']
                    if (direction==1 and high>=target) or (direction==-1 and low<=target):
                        price_fill = target - unit_slip*direction
                        pnl = (price_fill - entry['price']) * entry['qty']*0.5*direction
                        realized += pnl
                        cost += price_fill*(self.fees_bps/1e4)
                        entry['filled_pct']=0.5
                        entry['trail'] = price_fill - self.trail_atr_mult*atr*direction

                # 트레일/SL 킬
                # 우선 SL/Trail 가격 계산
                sl_price = entry['sl']
                trail = entry['trail']
                exit_now = None
                # SL 체크
                if (direction==1 and low<=sl_price) or (direction==-1 and high>=sl_price):
                    exit_now = sl_price
                # 트레일 체크
                if trail is not None:
                    if (direction==1 and low<=trail) or (direction==-1 and high>=trail):
                        exit_now = trail

                if exit_now is not None:
                    price_fill = exit_now - unit_slip*direction
                    qty_left = entry['qty']*(1-entry['filled_pct'])
                    pnl = (price_fill - entry['price']) * qty_left * direction
                    realized += pnl
                    cost += price_fill*(self.fees_bps/1e4)
                    records.append({"ts_exit": ts, "pnl": realized, "cost": cost})
                    equity += realized
                    equity -= cost
                    pos = 0; entry=None
                # 유지 시
            eq_curve.append((ts, equity))

        eq_df = pd.DataFrame(eq_curve, columns=['ts','equity']).set_index('ts')
        trades = pd.DataFrame(records)
        return eq_df, trades


import pandas as pd
from .indicators import ema, rsi, atr, bollinger, vwap, pivots_daily, ema_slope
from .structure import add_bos_flags, simple_ob_zone

def build_features(df: pd.DataFrame, use_pivots=True, use_vwap=True, use_bos=True):
    out = df.copy()
    out['ema_fast'] = ema(out['close'], span=21)
    out['ema_slow'] = ema(out['close'], span=100)
    out['ema_slope'] = ema_slope(out['close'], 50, look=5)
    out['rsi'] = rsi(out['close'], 14)
    out['atr'] = atr(out, 14)

    ma, up, lo = bollinger(out['close'], 20, 2.0)
    out['bb_ma'], out['bb_up'], out['bb_lo'] = ma, up, lo

    if use_vwap:
        out['vwap'] = vwap(out)

    if use_pivots:
        piv = pivots_daily(out)
        for c in piv.columns:
            out[c] = piv[c]
        for c in ['P','R1','S1','R2','S2']:
            out[f'dist_{c}'] = (out['close'] - out[c]) / out['close']

    if use_bos:
        out = add_bos_flags(out, 20)
        ob = simple_ob_zone(out, 5)
        out = out.join(ob)

    out.dropna(inplace=True)
    return out

# ETH Scalp & Trader Pack v0.1 (Binance‑Free‑API Compatible)

두 가지 전략을 바로 비교 백테스트/실시간 운영할 수 있는 최소 구성입니다.

- **Scalper**: Pivot + VWAP + EMA/RSI + ATR Risk (1m/5m)
- **Trader**: Order‑Block 근사(BOS/CHOCH) + Pivot 컨텍스트(15m/1h)

## 빠른 시작

1) 가상환경 생성 후 패키지 설치
```
pip install -r requirements.txt
```

2) 백테스트 실행 (CSV 또는 ccxt 다운로드)
```
python run_backtest.py --strategy scalper --symbol ETH/USDT --timeframe 1m --source csv --csv data/ETHUSDT-1m.csv
python run_backtest.py --strategy trader  --symbol ETH/USDT --timeframe 15m --source ccxt --since_days 30
```

3) 결과
- `reports/` 아래에 메트릭(JSON) + Equity Curve CSV 출력

## 실거래 (데모)
- `live_trade.py`는 ccxt로 **바이낸스(현물/선물)** 주문을 예시로 제공합니다.
- **주의**: 실제 키는 환경변수로 제공하세요. (BINANCE_API_KEY / BINANCE_API_SECRET)
- 기본은 **시뮬레이션 모드**이며, `--live 1`로 실거래 전환됩니다. 테스트넷/리스크 관리 먼저!

## 설계 포인트
- Binance 무료 API에서 가능한 데이터만 사용 (OHLCV, bid/ask ticker)
- L2 깊은 오더북/센터멘트 지표 없이도 재현 가능한 신호만 포함
- Pivots는 **청산/부분청산 지도**로 활용, 신호 소스는 모멘텀/복귀/구조

## 목표 정렬
- **단기(승률 70% / 월 300%)**: Scalper 전략으로 시도 (고빈도 + 엄격 필터 + 부분청산)
- **장기(안정/복리)**: Trader 전략으로 유지 (구조 컨텍스트 + 낮은 빈도)

## 체크리스트
- [ ] 슬리피지/수수료 상한치 준수 (reports에 비용 비중 출력)
- [ ] 재페인트 방지(신호는 **종가 확정 시**만)
- [ ] 거래 불가 시간대 필터 (유동성 낮은 시간대 감쇠)
- [ ] 포지션 중복 방지 (동일 캔들 다중 엔트리 금지)
- [ ] 실패 로그 모드: `python run_backtest.py ... --debug 1`


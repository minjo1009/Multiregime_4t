
import os
import time
import argparse
import ccxt
import pandas as pd
from utils.config_loader import load_config
from utils.logger import log, warn
from core.features import build_features
from strategies.scalper_pivot_vwap import make_strategy as make_scalper
from strategies.trader_ob_pivot import make_strategy as make_trader

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yml")
    ap.add_argument("--strategy", default="scalper", choices=["scalper","trader"])
    ap.add_argument("--symbol", default="ETH/USDT")
    ap.add_argument("--timeframe", default="1m")
    ap.add_argument("--live", type=int, default=0)  # 0: simulate, 1: live
    ap.add_argument("--loop", type=int, default=120)
    return ap.parse_args()

def main():
    args = parse_args()
    cfg = load_config(args.config)

    api_key = os.getenv("BINANCE_API_KEY","")
    api_secret = os.getenv("BINANCE_API_SECRET","")
    ex = ccxt.binance({
        "apiKey": api_key,
        "secret": api_secret,
        "enableRateLimit": True
    })

    strat = make_scalper(cfg["filters"]["use_pivots"], cfg["filters"]["use_vwap"]) if args.strategy=="scalper" else \
            make_trader(cfg["filters"]["use_pivots"], cfg["filters"]["use_bos"])

    balance = 10000.0  # simulation equity
    position = 0
    entry_px = None
    qty = 0.0

    log("Starting loop... LIVE=%s" % args.live)
    for _ in range(args.loop):
        # 최근 500 캔들
        ohlcv = ex.fetch_ohlcv(args.symbol, timeframe=args.timeframe, limit=600)
        df = pd.DataFrame(ohlcv, columns=['ts','open','high','low','close','volume'])
        df['datetime'] = pd.to_datetime(df['ts'], unit='ms')
        df = df[['datetime','open','high','low','close','volume']].set_index('datetime')

        feats = build_features(df,
                               use_pivots=cfg["filters"]["use_pivots"],
                               use_vwap=cfg["filters"]["use_vwap"],
                               use_bos=cfg["filters"]["use_bos"])
        signal = strat(feats)

        price = feats.iloc[-1]['close']
        atr = feats.iloc[-1]['atr']

        if position==0 and signal!=0:
            risk = balance * (cfg["risk"]["max_r_pct"]/100.0)
            sl_dist = atr
            qty = max(risk / max(sl_dist,1e-9), 0.0)
            direction = signal
            entry_px = price
            position = direction
            if args.live==1:
                side = "buy" if position==1 else "sell"
                log("[LIVE] placing market order:", side, qty)
                try:
                    ex.create_order(args.symbol, "market", side, qty)
                except Exception as e:
                    warn("order failed:", e)
                    position=0; qty=0.0; entry_px=None
            else:
                log(f"[SIM] entry {direction} @ {entry_px} qty={qty:.6f}")
        elif position!=0:
            # 단순 SL/TP 관리 (실시간 예시)
            direction = position
            # TP1 at 0.6R
            tp = entry_px + direction*(0.6*atr)
            sl = entry_px - direction*(1.0*atr)

            if (direction==1 and price>=tp) or (direction==-1 and price<=tp):
                pnl = (tp-entry_px)*qty*direction
                balance += pnl
                log(f"[SIM] TP hit pnl={pnl:.4f} balance={balance:.2f}")
                position=0; qty=0.0; entry_px=None

            if (direction==1 and price<=sl) or (direction==-1 and price>=sl):
                pnl = (sl-entry_px)*qty*direction
                balance += pnl
                log(f"[SIM] SL hit pnl={pnl:.4f} balance={balance:.2f}")
                position=0; qty=0.0; entry_px=None

        time.sleep(2)

if __name__=="__main__":
    main()

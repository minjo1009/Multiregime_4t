
import pandas as pd
import numpy as np

def make_strategy(use_pivots=True, use_vwap=True):
    def strategy(df: pd.DataFrame) -> int:
        row = df.iloc[-1]
        prev = df.iloc[-2]
        # 기본 필터
        trend_ok = row['ema_fast'] > row['ema_slow']
        rsi_ok = (row['rsi']>45) and (row['rsi']<75)
        squeeze = row['bb_up'] - row['bb_lo'] < prev['bb_up'] - prev['bb_lo']*1.05

        # VWAP 복귀 진입
        long_setup = trend_ok and rsi_ok
        if use_vwap and 'vwap' in row:
            long_setup = long_setup and (prev['close'] < prev['vwap']) and (row['close'] > row['vwap'])

        # 피봇 여유(타겟까지 거리)
        if use_pivots and 'R1' in row and 'dist_R1' in row:
            # 타겟까지 최소 여유 0.2% 이상
            if abs(row['dist_R1']) < 0.002:
                long_setup = False

        if long_setup:
            return 1

        # 숏은 보수적으로(스캘핑 위험)
        short_setup = (row['ema_fast'] < row['ema_slow']) and (row['rsi']<55)
        if use_vwap and 'vwap' in row:
            short_setup = short_setup and (prev['close'] > prev['vwap']) and (row['close'] < row['vwap'])
        if use_pivots and 'S1' in row and 'dist_S1' in row:
            if abs(row['dist_S1']) < 0.002:
                short_setup = False

        return -1 if short_setup else 0
    return strategy

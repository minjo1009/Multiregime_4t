
import pandas as pd

def make_strategy(use_pivots=True, use_bos=True):
    def strategy(df: pd.DataFrame) -> int:
        row = df.iloc[-1]
        # 구조 바이어스
        bias_long = True
        if use_bos:
            # 최근 BOS 업 우세
            bias_long = df['bos_up'].tail(20).sum() >= df['bos_dn'].tail(20).sum()

        # 추세 필터
        trend = row['ema_slope'] > 0

        # 엔트리: OB 재테스트 근사 + 피봇 여유
        setup = bias_long and trend
        if use_pivots and 'P' in row and 'dist_R1' in row:
            # 너무 가까운 피봇은 피하기
            setup = setup and (abs(row['dist_R1']) > 0.0015)

        return 1 if setup else 0
    return strategy


import argparse, json, os
import pandas as pd
from utils.config_loader import load_config
from utils.logger import log, warn
from core.data import load_csv, fetch_ohlcv_ccxt
from core.features import build_features
from core.backtester import Backtester
from core.metrics import summarize
from strategies.scalper_pivot_vwap import make_strategy as make_scalper
from strategies.trader_ob_pivot import make_strategy as make_trader

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yml")
    ap.add_argument("--strategy", default=None, choices=["scalper","trader"])
    ap.add_argument("--symbol", default=None)
    ap.add_argument("--timeframe", default=None)
    ap.add_argument("--source", default=None, choices=["csv","ccxt"])
    ap.add_argument("--csv", dest="csv_path", default=None)
    ap.add_argument("--since_days", type=int, default=None)
    ap.add_argument("--debug", type=int, default=0)
    return ap.parse_args()

def main():
    args = parse_args()
    cfg = load_config(args.config)
    # CLI override
    for k in ["strategy","symbol","timeframe","source","csv_path","since_days"]:
        v = getattr(args, k, None)
        if v not in [None, "None"]:
            cfg[k]=v

    log("CONFIG:", cfg)

    # 데이터
    if cfg["source"] == "csv":
        df = load_csv(cfg["csv_path"])
    else:
        df = fetch_ohlcv_ccxt(cfg["symbol"], cfg["timeframe"], cfg.get("since_days", 30))

    feats = build_features(
        df,
        use_pivots=cfg["filters"]["use_pivots"],
        use_vwap=cfg["filters"]["use_vwap"],
        use_bos=cfg["filters"]["use_bos"]
    )

    # 전략
    if cfg["strategy"]=="scalper":
        strat = make_scalper(cfg["filters"]["use_pivots"], cfg["filters"]["use_vwap"])
    else:
        strat = make_trader(cfg["filters"]["use_pivots"], cfg["filters"]["use_bos"])

    bt = Backtester(
        feats, strat,
        fees_bps=cfg["fees_bps"],
        slippage_bps=cfg["slippage_bps"],
        max_r_pct=cfg["risk"]["max_r_pct"],
        tp1_r=cfg["exits"]["tp1_r_multiple"],
        trail_atr_mult=cfg["exits"]["trail_atr_mult"],
        partial_tp=cfg["exits"]["partial_tp"],
        debug=bool(int(getattr(args,"debug",0)))
    )

    eq, trades = bt.run(start_equity=10000.0)

    os.makedirs("reports", exist_ok=True)
    if cfg["report"]["save_equity_csv"]:
        eq.to_csv("reports/equity_curve.csv")
    m = summarize(trades, eq['equity'])
    if cfg["report"]["save_metrics_json"]:
        with open("reports/metrics.json","w") as f:
            json.dump(m, f, indent=2)

    log("== METRICS ==")
    log(json.dumps(m, indent=2, ensure_ascii=False))
    if len(trades)==0:
        warn("No trades generated. Try longer data or relax filters.")

if __name__=="__main__":
    main()

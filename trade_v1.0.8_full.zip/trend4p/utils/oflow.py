import pandas as pd
def combine_of(df: pd.DataFrame):
    cols=[c for c in df.columns if c.lower() in ('vpin','ats','lambda_kyle','oflow')]
    if not cols:
        return pd.Series(0.0, index=df.index, name='of_shift')
    zs=[]
    for c in cols:
        s=df[c].astype(float)
        z=(s - s.mean())/(s.std()+1e-9)
        zs.append(z.fillna(0.0))
    return (sum(zs)/len(zs)).rename('of_shift')

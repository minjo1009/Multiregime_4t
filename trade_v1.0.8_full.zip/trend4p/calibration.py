import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
class Calibrator:
    def __init__(self, method='isotonic'):
        self.method=method; self.m=None; self.kind='off'
    def fit(self, y_pred, y_true):
        x=np.asarray(y_pred).reshape(-1); y=np.asarray(y_true).reshape(-1)
        if self.method=='platt':
            m=LogisticRegression(max_iter=500); m.fit(x.reshape(-1,1), y); self.m=m; self.kind='platt'
        elif self.method=='isotonic':
            m=IsotonicRegression(out_of_bounds='clip'); m.fit(x,y); self.m=m; self.kind='iso'
        else:
            self.kind='off'
        return self
    def predict(self, y_pred):
        x=np.asarray(y_pred).reshape(-1)
        if self.kind=='platt': return self.m.predict_proba(x.reshape(-1,1))[:,1]
        if self.kind=='iso':   return self.m.predict(x)
        return x

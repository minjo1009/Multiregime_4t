import pandas as pd
def compute_s1(df: pd.DataFrame):
    px=df['close'].astype(float).ffill()
    ret=px.pct_change().fillna(0.0)
    rv=ret.rolling(60).std().fillna(ret.abs().median())
    mom=px.pct_change(15).fillna(0.0)
    z=(mom/(rv+1e-8)).clip(-10,10)
    s=1.0/(1.0+(-z).rpow(2.718281828))
    return s

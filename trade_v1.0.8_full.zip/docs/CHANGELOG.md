## 1.0.7d: Full pack with policy loader, preflight, CI YAML, notebook demo.

import argparse, os, json
from backtest.runner import run_backtest
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--config", default="conf/config.yml")
    ap.add_argument("--out_dir", default="_out_4u/run")
    a = ap.parse_args()
    os.makedirs(a.out_dir, exist_ok=True)
    try:
        run_backtest(a.data_path, a.config, a.out_dir)
    except Exception:
        # guarantee debug file exists even on failure
        dbg = os.path.join(a.out_dir, "gating_debug.json")
        if not os.path.exists(dbg):
            with open(dbg,"w",encoding="utf-8") as f: json.dump({}, f)
        raise

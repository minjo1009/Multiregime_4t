from backtest.engine import BacktestEngine
def run_backtest(data_path, cfg_path=None, out_dir="_out_4u/run"):
    return BacktestEngine(cfg_path).run(data_path, out_dir, {})

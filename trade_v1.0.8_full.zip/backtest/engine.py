import os, json, yaml
import numpy as np, pandas as pd
from trend4p.signals.s1 import compute_s1
from trend4p.calibration import Calibrator
from trend4p.utils.oflow import combine_of

SESSIONS={'ASIA':(0,8),'EU':(8,16),'US':(16,24)}
def session_of_ms(ms):
    h=int(pd.to_datetime(ms, unit='ms', utc=True).hour)
    for k,(a,b) in SESSIONS.items():
        if a<=h<b: return k
    return 'ASIA'

class BacktestEngine:
    def __init__(self, cfg_path=None):
        self.cfg={}
        if cfg_path and os.path.exists(cfg_path):
            with open(cfg_path,'r') as f: self.cfg=yaml.safe_load(f) or {}

    def _solve_thr_by_session(self, p, target):
        sess=p.index.to_series().apply(session_of_ms)
        df=pd.DataFrame({'p':p.values, 'sess':sess.values})
        thr={}
        for s,g in df.groupby('sess'):
            lo,hi=0.0,1.0
            for _ in range(22):
                mid=(lo+hi)/2.0
                cov=float((g['p']>mid).mean())
                if cov>target: lo=mid
                else: hi=mid
            thr[s]=(lo+hi)/2.0
        return thr

    def run(self, data_path, out_dir, cfg_override=None):
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as f: f.write('{}')
        cfg=dict(self.cfg); cfg.update(cfg_override or {})
        df=pd.read_csv(data_path)
        # normalize columns
        df.columns=[c.strip().lower() for c in df.columns]
        need={'open_time','open','high','low','close','volume'}
        miss=need-set(df.columns)
        if miss: raise ValueError(f"Missing base columns: {sorted(miss)}")

        # S1 raw
        s1=compute_s1(df)
        # pseudo-label
        px=df['close'].astype(float).ffill()
        y=(px.pct_change().shift(-1)>0).astype(int).fillna(0)

        # calibration
        cal=cfg.get('calibration',{'method':'isotonic','by':'session'})
        method,by=cal.get('method','isotonic'), cal.get('by','session')
        if by=='global':
            tr=slice(0,int(len(s1)*0.6))
            model=Calibrator(method).fit(s1.iloc[tr], y.iloc[tr])
            p=pd.Series(model.predict(s1), index=s1.index, name='p')
        else:
            key=s1.index.to_series().apply(session_of_ms)
            p=pd.Series(index=s1.index, dtype=float)
            for k, idx in key.groupby(key).groups.items():
                g_s1,g_y=s1.loc[idx], y.loc[idx]; tr=slice(0,int(len(g_s1)*0.6))
                model=Calibrator(method).fit(g_s1.iloc[tr], g_y.iloc[tr])
                p.loc[idx]=model.predict(g_s1)

        # orderflow shift (bonus/penalty only)
        of=combine_of(df).reindex(p.index).fillna(0.0)
        gamma_map=cfg.get('gamma',{'ASIA':1.4,'EU':1.0,'US':1.1})
        sess=p.index.to_series().apply(session_of_ms)
        gamma=sess.map(gamma_map).fillna(1.0)

        # coverage target
        cov_min=float(cfg.get('coverage_target_min',0.03))
        cov_max=float(cfg.get('coverage_target_max',0.08))
        target=(cov_min+cov_max)/2.0
        thr_map=self._solve_thr_by_session(p, target)
        thr=sess.map(thr_map).astype(float)

        # soft gating (no hard close)
        a=float(cfg.get('gate_a',10.0)); temp=float(cfg.get('gate_logit_temp',10.0)); beta=float(cfg.get('gate_beta',1.2))
        logit=(a*(p-thr)+gamma*of)/max(temp,1e-6)
        gate=(1.0/(1.0+np.exp(-logit)))**beta

        # simple side: rank-based always-on
        rank=gate.rank(pct=True)
        side=((rank>0.5).astype(int)*2-1).astype(int)

        # outputs
        preds=pd.DataFrame({'p_raw':p,'gate':gate,'side':side,'sess':sess})
        preds.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False)
        ret=px.pct_change().fillna(0.0)
        pnl=(side.shift(1).fillna(0)*ret)
        eq=pnl.cumsum()
        trades=pd.DataFrame({'ret':ret,'pnl':pnl,'equity':eq})
        trades.to_csv(os.path.join(out_dir,'trades.csv'), index=False)

        cov_all=float((gate>0.5).mean())
        cov_by=preds.groupby('sess')['gate'].apply(lambda s: float((s>0.5).mean())).to_dict()
        dbg={'target':target,'thr_by_session':{k:float(v) for k,v in thr_map.items()},'cov_overall':cov_all,'cov_by_session':cov_by,'beta':beta}
        with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as f: json.dump(dbg,f,indent=2)

        summary={'coverage_overall':cov_all,'coverage_by_session':cov_by,'n_bars':int(len(df))}
        with open(os.path.join(out_dir,'summary.json'),'w',encoding='utf-8') as f: json.dump(summary,f,indent=2)
        return preds, trades, summary

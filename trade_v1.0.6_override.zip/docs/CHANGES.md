
## v1.0.6
1) S1 재캘리브레이션 (session/regime 선택), 2) 세션 커버리지 임계치 solve,
3) 소프트 게이팅(β,temp) 강화, 4) OF 가중 γ 세분화(session×regime),
5) 리포트 확장(hit_rate, PF, avg_win/loss, rank_ic@topk, ECE/rel, coverage by session/regime).

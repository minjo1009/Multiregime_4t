
import numpy as np
try:
    from sklearn.isotonic import IsotonicRegression
except Exception:
    IsotonicRegression = None
try:
    from sklearn.linear_model import LogisticRegression
except Exception:
    LogisticRegression = None
class Calibrator:
    def __init__(self, method="off"):
        self.method=(method or "off").lower()
        self.model=None
    def fit(self, y_pred, y_true):
        y_pred=np.asarray(y_pred).reshape(-1); y_true=np.asarray(y_true).reshape(-1)
        if self.method=="isotonic" and IsotonicRegression is not None:
            self.model=IsotonicRegression(out_of_bounds="clip").fit(y_pred, y_true)
        elif self.method=="platt" and LogisticRegression is not None:
            lr=LogisticRegression(max_iter=500); lr.fit(y_pred.reshape(-1,1), y_true); self.model=lr
        else:
            self.model=None
    def predict(self, y_pred):
        y_pred=np.asarray(y_pred).reshape(-1)
        if self.model is None or self.method=="off": return y_pred
        if self.method=="isotonic": return self.model.transform(y_pred)
        w=float(self.model.coef_.ravel()[0]); b=float(self.model.intercept_.ravel()[0])
        import numpy as np
        z=w*y_pred+b; return 1.0/(1.0+np.exp(-z))

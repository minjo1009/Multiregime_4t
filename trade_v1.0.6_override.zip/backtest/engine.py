
import os, json, numpy as np, pandas as pd, yaml
from trend4p.data.feeds import load_kline_csv
from trend4p.calibration import Calibrator
from trend4p.signals.s1 import train_predict
from trend4p.utils.regime import tag_regime
from trend4p.utils.oflow import compute_ats, combine_of
from trend4p.utils.gamma import resolve_gamma
from diag.reports import reliability_stats, profit_stats, rank_ic_at_topk

def apply_calibration(prob, df, method, by):
    method=(method or "off").lower(); by=(by or "global").lower()
    if method=="off": return prob
    out = np.array(prob, copy=True); y = df['y01'].to_numpy()
    if by=="session":
        for sess, idx in df.groupby('session').indices.items():
            idx=np.array(idx, dtype=int)
            if len(idx)<50: continue
            n=max(30, int(len(idx)*0.6)); tr=idx[:n]
            cal=Calibrator(method); cal.fit(prob[tr], y[tr]); out[idx]=cal.predict(prob[idx])
    elif by=="regime" and 'regime' in df.columns:
        for rg, idx in df.groupby('regime').indices.items():
            idx=np.array(idx, dtype=int)
            if len(idx)<50: continue
            n=max(30, int(len(idx)*0.6)); tr=idx[:n]
            cal=Calibrator(method); cal.fit(prob[tr], y[tr]); out[idx]=cal.predict(prob[idx])
    else:
        n=max(50, int(len(prob)*0.6))
        cal=Calibrator(method); cal.fit(prob[:n], y[:n]); out=cal.predict(prob)
    return out

def solve_thr_by_session(df, prob_cal, target_map, cut):
    thr_map={}
    if not isinstance(target_map, dict): return thr_map
    for sess, idx in df.iloc[:cut].groupby('session').indices.items():
        tgt = float(target_map.get(sess, 0.0))
        if tgt<=0: continue
        lo, hi = 0.0, 1.0
        idx=np.array(idx, dtype=int)
        for _ in range(24):
            mid=(lo+hi)/2.0
            cov=float((prob_cal[idx] > mid).mean())
            if cov>tgt: lo=mid
            else: hi=mid
        thr_map[sess]=(lo+hi)/2.0
    return thr_map

class BacktestEngine:
    def __init__(self, cfg_path):
        with open(cfg_path,"r",encoding="utf-8") as f:
            self.cfg = yaml.safe_load(f)

    def run(self, data_path, out_dir):
        cfg = self.cfg
        df = load_kline_csv(data_path)
        H  = int(cfg.get('horizon_bars', 15))
        df['regime'] = tag_regime(df, H)
        p_raw, mdl, X, y, fwd = train_predict(df, H)
        df['y01']=y; df['fwd']=fwd
        df['ats']=compute_ats(df)
        if 'ats' not in X.columns:
            X = pd.concat([X, df[['ats']]], axis=1)
        cal_m = cfg.get('calibration',{}).get('method','off')
        cal_by= cfg.get('calibration',{}).get('by','global')
        p_cal = apply_calibration(p_raw, df, cal_m, cal_by)
        cut_ratio = float(cfg.get('report',{}).get('cut_ratio', 0.7))
        cut = int(len(df)*cut_ratio)
        thr_map = solve_thr_by_session(df, p_cal, cfg.get('target_coverage_by_session',{}), cut)
        thr_series = df['session'].map(pd.Series(thr_map)).fillna(0.5).to_numpy()
        of_shift = combine_of(X)
        gamma = resolve_gamma(df, cfg)
        beta=float(cfg.get('gate',{}).get('beta',1.4))
        temp=float(cfg.get('gate',{}).get('temp',10.0))
        logit_core = temp*(p_cal - thr_series) + gamma*of_shift
        p_gate = (1.0/(1.0+np.exp(-logit_core))) ** beta
        p_gate = np.clip(p_gate, 0.0, 1.0)
        df['score']=p_cal; df['gate']=p_gate
        ret = df['close'].pct_change().fillna(0).to_numpy()
        signal = (p_gate>0.5).astype(int)
        pnl = np.r_[0, signal[:-1]*ret[1:]]
        trades = pd.DataFrame({"ts": df['ts'], "signal": signal, "pnl": pnl})
        preds  = pd.DataFrame({"ts": df['ts'], "score": p_cal, "gate": p_gate, "session": df['session'], "regime": df['regime']})
        cov_all = float((p_gate>0.5).mean())
        cov_by_sess = df.groupby('session')['gate'].apply(lambda s: float((s>0.5).mean())).to_dict()
        cov_by_regime = df.groupby('regime')['gate'].apply(lambda s: float((s>0.5).mean())).to_dict()
        rel = reliability_stats(p_cal[cut:], y[cut:])
        pf  = profit_stats(trades.iloc[cut:])
        ric = rank_ic_at_topk(p_cal[cut:], fwd[cut:], topk_pct=int(cfg.get('report',{}).get('rank_ic_topk_pct',10)) )
        os.makedirs(out_dir, exist_ok=True)
        with open(os.path.join(out_dir,"gating_debug.json"),"w",encoding="utf-8") as f:
            json.dump({"cov_overall":cov_all,"cov_by_session":cov_by_sess,"cov_by_regime":cov_by_regime,
                       "thr_by_session":{k: float(v) for k,v in thr_map.items()},"S1_CALIB":rel,"beta":float(beta),"temp":float(temp)}, f, indent=2, ensure_ascii=False)
        meta={"n_obs":int(len(df)),"coverage_overall":cov_all,"coverage_by_session":cov_by_sess,
              "coverage_by_regime":cov_by_regime,"calibration":rel,"profit":pf,"rank_ic_topk":ric}
        return preds, trades, meta

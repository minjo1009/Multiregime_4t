import numpy as np
import pandas as pd

def select_by_cov(proba, cov_band=(0.2,0.4)):
    p = pd.Series(proba).dropna()
    if p.empty: 
        return pd.Series([], dtype=bool), np.nan, 0.0
    target = float(np.mean(cov_band))
    thr = np.quantile(p, 1.0 - target)
    sel = (proba >= thr) | (proba <= (1.0 - thr))  # two-sided
    cov = float(np.mean(sel))
    for _ in range(6):
        if cov < cov_band[0]:
            target = min(0.49, target + 0.01)
        elif cov > cov_band[1]:
            target = max(0.01, target - 0.01)
        else:
            break
        thr = np.quantile(p, 1.0 - target)
        sel = (proba >= thr) | (proba <= (1.0 - thr))
        cov = float(np.mean(sel))
    return sel, float(thr), cov

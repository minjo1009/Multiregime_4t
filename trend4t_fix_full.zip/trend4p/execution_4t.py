import numpy as np, pandas as pd
from sklearn.metrics import accuracy_score, confusion_matrix
from .data_utils import load_ohlcv, slice_timerange
from .features_4t import feat_block
from .labeling import forward_return, choose_k_by_coverage, make_labels
from .model_4t import build_model

def _pick_prob_threshold(p_train: np.ndarray, cov_target: float) -> float:
    # symmetric two-sided selection: outside [1-thr, thr]
    x = np.sort(np.minimum(p_train, 1.0 - p_train))
    q = float(np.clip(cov_target, 0.01, 0.49))
    idx = int(np.clip(np.floor(q * (len(x)-1)), 0, len(x)-1))
    thr = float(1.0 - x[idx])
    return float(np.clip(thr, 0.55, 0.99))

def _metrics(y_true, y_pred, fr, fee_bps: float):
    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)
    fr = np.asarray(fr)
    mask = (y_pred != 0)
    cov = float(mask.mean()) if len(mask) else 0.0
    if cov == 0.0:
        return 0.0, 0.0, 0.0, 0, 1.0, 1.0

    # Accuracy among trades (sign match)
    acc = float((np.sign(y_true[mask]) == np.sign(y_pred[mask])).mean())

    # MCC among trades — guard for single-class warning by passing both labels
    cm = confusion_matrix(np.sign(y_true[mask]).astype(int), np.sign(y_pred[mask]).astype(int), labels=[-1,1])
    if cm.size == 4:
        tn, fp, fn, tp = cm.ravel()
        denom = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) + 1e-12
        mcc = float(((tp*tn - fp*fn)/denom) if denom>0 else 0.0)
    else:
        mcc = 0.0

    n_trades = int(mask.sum())
    gross = np.prod(1.0 + fr[mask] * y_pred[mask])
    fee = (1.0 - fee_bps/10000.0) ** n_trades
    total = float(gross * fee)
    monthly = float(total)  # placeholder: same horizon
    return cov, acc, mcc, n_trades, total, monthly

def backtest(data_path: str, train_start: str, train_end: str, test_start: str, test_end: str,
             H: int = 5, fee_bps: float = 1.0, cov_band=(0.2, 0.4)):
    # 1) load & slice
    df = load_ohlcv(data_path)
    tr = slice_timerange(df, train_start, train_end)
    te = slice_timerange(df, test_start, test_end)

    # 2) features (shift to avoid look-ahead)
    Xtr = feat_block(tr).shift(1).dropna()
    Xte = feat_block(te).shift(1).dropna()

    close_tr = tr["close"].reindex(Xtr.index)
    close_te = te["close"].reindex(Xte.index)

    # 3) labels from forward return with H
    fr_tr = forward_return(close_tr, H)
    fr_te = forward_return(close_te, H)
    k = choose_k_by_coverage(fr_tr.abs(), cov_low=cov_band[0], cov_high=cov_band[1])
    ytr = make_labels(fr_tr, k)
    yte_true = make_labels(fr_te, k)  # for directional evaluation

    # 4) fit on non-zero labels as binary (up=1, down=0) classification
    mask = (ytr != 0).reindex(Xtr.index).fillna(False).values
    if mask.sum() < 50:
        # Not enough events — degrade to simple momentum sign
        p_tr = (Xtr["mom_20"] > 0).astype(float).values
        p_te = (Xte["mom_20"] > 0).astype(float).values
    else:
        Xtr2 = Xtr[mask]; ytr2 = (ytr.reindex(Xtr.index)[mask] > 0).astype(int)
        mdl = build_model()
        mdl.fit(Xtr2, ytr2)
        p_tr = mdl.predict_proba(Xtr)[:,1]
        p_te = mdl.predict_proba(Xte)[:,1]

    # 5) coverage-calibrated threshold from train proba
    cov_target = float(np.mean(cov_band))
    thr = _pick_prob_threshold(p_tr, cov_target)

    yhat_tr = np.where(p_tr >  thr,  1, np.where(p_tr < (1-thr), -1, 0))
    yhat_te = np.where(p_te >  thr,  1, np.where(p_te < (1-thr), -1, 0))

    cov_tr, acc_tr, mcc_tr, ntr, ret_tr, mon_tr = _metrics(ytr.reindex(Xtr.index).values, yhat_tr, fr_tr.reindex(Xtr.index).values, fee_bps)
    cov_te, acc_te, mcc_te, nte, ret_te, mon_te = _metrics(yte_true.reindex(Xte.index).values, yhat_te, fr_te.reindex(Xte.index).values, fee_bps)

    return {
        "H": int(H),
        "k_edge": float(k),
        "prob_threshold": float(thr),
        "train_metrics": {
            "coverage": cov_tr, "acc": acc_tr, "mcc": mcc_tr,
            "n_trades": ntr, "total_return": ret_tr, "monthly_return": mon_tr
        },
        "test_metrics": {
            "coverage": cov_te, "acc": acc_te, "mcc": mcc_te,
            "n_trades": nte, "total_return": ret_te, "monthly_return": mon_te
        },
        "train": {"start": str(Xtr.index.min()), "end": str(Xtr.index.max())},
        "test": {"start": str(Xte.index.min()), "end": str(Xte.index.max())}
    }

import pandas as pd, numpy as np

def rsi(close: pd.Series, n:int=14):
    delta = close.diff()
    gain = delta.clip(lower=0).ewm(alpha=1/n, adjust=False).mean()
    loss = (-delta.clip(upper=0)).ewm(alpha=1/n, adjust=False).mean()
    rs = gain / (loss.replace(0,np.nan))
    return 100 - (100/(1+rs))

def feat_block(df: pd.DataFrame) -> pd.DataFrame:
    c = df["close"]
    o = df["open"]
    h = df["high"]
    l = df["low"]
    out = pd.DataFrame(index=df.index)

    # raw returns
    r1 = c.pct_change()
    out["ret_1"] = r1
    for n in (3,5,10,15,30,60):
        out[f"ret_{n}"] = c.pct_change(n)

    # rolling means / momentum
    for n in (5,10,20,50,100,200):
        ma = c.rolling(n).mean()
        out[f"z_ma_{n}"] = (c - ma)/(c.rolling(n).std() + 1e-9)
        out[f"mom_{n}"] = (c/ma) - 1.0

    # position in rolling window
    for n in (20,50,100,200):
        roll = c.rolling(n)
        out[f"pos_{n}"] = (c - roll.min())/(roll.max()-roll.min() + 1e-9)

    # volatility (per hour scale)
    for n in (10,30,60,180):
        out[f"vol_{n}"] = r1.rolling(n).std().mul(np.sqrt(60))

    # OHLC spreads
    out["hl_spread"] = (h-l)/c.replace(0,np.nan)
    out["oc_spread"] = (c-o)/o.replace(0,np.nan)

    # RSI
    out["rsi_14"] = rsi(c,14)

    out = out.replace([np.inf,-np.inf], np.nan).fillna(0.0)
    return out

import pandas as pd, numpy as np
from backtest.engine import backtest

def make_df(n=5000, seed=0):
    rng = np.random.default_rng(seed)
    close = pd.Series(1000 + np.cumsum(rng.normal(0, 1, n)))
    high  = close + np.abs(rng.normal(0, 1.5, n))
    low   = close - np.abs(rng.normal(0, 1.5, n))
    df = pd.DataFrame({
        "open_time": (pd.Timestamp("2024-01-01", tz='UTC') + pd.to_timedelta(np.arange(n), unit='m')).view('int64')//10**9,
        "open": close.shift(1).fillna(close.iloc[0]),
        "high": high,
        "low": low,
        "close": close,
        "volume": 100 + rng.random(n)*10
    })
    return df

def test_trades_less_than_rows():
    df = make_df()
    trades, summary = backtest(df, {"tp_pct":0.0035,"sl_pct":0.0018,"hold_bars":6,"thr_by_session":{"US":4.0,"EU":3.8,"ASIA":3.5}})
    assert summary["n_trades"] < len(df)

def test_metrics_present():
    df = make_df()
    trades, summary = backtest(df, {"tp_pct":0.0035,"sl_pct":0.0018,"hold_bars":6,"thr_by_session":{"US":4.0,"EU":3.8,"ASIA":3.5}})
    for k in ("hit_rate","profit_factor","n_trades","mcc"):
        assert k in summary and summary[k] is not None
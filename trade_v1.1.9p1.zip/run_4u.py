# -*- coding: utf-8 -*-
"""
run_4u.py — for v1.1.9p1
- Load conf/config.effective.yml if exists, else conf/config.yml
- Validate CSV required columns
- Run engine.backtest
- Write trades.csv, summary.json, gating_debug.json
- Log selected conf path + sha256 (also record in summary.__config_sha256__)
- No placeholders: on any failure, exit(78) without fabricating summary
- Exit 75 on schema/CSV fatal errors
"""
import argparse, json, sys, hashlib, os, pathlib, traceback
import pandas as pd
import yaml

REQUIRED_COLS = ["open_time","open","high","low","close","volume"]

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def read_conf(run_dir: pathlib.Path) -> tuple[dict, str, str]:
    eff = run_dir/"conf"/"config.effective.yml"
    base = run_dir/"conf"/"config.yml"
    if eff.exists():
        text = eff.read_text(encoding="utf-8")
        return yaml.safe_load(text) or {}, str(eff), sha256_text(text)
    elif base.exists():
        text = base.read_text(encoding="utf-8")
        return yaml.safe_load(text) or {}, str(base), sha256_text(text)
    else:
        return {}, "NONE", sha256_text("")

def fatal_exit(code: int, msg: str):
    print(f"[fatal] {msg}", file=sys.stderr)
    sys.exit(code)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--out_dir",   required=True)
    args = ap.parse_args()

    run_dir = pathlib.Path(__file__).resolve().parent
    out_dir = pathlib.Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    # Load CSV
    try:
        df = pd.read_csv(args.data_path)
    except Exception as e:
        fatal_exit(75, f"csv read error: {e}")

    # Schema check
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        fatal_exit(75, f"required columns missing: {missing}")

    n_rows = int(len(df))

    # Load conf (effective first)
    cfg, cfg_path, cfg_sha = read_conf(run_dir)
    print(f"[config] using={cfg_path} sha256={cfg_sha}")

    # Write gating_debug with thr_by_session passthrough (if any)
    thr = (cfg.get("thr_by_session") or {}) if isinstance(cfg, dict) else {}
    gating_debug = {"thr_by_session": thr}
    (out_dir/"gating_debug.json").write_text(json.dumps(gating_debug, ensure_ascii=False, indent=2), encoding="utf-8")

    # Run engine
    try:
        from backtest.engine import backtest
        trades, summary = backtest(df, cfg)
    except SystemExit as se:
        raise
    except Exception as e:
        (out_dir/"_error.log").write_text(traceback.format_exc(), encoding="utf-8")
        fatal_exit(78, f"engine failed: {e}")

    # Validate summary metrics
    for k in ("hit_rate","profit_factor","n_trades"):
        if k not in summary or summary[k] is None:
            fatal_exit(78, f"missing metric in summary: {k}")

    # Save outputs
    trades.to_csv(out_dir/"trades.csv", index=False)
    summary["__config_path__"] = cfg_path
    summary["__config_sha256__"] = cfg_sha
    summary["n_rows"] = n_rows
    (out_dir/"summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"[done] outputs at {out_dir}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
# -*- coding: utf-8 -*-
"""
backtest/engine.py — v1.1.9p1
Fixes:
- Count a trade ONLY when exactly one of TP/SL is touched within horizon (XOR).
- No-touch or both-touch bars are excluded (NaN → drop).
- Optional regime-gating by session via thr_by_session: z-score >= threshold(session).
- Compute MCC based on sign of H-step forward return vs realized direction (TP=+1, SL=-1).
"""
from typing import Dict, Any, Tuple
import pandas as pd
import numpy as np

REQUIRED_COLS = ["open_time","open","high","low","close","volume"]

def _alias(cfg: Dict[str, Any], keys, default=None):
    for k in keys:
        if k in cfg and cfg[k] is not None:
            return cfg[k]
    return default

def normalize_config(cfg: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(cfg or {})
    out["tp_pct"] = float(_alias(out, ["tp_pct","tp","take_profit"], 0.003))
    out["sl_pct"] = float(_alias(out, ["sl_pct","sl","stop_loss"], 0.0015))
    out["hold_bars"] = int(_alias(out, ["hold_bars","hold","holding_period"], 6))
    out["z_window"] = int(_alias(out, ["z_window"], 288))  # 2일(1분봉 가정) 정도
    tbs = _alias(out, ["thr_by_session"], {})
    out["thr_by_session"] = tbs if isinstance(tbs, dict) else {}
    return out

def validate_df(df: pd.DataFrame):
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"missing required cols: {missing}")
    if len(df) < 100:
        raise ValueError("too few rows for backtest (min 100)")

def _future_max_min(series: pd.Series, window: int) -> Tuple[pd.Series, pd.Series]:
    rev = series[::-1]
    fmax = rev.rolling(window, min_periods=window).max()[::-1].shift(-(window-1))
    fmin = rev.rolling(window, min_periods=window).min()[::-1].shift(-(window-1))
    return fmax, fmin

def _epoch_to_hour(open_time: pd.Series) -> pd.Series:
    ot = pd.to_numeric(open_time, errors="coerce")
    ms = ot.max() > 1e11
    dt = pd.to_datetime(ot, unit=('ms' if ms else 's'), utc=True)
    return dt.dt.hour

def _session_from_hour(hour: pd.Series) -> pd.Series:
    s = pd.Series(np.where((hour>=0) & (hour<7), "ASIA",
                np.where((hour>=7) & (hour<13), "EU",
                np.where((hour>=13) & (hour<20), "US", "OTHER"))),
                index=hour.index)
    return s

def _mcc(tp, tn, fp, fn):
    num = tp*tn - fp*fn
    den = (tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)
    if den <= 0:
        return None
    return float(num / (den ** 0.5))

def backtest(df: pd.DataFrame, cfg: Dict[str, Any]):
    validate_df(df)
    C = normalize_config(cfg)
    tp = C["tp_pct"]; sl = C["sl_pct"]; H = C["hold_bars"]
    W = C["z_window"]
    thr_map = C["thr_by_session"] or {}

    close = pd.to_numeric(df["close"], errors="coerce").astype(float)
    high  = pd.to_numeric(df["high"], errors="coerce").astype(float)
    low   = pd.to_numeric(df["low"], errors="coerce").astype(float)

    # Session + simple regime z-score
    hour = _epoch_to_hour(df["open_time"])
    session = _session_from_hour(hour)
    r = close.pct_change()
    vol = r.rolling(W, min_periods=max(10, W//4)).std().replace(0, np.nan)
    z = (r.abs() / vol).replace([np.inf, -np.inf], np.nan).fillna(0.0)

    thr = pd.Series(0.0, index=close.index)
    thr[session=="US"]   = float(thr_map.get("US", 0.0))
    thr[session=="EU"]   = float(thr_map.get("EU", 0.0))
    thr[session=="ASIA"] = float(thr_map.get("ASIA", 0.0))
    regime_ok = z >= thr

    # Future extrema within horizon
    fmax, _ = _future_max_min(high, H)
    _, fmin = _future_max_min(low, H)

    tp_price = close * (1.0 + tp)
    sl_price = close * (1.0 - sl)

    hit_tp = (fmax >= tp_price)
    hit_sl = (fmin <= sl_price)

    # Only exactly one side (XOR) and regime gate
    one_side = hit_tp ^ hit_sl
    valid = one_side & regime_ok

    pnl = np.where(valid & hit_tp,  tp,
          np.where(valid & hit_sl, -sl, np.nan))

    # Exclude last H bars
    if H > 0:
        pnl[-H:] = np.nan

    trades = pd.DataFrame({
        "open_time": df["open_time"],
        "pnl": pnl
    }).dropna()

    v = trades["pnl"].astype(float)
    n = int(v.count())
    if n == 0:
        raise RuntimeError("no trades generated (n_trades=0)")
    hit_rate = float((v > 0).mean())
    pos = float(v[v > 0].sum())
    neg = float((-v[v < 0]).sum())
    profit_factor = (pos / neg) if neg > 0 else (1e9 if pos > 0 else 0.0)

    # MCC vs H-step forward drift
    # pred: +1 if TP, -1 if SL; true: sign of H-step return
    fwd = close.shift(-H)
    fwdret = (fwd / close) - 1.0
    # Align with trades rows
    t = trades.copy()
    t["pred"] = np.where(t["pnl"] > 0, 1, -1)
    t_idx = trades.index
    true = np.sign(fwdret.reindex(t_idx).astype(float).fillna(0.0))
    # map true to {-1, +1} (0 → drop)
    mask = true != 0
    y_true = true[mask]
    y_pred = t["pred"].reindex(y_true.index)
    tp_c = int(((y_true == 1) & (y_pred == 1)).sum())
    tn_c = int(((y_true == -1) & (y_pred == -1)).sum())
    fp_c = int(((y_true == -1) & (y_pred == 1)).sum())
    fn_c = int(((y_true == 1) & (y_pred == -1)).sum())
    mcc = _mcc(tp_c, tn_c, fp_c, fn_c)

    summary = {
        "hit_rate": float(hit_rate),
        "profit_factor": float(profit_factor),
        "n_trades": int(n),
        "mcc": mcc,
        "tp_pct": float(tp),
        "sl_pct": float(sl),
        "hold_bars": int(H),
        "z_window": int(W),
        "thr_by_session": thr_map,
    }
    return trades, summary
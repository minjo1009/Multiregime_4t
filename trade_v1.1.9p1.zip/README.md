# trade_v1.1.9p1

핵심 수정
- **트레이드 집계 규칙(XOR)**: TP/SL 중 정확히 하나만 터치한 경우만 트레이드로 카운트.
- **레짐 게이트(옵션)**: `thr_by_session`에 따라 z-score >= 임계치일 때만 유효.
- **MCC 계산 추가**: H바 후 수익률의 부호와 realized 방향(TP=+1, SL=-1) 간의 MCC 산출.

보장
- 실패 시 placeholder 금지. 핵심 지표(hit_rate/profit_factor/n_trades/mcc) 기록.

사용
```
python run_4u.py --data_path <CSV> --out_dir <OUT_DIR>
```
# Trend 4t — Hotfix Full Pack (override-ready)

## What’s fixed (recap)
1) **Time column**: accepts `open_time`, `Open time`, `timestamp`, `ts`, `date`, `datetime`, `time` → canonical `ts` (UTC).
2) **Pandas deprecations**: removed `infer_datetime_format`, robust parser for int/str timestamps.
3) **Coverage gating**: probability threshold is calibrated from train-proba to match a target coverage band (two-sided).
4) **Scikit-learn 1.4+**: `CalibratedClassifierCV(estimator=..., method="sigmoid")` (no `base_estimator`).
5) **MCC warnings**: confusion matrix computed on *traded* subset with explicit labels `[-1, 1]`.
6) **No look-ahead**: features are shifted by 1 bar; labels use `H`-step forward return.
7) **Minutely grid**: force 1-min OHLCV via resample if needed, right-closed/right-labeled.

## Quick start
```bash
python run_4t.py   --data ./data/ETHUSDT_1min_2020_2025.csv   --train_start 2025-01-01 --train_end 2025-04-30   --test_start  2025-05-01  --test_end  2025-06-30   --H 5 --fee_bps 1.0 --cov_low 0.20 --cov_high 0.40   --out_dir ./_out_4t
```
Output `summary.json` is also printed to stdout.

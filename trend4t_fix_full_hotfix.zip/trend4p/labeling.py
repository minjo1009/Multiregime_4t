import pandas as pd, numpy as np

def forward_return(close: pd.Series, H:int) -> pd.Series:
    return (close.shift(-H)/close - 1.0)

def choose_k_by_coverage(fr_abs: pd.Series, cov_low: float, cov_high: float) -> float:
    cov_target = (cov_low + cov_high) / 2.0
    q = 1.0 - cov_target
    k = float(fr_abs.quantile(q))
    if not np.isfinite(k) or k <= 0:
        k = float(fr_abs.dropna().abs().median())
        if not np.isfinite(k) or k<=0: k = 1e-4
    return k

def make_labels(fr: pd.Series, k: float) -> pd.Series:
    y = fr.copy()*0
    y[fr >  k] =  1
    y[fr < -k] = -1
    y = y.replace([float('inf'), float('-inf')], float('nan')).fillna(0)
    return y.astype(int)

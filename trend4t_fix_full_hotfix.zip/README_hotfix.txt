Hotfix notes (trend4t_fix_full_hotfix):
- trend4p/labeling.py: fillna(0) before int cast to prevent IntCastingNaNError.
- requirements.txt: ensure core deps (numpy, pandas, scikit-learn, scipy, joblib).

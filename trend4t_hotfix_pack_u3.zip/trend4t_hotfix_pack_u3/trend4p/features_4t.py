import numpy as np, pandas as pd

def rsi(series, win=14):
    delta = series.diff()
    up = (delta.clip(lower=0)).rolling(win).mean()
    down = (-delta.clip(upper=0)).rolling(win).mean()
    rs = up / (down + 1e-9)
    return 100 - (100 / (1 + rs))

def make_features(df):
    out = pd.DataFrame(index=df.index)
    # returns
    out["ret1"] = df["close"].pct_change().fillna(0)
    out["logret1"] = (df["close"].apply(lambda x: np.log(x+1e-12))).diff().fillna(0)
    # EMAs
    out["ema_fast"] = df["close"].ewm(span=12, adjust=False).mean()
    out["ema_slow"] = df["close"].ewm(span=48, adjust=False).mean()
    out["ema_diff"] = (out["ema_fast"] - out["ema_slow"]) / (df["close"] + 1e-12)
    # Vol
    out["vol20"] = out["ret1"].rolling(20).std().fillna(0)
    # RSI
    out["rsi14"] = rsi(df["close"]).fillna(50)
    # fill
    out = out.replace([np.inf,-np.inf], 0).fillna(0)
    return out

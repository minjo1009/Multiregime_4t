import numpy as np, pandas as pd

def make_forward_return(df, H):
    # H-step forward return (close-to-close)
    return df["close"].shift(-H) / df["close"] - 1.0

def make_labels(df, H):
    fr = make_forward_return(df, H)
    y = (fr > 0).astype(float)  # binary label
    # hotfix: ensure no NaN/inf -> 0 and cast to int safely
    y = y.replace([np.inf, -np.inf], np.nan).fillna(0.0)
    return y.astype(int)

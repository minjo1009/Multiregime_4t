#!/usr/bin/env python3
# v1.1.5 unified entry — preflight → effective-config → engine → fallback → artifacts
from __future__ import annotations
import os, sys, json, argparse, pathlib, subprocess, traceback

ROOT = pathlib.Path(__file__).resolve().parent
RUN_DIR = ROOT
OUT_DIR = ROOT / "_out_4u" / "run"
CONF_DIR = ROOT / "conf"
DEFAULT_CFG = CONF_DIR / "config.yml"
EFFECTIVE_CFG = CONF_DIR / "config.effective.yml"

REQ_COLS = ["open_time","open","high","low","close","volume"]

def sh(cmd, cwd=None, allow_fail=False):
    try:
        subprocess.check_call(cmd, cwd=str(cwd) if cwd else None)
        return 0
    except subprocess.CalledProcessError as e:
        if allow_fail: 
            return e.returncode
        raise

def ensure_dir(p: pathlib.Path): 
    p.mkdir(parents=True, exist_ok=True)

def preflight(csv_path: str):
    ensure_dir(OUT_DIR)
    code = sh([sys.executable, "scripts/preflight_strict.py", csv_path], cwd=RUN_DIR, allow_fail=True)
    if code != 0:
        print(f"[preflight] FAILED({code}) for {csv_path}", file=sys.stderr)
        sys.exit(64)

def make_effective_config():
    # merge ENV overrides → conf/config.effective.yml
    sh([sys.executable, "backtest/exit_bridge.py"], cwd=RUN_DIR, allow_fail=True)
    if not EFFECTIVE_CFG.exists():
        # fallback: 기본 config라도 보장
        if DEFAULT_CFG.exists():
            EFFECTIVE_CFG.write_text(DEFAULT_CFG.read_text(), encoding="utf-8")

def run_engine(csv_path: str):
    os.environ.setdefault("PYTHONPATH", str(RUN_DIR))
    # 1) 정식 엔진(어댑터 경유)
    try:
        from backtest.engine_adapter import run_backtest
        cfg = str(EFFECTIVE_CFG if EFFECTIVE_CFG.exists() else DEFAULT_CFG)
        run_backtest(csv_path, cfg, str(OUT_DIR))
        return True
    except Exception:
        traceback.print_exc()
        return False

def run_fallback(csv_path: str):
    # 최소 아티팩트 보장을 위한 스모크 러너
    code = sh([sys.executable, "backtest/run_v108.py", "--data_path", csv_path, "--out_dir", str(OUT_DIR)],
              cwd=RUN_DIR, allow_fail=True)
    return code == 0

def ensure_artifacts():
    ensure_dir(OUT_DIR)
    # gating_debug.json
    gd = OUT_DIR / "gating_debug.json"
    if not gd.exists():
        gd.write_text(json.dumps({"_note":"fallback stub"}, ensure_ascii=False, indent=2), encoding="utf-8")
    # summary.json
    sj = OUT_DIR / "summary.json"
    if not sj.exists():
        sj.write_text(json.dumps({"status":"fallback","hit_rate":None,"mcc":None,"coverage_overall":None},
                                 ensure_ascii=False, indent=2), encoding="utf-8")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=False, help="CSV path")
    ap.add_argument("--data_glob", required=False, help="glob to pick first CSV if data_path missing")
    ap.add_argument("--out_dir", required=False, default=str(OUT_DIR))
    args = ap.parse_args()

    csv = args.data_path
    if not csv and args.data_glob:
        import glob
        cands = sorted(glob.glob(args.data_glob, recursive=True))
        if cands: 
            csv = cands[0]
    if not csv: 
        print("ERROR: no --data_path or --data_glob", file=sys.stderr)
        sys.exit(64)

    # 경로 고정 & 출력 디렉토리 업데이트
    ensure_dir(pathlib.Path(args.out_dir))
    global OUT_DIR
    OUT_DIR = pathlib.Path(args.out_dir)

    preflight(csv)
    make_effective_config()

    ok = run_engine(csv)
    if not ok:
        print("[engine] failed → fallback wrapper", file=sys.stderr)
        run_fallback(csv)

    ensure_artifacts()
    print(f"[done] outputs at {OUT_DIR}")

if __name__ == "__main__":
    main()

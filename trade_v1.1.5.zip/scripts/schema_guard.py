#!/usr/bin/env python3
import os, sys, json
from pathlib import Path
import pandas as pd

REQUIRED = ["time","open","high","low","close","volume"]
CSV_PATH = os.environ.get("CSV_PATH") or Path("scripts/CSV_PATH.txt").read_text().strip()
OUT = Path("_out_4u"); RUN = OUT/"run"
OUT.mkdir(parents=True, exist_ok=True); RUN.mkdir(parents=True, exist_ok=True)

ok=True; msgs=[]
if not CSV_PATH or not os.path.exists(CSV_PATH):
    ok=False; msgs.append("csv_missing")

df=None
if ok:
    try:
        df = pd.read_csv(CSV_PATH, nrows=1000)
    except Exception as e:
        ok=False; msgs.append(f"read_error:{e}")

if df is not None:
    cols = [c.lower() for c in df.columns]
    for r in REQUIRED:
        if not any(r==c or r in c for c in cols):
            ok=False; msgs.append(f"missing_col:{r}")
    if df.isna().any().any():
        msgs.append("has_nan")

diag = {"ok": ok, "msgs": msgs, "csv_path": CSV_PATH}
(RUN/"schema_guard.json").write_text(json.dumps(diag, ensure_ascii=False, indent=2), encoding="utf-8")
print("[schema_guard]", diag)
sys.exit(0 if ok else 2)

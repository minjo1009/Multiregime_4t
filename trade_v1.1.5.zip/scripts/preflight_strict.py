#!/usr/bin/env python3
import sys, json, pandas as pd, pathlib

REQ = ["open_time","open","high","low","close","volume"]
outd = pathlib.Path("_out_4u/run"); outd.mkdir(parents=True, exist_ok=True)

p = sys.argv[1] if len(sys.argv) > 1 else None
if not p: 
    print("no csv path", file=sys.stderr)
    sys.exit(64)

df = pd.read_csv(p, nrows=10000)
miss = [c for c in REQ if c not in df.columns]
info = {
  "path": p,
  "rows_scanned": int(len(df)),
  "columns": list(map(str, df.columns)),
  "missing": miss,
}

# open_time 초/밀리초 힌트
if "open_time" in df.columns:
    ot = pd.to_numeric(df["open_time"].head(5), errors="coerce")
    hint = "unknown"
    if ot.notna().all():
        mx = float(ot.max())
        if mx < 1e11: hint = "seconds_like(×1000?)"
        elif mx < 1e13: hint = "milliseconds_like"
        else: hint = "maybe_ns?"
    info["open_time_hint"] = hint

outd.joinpath("preflight.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
if miss:
    print(f"Missing columns: {miss}", file=sys.stderr)
    sys.exit(65)

print(json.dumps(info, ensure_ascii=False))

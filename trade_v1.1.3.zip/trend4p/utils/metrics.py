import numpy as np
def ece(prob, y, bins=10):
    p=np.clip(np.asarray(prob,float),1e-6,1-1e-6); y=np.asarray(y,int)
    edges=np.linspace(0,1,bins+1); e=0.0
    for i in range(bins):
        m=(p>=edges[i])&(p<edges[i+1])
        if not m.any(): continue
        e += abs(p[m].mean()-y[m].mean()) * m.mean()
    return float(e)
def rel_slope(prob, y):
    p=np.clip(np.asarray(prob,float),1e-6,1-1e-6); y=np.asarray(y,float)
    if p.std()==0: return 0.0
    cov=np.cov(p,y)[0,1]; return float(cov/(p.var()+1e-12))

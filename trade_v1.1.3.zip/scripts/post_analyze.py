#!/usr/bin/env python3
import json, os
from pathlib import Path
import pandas as pd, numpy as np

OUT = Path("_out_4u"); OUT.mkdir(parents=True, exist_ok=True)
RUN = OUT/"run"; RUN.mkdir(parents=True, exist_ok=True)

preds = None
for cand in ["_out_4u/preds_test.csv", "preds_test.csv"]:
    if os.path.exists(cand):
        try:
            preds = pd.read_csv(cand)
            break
        except Exception:
            pass

diag = {}
if preds is not None:
    gcol = None
    for c in ["gate","g","score","prob"]:
        if c in preds.columns:
            gcol = c; break
    if gcol is not None:
        g = pd.to_numeric(preds[gcol], errors="coerce").replace([np.inf,-np.inf], np.nan).dropna()
        if len(g) > 0:
            qs = [0.0,0.01,0.5,0.9,0.95,0.99,1.0]
            diag["gate_percentiles"] = {f"{q:.2f}": float(g.quantile(q)) for q in qs}
            diag["coverage_overall_inferred"] = float((g>0.5).mean())
        sess_col = None
        for c in preds.columns:
            if c.lower() in ("session","sess","market_session"):
                sess_col = c; break
        if sess_col is not None:
            cov_by = {}
            for sname, sub in preds.groupby(sess_col):
                sg = pd.to_numeric(sub[gcol], errors="coerce")
                cov_by[str(sname)] = float((sg>0.5).mean())
            diag["coverage_by_session_inferred"] = cov_by

dst = RUN/"gating_debug.json"
prev = {}
if dst.exists():
    try:
        prev = json.loads(dst.read_text(encoding="utf-8"))
    except Exception:
        prev = {}
prev.update(diag)
dst.write_text(json.dumps(prev, ensure_ascii=False, indent=2), encoding="utf-8")

if not (OUT/"summary.json").exists():
    (OUT/"summary.json").write_text("{}", encoding="utf-8")

print("[post_analyze] wrote", dst, "keys:", list(diag.keys()))
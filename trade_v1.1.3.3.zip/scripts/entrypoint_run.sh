#!/usr/bin/env bash
set -Eeuo pipefail
export PYTHONPATH="tmp/trade:tmp/trade/backtest:${PYTHONPATH:-}"
SEL=$(python - <<'PY'
import glob,os,sys
pat=os.environ.get("CSV_ROOT","tmp/data")+"/"+os.environ.get("CSV_GLOB","**/*.csv")
paths=sorted(glob.glob(pat, recursive=True))
print(paths[0] if paths else "")
PY
)
echo "$SEL" > _out_4u/CSV_PATH.txt
[ -n "$SEL" ] || { echo "::error::No CSV matched"; exit 3; }
python -u tmp/trade/runner.py
mkdir -p _out_4u/run
for f in summary.json preds_test.csv trades.csv gating_debug.json used_config.json; do
  [ -f "_out_4u/run/$f" ] && cp -f "_out_4u/run/$f" "_out_4u/$f" || : > "_out_4u/$f"
done

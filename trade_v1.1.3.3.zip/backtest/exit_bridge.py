from pathlib import Path
import os, yaml, json

def _bool(v): 
    if isinstance(v, bool): return v
    s=str(v).lower()
    return s in ("1","true","yes","y","on")

def main():
    # resolve config path
    eff = Path("tmp/trade/conf/config.effective.yml")
    base = Path("tmp/trade/conf/config.yml")
    p = eff if eff.exists() else base
    if not p.exists():
        print("[exit_bridge] no config found at", p); return 1
    cfg = yaml.safe_load(p.read_text()) or {}
    # normalize sections
    for k in ("pricing","trading","gating","calibration","trade","gate","costs","exit","strategy","params"):
        cfg.setdefault(k, {})
    trade = cfg.setdefault("trade", {})
    # read from trade.* (preferred) or trading.*
    tp = float(trade.get("tp_pct", cfg.get("trading",{}).get("tp_pct", 0.0)))
    sl = float(trade.get("sl_pct", cfg.get("trading",{}).get("sl_pct", 0.0)))
    ttl = int(trade.get("hold_bars", 0) or 0)
    be_on = _bool(trade.get("be_on", False))
    be_tr = float(trade.get("be_trigger_pct", 0.0) or 0.0)
    tr_on = _bool(trade.get("trail_on", False))
    tr_st = float(trade.get("trail_start_pct", 0.0) or 0.0)
    tr_gap = float(trade.get("trail_gap_pct", 0.0) or 0.0)

    # 1) Canonical exit block
    exitb = cfg.setdefault("exit", {})
    exitb["tp_pct"] = tp
    exitb["sl_pct"] = sl
    exitb["ttl_bars"] = ttl
    be = exitb.setdefault("break_even", {})
    be["enabled"] = bool(be_on)
    be["trigger_pct"] = be_tr
    tr = exitb.setdefault("trailing", {})
    tr["enabled"] = bool(tr_on)
    tr["start_pct"] = tr_st
    tr["gap_pct"] = tr_gap

    # 2) strategy.exit alias
    st = cfg.setdefault("strategy", {})
    st_exit = st.setdefault("exit", {})
    for k,v in exitb.items():
        st_exit[k] = v

    # 3) params.* flat aliases (common in many repos)
    params = cfg.setdefault("params", {})
    params.update({
        "exit_ttl_bars": ttl,
        "exit_tp_pct": tp,
        "exit_sl_pct": sl,
        "exit_be_on": bool(be_on),
        "exit_be_trigger_pct": be_tr,
        "exit_trail_on": bool(tr_on),
        "exit_trail_start_pct": tr_st,
        "exit_trail_gap_pct": tr_gap,
    })

    # 4) environment variables as last-resort bridge for runners that read os.environ
    os.environ["EXIT_TTL_BARS"]=str(ttl)
    os.environ["EXIT_TP_PCT"]=str(tp)
    os.environ["EXIT_SL_PCT"]=str(sl)
    os.environ["EXIT_BE_ON"]="1" if be_on else "0"
    os.environ["EXIT_BE_TRIGGER_PCT"]=str(be_tr)
    os.environ["EXIT_TRAIL_ON"]="1" if tr_on else "0"
    os.environ["EXIT_TRAIL_START_PCT"]=str(tr_st)
    os.environ["EXIT_TRAIL_GAP_PCT"]=str(tr_gap)

    # write back to both files to avoid ambiguity
    eff.parent.mkdir(parents=True, exist_ok=True)
    eff.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))
    base.parent.mkdir(parents=True, exist_ok=True)
    base.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))

    Path("_out_4u/run").mkdir(parents=True, exist_ok=True)
    meta = {
        "bridge":"exit_bridge.py",
        "applied": True,
        "tp_pct": tp, "sl_pct": sl, "ttl_bars": ttl,
        "be_on": be_on, "be_trigger_pct": be_tr,
        "trail_on": tr_on, "trail_start_pct": tr_st, "trail_gap_pct": tr_gap
    }
    Path("_out_4u/run/exit_bridge_used.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False))
    print("[exit_bridge] applied", meta)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

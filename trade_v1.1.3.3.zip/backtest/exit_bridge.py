from pathlib import Path
import os, yaml, json

def _b(v):
    if isinstance(v, bool): return v
    s = str(v).strip().lower()
    return s in ("1","true","yes","y","on")

def main():
    eff = Path("tmp/trade/conf/config.effective.yml")
    base = Path("tmp/trade/conf/config.yml")
    p = eff if eff.exists() else base
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        cfg = {"trade": {}}
    else:
        cfg = yaml.safe_load(p.read_text()) or {}
    for k in ("pricing","trading","gating","calibration","trade","gate","costs","exit","strategy","params"):
        cfg.setdefault(k, {})

    trade = cfg["trade"]

    def env_num(key, dflt=None, cast=float):
        v = os.environ.get(key, None)
        if v is None: return dflt
        try: return cast(v)
        except: return dflt

    tp = trade.get("tp_pct", env_num("EXIT_TP_PCT", 0.0))
    sl = trade.get("sl_pct", env_num("EXIT_SL_PCT", 0.0))
    ttl = trade.get("hold_bars", env_num("EXIT_TTL_BARS", 0, int))
    be_on = trade.get("be_on", _b(os.environ.get("EXIT_BE_ON", "false")))
    be_tr = trade.get("be_trigger_pct", env_num("EXIT_BE_TRIGGER_PCT", 0.0))
    tr_on = trade.get("trail_on", _b(os.environ.get("EXIT_TRAIL_ON", "false")))
    tr_st = trade.get("trail_start_pct", env_num("EXIT_TRAIL_START_PCT", 0.0))
    tr_gap = trade.get("trail_gap_pct", env_num("EXIT_TRAIL_GAP_PCT", 0.0))

    trade.update({
        "tp_pct": float(tp),
        "sl_pct": float(sl),
        "hold_bars": int(ttl or 0),
        "be_on": bool(be_on),
        "be_trigger_pct": float(be_tr or 0.0),
        "trail_on": bool(tr_on),
        "trail_start_pct": float(tr_st or 0.0),
        "trail_gap_pct": float(tr_gap or 0.0),
    })

    exitb = cfg["exit"]
    exitb["tp_pct"] = float(tp)
    exitb["sl_pct"] = float(sl)
    exitb["ttl_bars"] = int(ttl or 0)
    be = exitb.setdefault("break_even", {})
    be["enabled"] = bool(be_on)
    be["trigger_pct"] = float(be_tr or 0.0)
    tr = exitb.setdefault("trailing", {})
    tr["enabled"] = bool(tr_on)
    tr["start_pct"] = float(tr_st or 0.0)
    tr["gap_pct"] = float(tr_gap or 0.0)

    cfg["strategy"].setdefault("exit", {}).update(exitb)
    cfg["params"].update({
        "exit_ttl_bars": int(ttl or 0),
        "exit_tp_pct": float(tp),
        "exit_sl_pct": float(sl),
        "exit_be_on": bool(be_on),
        "exit_be_trigger_pct": float(be_tr or 0.0),
        "exit_trail_on": bool(tr_on),
        "exit_trail_start_pct": float(tr_st or 0.0),
        "exit_trail_gap_pct": float(tr_gap or 0.0),
    })

    # also export ENV synonyms (defensive)
    os.environ["EXIT_TP_PCT"] = str(trade["tp_pct"])
    os.environ["EXIT_SL_PCT"] = str(trade["sl_pct"])
    os.environ["EXIT_TTL_BARS"] = str(trade["hold_bars"])
    os.environ["EXIT_BE_ON"] = "1" if trade["be_on"] else "0"
    os.environ["EXIT_BE_TRIGGER_PCT"] = str(trade["be_trigger_pct"])
    os.environ["EXIT_TRAIL_ON"] = "1" if trade["trail_on"] else "0"
    os.environ["EXIT_TRAIL_START_PCT"] = str(trade["trail_start_pct"])
    os.environ["EXIT_TRAIL_GAP_PCT"] = str(trade["trail_gap_pct"])
    os.environ["HOLD_BARS"] = os.environ["EXIT_TTL_BARS"]
    os.environ["TTL_BARS"] = os.environ["EXIT_TTL_BARS"]
    os.environ["MAX_HOLD_BARS"] = os.environ["EXIT_TTL_BARS"]
    os.environ["TRADE_HOLD_BARS"] = os.environ["EXIT_TTL_BARS"]
    os.environ["SOT_HOLD_BARS"] = os.environ["EXIT_TTL_BARS"]
    os.environ["TP_PCT"] = os.environ["EXIT_TP_PCT"]
    os.environ["SL_PCT"] = os.environ["EXIT_SL_PCT"]

    eff.parent.mkdir(parents=True, exist_ok=True)
    base.parent.mkdir(parents=True, exist_ok=True)
    eff.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))
    base.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))

    Path("_out_4u/run").mkdir(parents=True, exist_ok=True)
    Path("_out_4u/run/exit_bridge_used.json").write_text(json.dumps({
        "bridge": "exit_bridge.py",
        "applied": True,
        "trade": trade
    }, indent=2, ensure_ascii=False))
    print("[exit_bridge] applied")

if __name__ == "__main__":
    main()

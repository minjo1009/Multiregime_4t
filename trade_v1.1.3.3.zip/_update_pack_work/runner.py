#!/usr/bin/env python3
import os, sys, runpy
from pathlib import Path

def main():
    root = Path(__file__).resolve().parent
    # apply bridge
    try:
        sys.path[:0] = [str(root), str(root/"backtest")]
        from backtest.exit_bridge import main as exit_bridge
        exit_bridge()
    except Exception as e:
        print("WARN(exit_bridge):", e)

    # choose an underlying runner
    candidates = [
        root/"run_4u.py",
        root/"backtest"/"runner.py",
        root/"backtest"/"engine.py",
    ]
    target = next((p for p in candidates if p.exists()), None)
    if not target:
        print("::error::No underlying engine/runner found.", [str(p) for p in candidates])
        sys.exit(5)

    # pass basic args for run_4u.py
    args = []
    if target.name == "run_4u.py":
        data_path = os.environ.get("DATA_PATH")
        if not data_path and Path("_out_4u/CSV_PATH.txt").exists():
            data_path = Path("_out_4u/CSV_PATH.txt").read_text().strip()
        if data_path:
            args = ["--data_path", data_path, "--config", "tmp/trade/conf/config.yml"]

    os.environ["PYTHONPATH"] = f"{root}:{root/'backtest'}:" + os.environ.get("PYTHONPATH","")
    sys.argv = [str(target)] + args
    print("[RUN->]", target, "args=", args)
    runpy.run_path(str(target), run_name="__main__")

if __name__ == "__main__":
    main()

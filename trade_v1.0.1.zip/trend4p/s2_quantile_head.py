
import numpy as np, pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
class S2QuantileHead:
    def __init__(self, taus=(0.1,0.5,0.9)): self.taus=taus; self.models={}
    def fit(self, X, y, r_post):
        w=np.clip(r_post.mean(axis=1),1e-6,1.0)
        for t in self.taus:
            m=GradientBoostingRegressor(loss='quantile', alpha=t, random_state=42); m.fit(X,y,sample_weight=w); self.models[t]=m
        return self
    def predict_quantiles(self, X):
        out={f'q{int(t*100)}': self.models[t].predict(X) for t in self.taus}; return pd.DataFrame(out, index=X.index)
def quantiles_to_mu_sigma_es(q, alpha=0.1):
    q10=q['q10']; q50=q['q50']; q90=q['q90']; mu=(q10+q50+q90)/3.0; iqr=(q90-q10); sigma=(iqr/1.35).abs(); es=q10
    return mu.values, sigma.values, es.values


import pandas as pd, numpy as np

REQUIRED_BASE = {'open_time','open','high','low','close','volume','number_of_trades'}
# We accept either taker_buy_base_asset_volume (preferred) or taker_buy_quote_asset_volume (fallback).

def load_kline_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    # drop common junk index columns if present
    for junk in ['Unnamed: 0', 'index']:
        if junk in df.columns: df = df.drop(columns=[junk])

    cols = set(df.columns)
    missing = REQUIRED_BASE - cols
    if missing:
        raise ValueError(f"Missing columns: {missing}")

    # Choose/construct taker_buy_base_asset_volume
    has_base = 'taker_buy_base_asset_volume' in cols
    has_quote = 'taker_buy_quote_asset_volume' in cols

    # typing
    for c in ['open','high','low','close','volume']:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    if 'taker_buy_base_asset_volume' in df.columns:
        df['taker_buy_base_asset_volume'] = pd.to_numeric(df['taker_buy_base_asset_volume'], errors='coerce')
    if 'taker_buy_quote_asset_volume' in df.columns:
        df['taker_buy_quote_asset_volume'] = pd.to_numeric(df['taker_buy_quote_asset_volume'], errors='coerce')
    df['number_of_trades'] = pd.to_numeric(df['number_of_trades'], errors='coerce').fillna(0).astype(int)

    # timestamp parse (ms epoch or ISO string)
    try:
        ts = pd.to_datetime(df['open_time'], unit='ms', utc=True)
    except Exception:
        ts = pd.to_datetime(df['open_time'], utc=True, errors='coerce')
    df['ts'] = ts
    df = df.dropna(subset=['ts']).reset_index(drop=True)

    if not has_base and has_quote:
        # Convert quote(USDT) -> base(ETH) using typical price to reduce bias
        tp = (df['high'] + df['low'] + df['close']) / 3.0
        tp = tp.replace(0, np.nan)
        df['taker_buy_base_asset_volume'] = (df['taker_buy_quote_asset_volume'] / tp).fillna(0.0)

    # Final guard
    if 'taker_buy_base_asset_volume' not in df.columns:
        raise ValueError("Neither 'taker_buy_base_asset_volume' nor convertible 'taker_buy_quote_asset_volume' present.")

    df['ret1'] = np.log(df['close']).diff()
    return df

def label_future_return(df: pd.DataFrame, horizon: int) -> pd.Series:
    return np.log(df['close'].shift(-horizon) / df['close'])

def add_session_cols(df: pd.DataFrame) -> pd.DataFrame:
    hour = df['ts'].dt.hour
    sess = hour.map(lambda h: 'ASIA' if 0<=h<8 else ('EU' if 8<=h<16 else 'US'))
    df['session'] = sess
    for s in ['ASIA','EU','US']:
        df[f'sess_{s}'] = (df['session']==s).astype(int)
    return df


import numpy as np
class CoverageController:
    def __init__(self, target_min=0.03, target_max=0.08): self.tmin=target_min; self.tmax=target_max; self.s0=0.0; self.a=10.0
    def update(self, cov):
        if cov<self.tmin: self.s0-=0.02
        elif cov>self.tmax: self.s0+=0.02
        self.s0=float(np.clip(self.s0,-1.0,1.0))
def gate_scores(mu_net, es, a, s0, lambda_tail=1.0):
    import numpy as np
    score = mu_net - lambda_tail*np.abs(es)
    g = 1.0/(1.0+np.exp(-a*(score - s0)))
    return score, g


import os, json, numpy as np, pandas as pd
from trend4p.data.feeds import load_kline_csv, label_future_return, add_session_cols
from trend4p.data.feature_basic import add_basic_features
from trend4p.feature_orderflow import compute_orderflow_features
from trend4p.regime_posterior import RegimePosterior, heuristic_prelabel
from trend4p.s1_dir_head import S1DirHeadMoE
from trend4p.s2_quantile_head import S2QuantileHead, quantiles_to_mu_sigma_es
from trend4p.gating import CoverageController, gate_scores
from trend4p.sizing import fractional_kelly, vol_targeting
from backtest.analyzers import basic_metrics

import yaml
def load_cfg(path): 
    with open(path,'r',encoding='utf-8') as f: return yaml.safe_load(f)

def run_backtest(data_path, cfg_path, out_dir):
    cfg=load_cfg(cfg_path); H=int(cfg['horizon_bars'])
    df=load_kline_csv(data_path); df=add_session_cols(df); df=add_basic_features(df)
    df=compute_orderflow_features(df, vpin_vol_k=cfg['vpin_bucket_mult'], vpin_m=cfg['vpin_m'], roll_lambda=cfg['lambda_roll'])
    df['y_ret']=label_future_return(df,H); df['y01']=(df['y_ret']>0).astype(int)
    slow=['mom_15','rv_60','VPIN','lambda_kyle','ATS']
    pre=heuristic_prelabel(df[slow]); rp=RegimePosterior().fit(df[slow].fillna(0), pre); r_post=rp.predict_proba(df[slow].fillna(0))
    feat=[c for c in df.columns if c.startswith('mom_') or c.startswith('rv_')] + ['DR','CVD_slope','VPIN','lambda_kyle','OFI_proxy','ATS','sess_ASIA','sess_EU','sess_US']
    X=df[feat].fillna(0); s1=S1DirHeadMoE().fit(X, df['y01'], r_post); df['p_long']=s1.predict_proba(X, r_post)
    s2=S2QuantileHead().fit(X, df['y_ret'].fillna(0), r_post); q=s2.predict_quantiles(X); mu,sigma,es=quantiles_to_mu_sigma_es(q, alpha=cfg['es_alpha'])
    df['mu']=mu; df['sigma']=sigma; df['es']=es
    cost_bps=cfg['fee_bps']+cfg['slip_bps_base']; mu_net=df['mu']-cost_bps*1e-4
    score,gate=gate_scores(mu_net.values, df['es'].values, a=10.0, s0=0.0); df['score']=score; df['gate']=gate
    size=fractional_kelly(df['mu'].values, np.maximum(1e-6,df['sigma'].values), frac=cfg['kelly_fraction'])
    df['size']=vol_targeting(size, np.maximum(1e-6,df['sigma'].values), target_vol=0.02)
    preds,tlog = __import__('trend4p.executor.sim_exec', fromlist=['simulate_trades']).simulate_trades(df,H,cost_bps)
    # group by session
    by_bucket=preds.groupby('session').agg(trades=('gate', lambda s:(s>0.5).sum()), hit=('ret_fut', lambda r: float((r[preds.loc[r.index,'gate']>0.5]>0).mean()) if (preds.loc[r.index,'gate']>0.5).sum()>0 else 0), pnl_net=('pnl','sum')).reset_index()
    micro=preds[['ts','VPIN','lambda_kyle','ATS']].copy(); costs=preds[['ts','cost_bps']].copy()
    meta={'algo_version':'trade_v1.0','cfg':cfg,'data_span':f"{str(preds['ts'].iloc[0])}~{str(preds['ts'].iloc[-1])}",'horizon_bars':H}
    preds.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False); tlog.to_csv(os.path.join(out_dir,'trades.csv'), index=False)
    return preds, tlog, micro, costs, by_bucket, meta

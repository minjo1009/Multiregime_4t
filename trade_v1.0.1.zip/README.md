# trade_v1.0

Quick start:
```
pip install -r requirements.txt
python run_4u.py --data_path /path/to/ETHUSDT_1min.csv --out_dir _out_4u/run
```

## v1.0.1 Hotfix
- CSV 로더가 `taker_buy_quote_asset_volume`만 있을 경우, 전형가격((H+L+C)/3)으로 base 체결량을 추정해 `taker_buy_base_asset_volume`을 생성합니다.

# v1.0.6B Override Checklist
- [x] Calibration by-session (isotonic) configured
- [x] Coverage targets per session (5~7%) defined
- [x] Gate = sigma(temp*(p_cal - thr_sess) + gamma*OF)^beta (no hard cut)
- [x] OF combine_of returns (N,) time-wise mean of z-scores
- [x] Quantile fallback threshold if solver cache missing
- [x] Save gating_debug.json (thr_by_session, coverage, slope, ece, params)
- [x] YAML in CI should point outputs to workspace/_out_4u/run

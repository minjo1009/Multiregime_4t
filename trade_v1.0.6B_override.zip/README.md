# trade_v1.0.6B_override (overlay pack)
Drop these files into your repo root to override StrategyV1-critical parts (no hard cuts, coverage allocator, OF combine, calibration by session).

## Files
- conf/config.yml — Strategy V1 config (isotonic by session, coverage targets, gate params)
- trend4p/utils/oflow.py — hardened `combine_of` → returns (N,) time-wise mean
- tools/apply_106b_patch.py — in-place patcher for `backtest/engine.py` (idempotent)
- docs/CHECKLIST_106B.md — what to verify after run

## How to apply
1) Commit this overlay into the repo root (preserve paths).
2) In your GitHub Action, add a step:
   ```bash
   python tools/apply_106b_patch.py
   ```
   right after unzipping and before running the backtest.
3) Run workflow with your usual inputs.
4) Verify `gating_debug.json` and `summary.json` under `_out_4u/run`:
   - coverage_by_session.actual around targets (5~7%)
   - s1.rel_slope ≈ 1, ece < 0.01
   - artifacts uploaded without path issues.

If anything clashes with local customization, `apply_106b_patch.py` is safe to run multiple times.

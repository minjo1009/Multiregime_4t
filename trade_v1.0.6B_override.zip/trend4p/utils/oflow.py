# -*- coding: utf-8 -*-
"""Order-flow utilities — v1.0.6B
combine_of: returns time-wise (N,) z-mean of VPIN/ATS/lambda_kyle columns if present.
"""
from __future__ import annotations
import numpy as np

def _z(a):
    a = np.asarray(a, dtype=float)
    m = np.nanmedian(a)
    sd = np.nanstd(a)
    if (sd == 0) or (not np.isfinite(sd)):
        sd = 1e-12
    return (a - m) / sd

def combine_of(df_or_X):
    # Accept pandas-like with columns or np.ndarray-like
    if hasattr(df_or_X, "columns"):
        cols = [c for c in ["VPIN", "ATS", "lambda_kyle"] if c in df_or_X.columns]
        n = len(df_or_X)
        if not cols:
            return np.zeros(n, dtype=float)
        arrs = [np.asarray(_z(df_or_X[c]), dtype=float).reshape(-1) for c in cols]
        Z = np.column_stack(arrs)   # (N, k)
        return np.nanmean(Z, axis=1)  # (N,)
    else:
        arr = np.asarray(df_or_X, dtype=float)
        if arr.ndim == 2 and arr.shape[0] in (3,) and arr.shape[1] >= 1:
            # assume shape (3, N) like vstack; take mean over rows→(N,)
            return np.nanmean(arr, axis=0)
        if arr.ndim == 2 and arr.shape[1] in (3,) and arr.shape[0] >= 1:
            # assume shape (N, 3); take mean over cols→(N,)
            return np.nanmean(arr, axis=1)
        if arr.ndim == 1:
            return np.nan_to_num(arr, copy=False)
        # fallback
        return np.zeros(arr.shape[0] if arr.ndim > 0 else 0, dtype=float)

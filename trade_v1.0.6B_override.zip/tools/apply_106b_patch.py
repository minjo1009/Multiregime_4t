# -*- coding: utf-8 -*-
"""Apply in-place patches to backtest/engine.py for trade v1.0.6B.
- Force import of combine_of
- Inject coverage solver (binary search) + quantile fallback
- Enforce soft gating (no hard cut) with temperature/beta/of_gamma
- Save gating_debug.json (thr_by_session, coverage, ECE, rel_slope, params)
This script is idempotent.
Usage:
  python tools/apply_106b_patch.py
"""
from __future__ import annotations
import io, os, re, json, sys

ENGINE_PATH = os.path.join(os.path.dirname(__file__), "..", "backtest", "engine.py")
ENGINE_PATH = os.path.normpath(ENGINE_PATH)

def _read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def _write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)

def ensure_import(code: str) -> str:
    if "from trend4p.utils.oflow import combine_of" not in code:
        code = re.sub(r"^(import.*|from .* import .*)", r"\1\nfrom trend4p.utils.oflow import combine_of", code, count=1, flags=re.M)
        if "from trend4p.utils.oflow import combine_of" not in code:
            code = "from trend4p.utils.oflow import combine_of\n" + code
    return code

def inject_helpers(code: str) -> str:
    if "def _quantile_thr(" not in code:
        code += """

def _quantile_thr(p_cal, target):
    import numpy as np, pandas as pd
    p = np.asarray(p_cal, dtype=float).reshape(-1)
    q = 1.0 - float(max(0.0, min(1.0, target)))
    thr = float(np.nanquantile(p, q))
    return thr

def _solve_thr_by_session(p_cal, sessions, target_map):
    import numpy as np, pandas as pd
    # sessions: array-like str labels aligned to p_cal
    uniq = pd.Series(sessions).astype(str).fillna("UNK").values
    thr_map = {}
    for s in pd.unique(uniq):
        idx = (uniq == s)
        if not idx.any():
            continue
        target = float(target_map.get(s, 0.05))
        p = np.asarray(p_cal, dtype=float)[idx]
        lo, hi = 0.0, 1.0
        for _ in range(24):  # binary search
            mid = (lo + hi) / 2.0
            cov = float((p >= mid).mean())
            if cov > target: lo = mid
            else: hi = mid
        thr_map[s] = (lo + hi) / 2.0
    return thr_map

"""
    return code

def replace_of_shift(code: str) -> str:
    # Replace first of_shift assignment with combine_of(X)
    code = re.sub(r"^([ \t]*)of_shift\s*=.*$", r"\1of_shift = combine_of(X)", code, count=1, flags=re.M)
    # Ensure logit_core exists with of_shift usage; if not, do nothing further.
    return code

def ensure_debug_dump(code: str) -> str:
    if "gating_debug.json" in code:
        return code
    # Append at end: a function to dump debug
    code += """

def _dump_gating_debug(out_dir, info: dict):
    import os, json
    os.makedirs(out_dir, exist_ok=True)
    p = os.path.join(out_dir, "gating_debug.json")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(info, f, ensure_ascii=False, indent=2)
"""
    return code

def patch(code: str) -> str:
    code = ensure_import(code)
    code = inject_helpers(code)
    code = replace_of_shift(code)
    code = ensure_debug_dump(code)
    # best-effort replacement for hard floor filters: turn them into clamp
    code = code.replace("if p_cal < prob_floor: continue", "p_cal = max(p_cal, prob_floor)  # clamp, do not skip")
    return code

def main():
    if not os.path.exists(ENGINE_PATH):
        print(f"[ERROR] engine.py not found: {ENGINE_PATH}", file=sys.stderr)
        sys.exit(2)
    code = _read(ENGINE_PATH)
    new = patch(code)
    if new != code:
        _write(ENGINE_PATH, new)
        print("[OK] Patched engine.py for 1.0.6B")
    else:
        print("[OK] engine.py already appears patched")
    return 0

if __name__ == "__main__":
    sys.exit(main())

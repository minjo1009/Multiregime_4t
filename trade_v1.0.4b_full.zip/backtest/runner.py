
import os, json, numpy as np, pandas as pd, yaml
from trend4p.data.feeds import load_kline_csv, label_future_return, add_session_cols
from trend4p.data.feature_basic import add_basic_features
from trend4p.feature_orderflow import compute_orderflow_features
from trend4p.regime_posterior import RegimePosterior, heuristic_prelabel
from trend4p.s1_dir_head import S1DirHeadMoE
from trend4p.s2_quantile_head import S2QuantileHead, quantiles_to_mu_sigma_es
from trend4p.sizing import fractional_kelly, vol_targeting

def load_cfg(path):
    with open(path,'r',encoding='utf-8') as f: return yaml.safe_load(f)

def run_backtest(data_path, cfg_path, out_dir):
    cfg=load_cfg(cfg_path)
    np.random.seed(cfg.get('seed',42))
    H=int(cfg['horizon_bars'])

    df=load_kline_csv(data_path)
    df=add_session_cols(df); df=add_basic_features(df)
    df=compute_orderflow_features(df, vpin_vol_k=cfg['vpin_bucket_mult'], vpin_m=cfg['vpin_m'], roll_lambda=cfg['lambda_roll'])
    df['y_ret']=label_future_return(df,H); df['y01']=(df['y_ret']>0).astype(int)

    slow=['mom_15','rv_60','VPIN','lambda_kyle','ATS']
    pre=heuristic_prelabel(df[slow]); rp=RegimePosterior().fit(df[slow].fillna(0), pre); r_post=rp.predict_proba(df[slow].fillna(0))

    feat_cols=[c for c in df.columns if c.startswith('mom_') or c.startswith('rv_')] + ['DR','CVD_slope','VPIN','lambda_kyle','OFI_proxy','ATS','sess_ASIA','sess_EU','sess_US']
    X_all=df[feat_cols].fillna(0)

    idx_tr=np.arange(len(df))[::int(cfg.get('train_stride',5))]
    s1=S1DirHeadMoE().fit(X_all.iloc[idx_tr], df['y01'].iloc[idx_tr], r_post[idx_tr])
    df['p_long']=s1.predict_proba(X_all, r_post)

    s2=S2QuantileHead().fit(X_all.iloc[idx_tr], df['y_ret'].fillna(0).iloc[idx_tr], r_post[idx_tr])
    qdf=s2.predict_quantiles(X_all)
    mu,sigma,es=quantiles_to_mu_sigma_es(qdf, alpha=cfg['es_alpha'])
    df['mu']=mu; df['sigma']=sigma; df['es']=es

    cost_bps=cfg['fee_bps']+cfg['slip_bps_base']
    df['cost_bps']=cost_bps
    mu_net=df['mu']-cost_bps*1e-4

    # Coverage-aligned gating + S1 min prob cutoff
    lambda_tail=float(cfg.get('lambda_tail', 0.7))
    score_series = (mu_net - lambda_tail*df['es'].abs())
    tmin=float(cfg.get('coverage_target_min', 0.03)); tmax=float(cfg.get('coverage_target_max', 0.08)); tmid=(tmin+tmax)/2.0
    thr = float(score_series.quantile(1.0 - tmid))
    a=10.0
    score = score_series.values
    gate = 1.0/(1.0+np.exp(-a*(score - thr)))
    p_cut=float(cfg.get('s1_min_prob', 0.52))
    gate = gate * (df['p_long'] >= p_cut).astype(float)
    df['score']=score_series.values; df['gate']=gate

    size=fractional_kelly(df['mu'].values, np.maximum(1e-6,df['sigma'].values), frac=cfg['kelly_fraction'])
    df['size']=vol_targeting(size, np.maximum(1e-6,df['sigma'].values), target_vol=0.02)

    from trend4p.executor.sim_exec import simulate_trades
    preds,tlog = simulate_trades(df,H,cost_bps)

    if 'cost_bps' not in preds.columns: preds['cost_bps']=cost_bps
    micro = preds.reindex(columns=['ts','VPIN','lambda_kyle','ATS']).copy()
    costs = preds.reindex(columns=['ts','cost_bps']).copy()

    by_bucket=preds.groupby('session').agg(trades=('gate', lambda s:(s>0.5).sum()), hit=('ret_fut', lambda r: float((r[preds.loc[r.index,'gate']>0.5]>0).mean()) if (preds.loc[r.index,'gate']>0.5).sum()>0 else 0), pnl_net=('pnl','sum')).reset_index()

    meta={'algo_version':'trade_v1.0.4b','cfg':cfg,'data_span':f"{str(preds['ts'].iloc[0])}~{str(preds['ts'].iloc[-1])}",'horizon_bars':H}
    os.makedirs(out_dir, exist_ok=True)
    cov_est=float((preds['gate']>0.5).mean())
    with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as fdbg:
        import json; json.dump({'tmin':tmin,'tmax':tmax,'tmid':tmid,'thr':thr,'cov_est':cov_est,'p_cut':p_cut}, fdbg, indent=2)

    preds.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False); tlog.to_csv(os.path.join(out_dir,'trades.csv'), index=False)
    return preds, tlog, micro, costs, by_bucket, meta


from sklearn.calibration import CalibratedClassifierCV as C
from sklearn.linear_model import LogisticRegression as L
try:
    C(estimator=L()); print('OK')
except TypeError:
    C(base_estimator=L()); print('OK legacy')

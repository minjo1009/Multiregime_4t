
# trade_v1.0.4b (full)
- Strategy v1 multi-regime MoE with S1 calibrated head + S2 quantile head.
- This is the **stability patch** of 1.0.4a: sklearn 1.4/1.5 compatible; fingerprint aligned; preflight tooling.
- See `CHANGELOG.md` for detailed changes.

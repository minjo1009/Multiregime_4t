
import numpy as np, pandas as pd
def _vpin_vectorized(vol: pd.Series, VD: pd.Series, Vb: float, m: int, index) -> pd.Series:
    if Vb <= 0 or len(vol) == 0: return pd.Series(np.nan, index=index, name="VPIN")
    cum_vol = vol.cumsum().values
    bucket_idx = np.floor(cum_vol / Vb).astype(np.int64)
    edges = np.nonzero(np.diff(bucket_idx) > 0)[0]
    if edges.size == 0: return pd.Series(np.nan, index=index, name="VPIN")
    cum_VD = VD.cumsum().values
    starts = np.concatenate(([0], edges[:-1] + 1))
    ends   = edges
    sum_VD = cum_VD[ends] - np.where(starts > 0, cum_VD[starts - 1], 0.0)
    imb_bucket = np.abs(sum_VD) / Vb
    if len(imb_bucket) < m:
        v_at_edges = np.full_like(imb_bucket, np.nan, dtype=float)
    else:
        kernel = np.ones(m, dtype=float) / m
        mv = np.convolve(imb_bucket, kernel, mode="valid")
        v_at_edges = np.concatenate([np.full(m-1, np.nan), mv])
    vpin = np.full(len(index), np.nan, dtype=float)
    vpin[ends] = v_at_edges
    return pd.Series(vpin, index=index, name="VPIN").ffill()
def compute_orderflow_features(df: pd.DataFrame, vpin_vol_k: int = 30, vpin_m: int = 50, cvd_reset: str = 'D', roll_lambda: int = 240) -> pd.DataFrame:
    out = df.copy()
    vol   = out['volume'].astype('float32')
    tbav  = out['taker_buy_base_asset_volume'].astype('float32')
    close = out['close'].astype('float32')
    out['BV'] = tbav
    out['SV'] = vol - tbav
    out['VD'] = 2.0 * tbav - vol
    out['DR'] = out['VD'] / vol.replace(0, 1e-9)
    out['ATS'] = vol / out['number_of_trades'].replace(0, 1.0)
    if cvd_reset == 'D': out['CVD'] = out.groupby(pd.to_datetime(out['ts']).dt.date)['VD'].cumsum()
    else: out['CVD'] = out['VD'].cumsum()
    out['CVD_slope'] = out['CVD'].diff()
    Vb = float(np.median(vol.values) * max(1, vpin_vol_k))
    out['VPIN'] = _vpin_vectorized(vol, out['VD'], Vb, vpin_m, out.index)
    ret = np.log(close).diff()
    Q = out['VD'].astype('float32')
    cov = (ret*Q).rolling(roll_lambda).mean() - ret.rolling(roll_lambda).mean()*Q.rolling(roll_lambda).mean()
    var = (Q**2).rolling(roll_lambda).mean() - (Q.rolling(roll_lambda).mean()**2)
    out['lambda_kyle'] = cov / var.replace(0, np.nan)
    rv = (ret.rolling(60).std()*np.sqrt(60)).replace(0, np.nan)
    out['OFI_proxy'] = out['DR'] * (vol / rv)
    return out

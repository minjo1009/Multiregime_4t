
import numpy as np, pandas as pd
def simulate_trades(df, H, cost_bps=3.0):
    df=df.copy(); df['entry_idx']=df.index+1; df['exit_idx']=df.index+H+1
    valid=df['exit_idx']<len(df); df.loc[~valid,'gate']=0.0
    fut_ret=(np.log(df['close'].shift(-H-1))-np.log(df['close'].shift(-1)))
    df['ret_fut']=fut_ret; cost=cost_bps*1e-4
    df['pnl']=df['size']*df['gate']*(df['ret_fut']-cost)
    tlog=df.loc[df['gate']>0.5, ['ts','gate','size','ret_fut','pnl']].copy()
    return df, tlog

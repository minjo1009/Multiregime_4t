
## 1.0.4b
- Fix: `trend4p/s1_dir_head.py` try/except indentation; sklearn 1.4/1.5 ctor compatibility.
- Align fingerprint comment to "S1 min prob cutoff".
- Add tools: `tools/smoke_sklearn.py`, `tools/preflight_csv.py`, `tools/verify_env.py`.
- Add tests: `tests/test_imports.py`, `tests/test_cal_cv.py`.
- No functional logic changes to S1/S2/gating/sizing.

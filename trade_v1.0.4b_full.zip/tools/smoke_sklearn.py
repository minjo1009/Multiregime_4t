
from sklearn.calibration import CalibratedClassifierCV as C
from sklearn.linear_model import LogisticRegression as L
try:
    C(estimator=L()); print('OK: estimator (>=1.5)')
except TypeError:
    C(base_estimator=L()); print('OK: base_estimator (<=1.4)')

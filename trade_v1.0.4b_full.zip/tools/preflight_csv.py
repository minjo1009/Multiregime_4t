
import sys, pandas as pd
csv=sys.argv[1]
df=pd.read_csv(csv, nrows=2)
need={'open_time','open','high','low','close','volume','number_of_trades'}
miss=need-set(df.columns)
assert not miss, f'Missing columns: {miss}'
hints={'taker_buy_base_asset_volume','taker_buy_quote_asset_volume'}
assert hints & set(df.columns), 'Need taker_buy_* volume columns'
print('CSV OK')

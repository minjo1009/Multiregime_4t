# 버전업 매뉴얼 (고정본)
- 계획→패치→셀프체크→CI가드→출력검증 순서.
- 인터페이스 보존: run_4u.py --data_path, 산출물=_out_4u/*.
- Calibrator 계약: fit/transform/predict/predict_proba 유지.
- 세션별 임계 자동튜닝(coverage 3~8%), 최소커버리지 폴백.
- 중복 ZIP 금지, 표준모듈 섀도잉 금지, CSV 절대경로 확정.
- 실패 기준: coverage==0 또는 테스트 실패 시 즉시 실패/롤백.

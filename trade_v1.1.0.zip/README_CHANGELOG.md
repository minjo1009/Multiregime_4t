# v1.1.0
- Session-wise coverage band control (3–8%) with auto retune + minimal coverage fallback
- Gating diagnostics & guard (run/gating_debug.json, coverage guard)
- Artifact contract & self-check scripts
- Calibrator contract preserved (predict/predict_proba)
- Reproducible packaging & stdlib shadow guard

# v1.0.9
- Implement Calibrator predict/predict_proba (engine API compatibility)
- Add tests and self-check
- No interface changes; artifacts path unchanged

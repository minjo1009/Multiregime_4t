import os, json
def save_reports(out_dir, preds_test, trades, extras):
    os.makedirs(out_dir, exist_ok=True)
    preds_test.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False)
    trades.to_csv(os.path.join(out_dir,'trades.csv'), index=False)
    with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as fdbg:
        json.dump(extras.get('gdbg',{}), fdbg, indent=2, ensure_ascii=False)
    run_dir=os.path.join(out_dir,'run'); os.makedirs(run_dir, exist_ok=True)
    with open(os.path.join(run_dir,'gating_debug.json'),'w',encoding='utf-8') as frun:
        json.dump(extras.get('gdbg',{}), frun, indent=2, ensure_ascii=False)
    with open(os.path.join(out_dir,'summary.json'),'w',encoding='utf-8') as f:
        json.dump(extras.get('summary',{}), f, indent=2, ensure_ascii=False)

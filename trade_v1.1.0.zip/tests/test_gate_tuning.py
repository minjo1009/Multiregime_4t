import numpy as np
from backtest.engine import _solve_thr_by_session, _sigmoid

def test_solve_thr_by_session_hits_band():
    rng = np.random.default_rng(123)
    N=10000
    sess = np.array(["ASIA"]*(N//2)+["US"]*(N-N//2))
    score = rng.normal(size=N)
    test = np.ones(N, dtype=bool)
    tgt = {"ASIA":0.05, "EU":0.05, "US":0.05}
    thr = _solve_thr_by_session(score, sess, tgt, test)
    adj = score.copy()
    for s,th in thr.items():
        m = (sess==s) & test
        adj[m] = adj[m] - th
    gate = _sigmoid(adj)
    for s in ["ASIA","US"]:
        m = (sess==s) & test
        cov = float((gate[m]>0.5).mean())
        assert 0.03 <= cov <= 0.08, cov

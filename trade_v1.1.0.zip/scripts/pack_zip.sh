#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"; OUT="${2:-trade_v1.1.0.zip}"
TMP="$(mktemp -d)"
rsync -a --delete --exclude '.git' --exclude '__pycache__' "$ROOT"/ "$TMP"/
( cd "$TMP" && zip -r -X "../$OUT" . )
echo "[pack] wrote $OUT"
echo "[pack] checking duplicates..."
unzip -Z1 "$OUT" | sort | uniq -d && { echo "[pack] DUP found. abort"; exit 1; } || echo "[pack] no duplicates"

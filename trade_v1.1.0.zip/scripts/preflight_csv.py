#!/usr/bin/env python3
import sys, json, os, glob, pandas as pd, pathlib
root = sys.argv[1] if len(sys.argv)>1 else "tmp/data"
csv_glob = os.environ.get("CSV_GLOB","**/*.csv")
matches = sorted(glob.glob(os.path.join(root, csv_glob), recursive=True))
if not matches:
    matches = sorted(glob.glob(os.path.join(root, "**/*.csv"), recursive=True))
out = {"glob": csv_glob, "found": matches[:10]}
if not matches:
    print(json.dumps(out, ensure_ascii=True)); sys.exit(0)
path = pathlib.Path(matches[0]).resolve().as_posix()
try:
    pd.read_csv(path, nrows=2)
    out["sample_path"]=path
except Exception as e:
    out["error"]=str(e); out["sample_path"]=path
print(json.dumps(out, ensure_ascii=True))
with open("CSV_PATH.txt","w", encoding="utf-8") as f: f.write(path)

#!/usr/bin/env python3
import sys, re, pathlib
root = pathlib.Path("tmp/trade/trend4p")
f = root / "calibration.py"
if not f.exists():
    sys.exit(0)
code = f.read_text(encoding="utf-8")
if re.search(r'\bclass\s+Calibrator\b', code) and ("predict(" in code) and ("predict_proba(" in code):
    print("Calibrator already provides predict/predict_proba"); sys.exit(0)
append = r'''
# --- Injected Calibrator contract v1.1.0 ---
try:
    import numpy as _np
    from sklearn.isotonic import IsotonicRegression as _Iso
except Exception:
    import numpy as _np
    class _Iso:
        def __init__(self,*a,**k): pass
        def fit(self,*a,**k): return self
        def transform(self, x): return _np.asarray(x,float).ravel()
class Calibrator:
    def __init__(self, method="isotonic", by_session=False, **kwargs):
        self.method = (method or "off").lower(); self.by_session=bool(by_session); self._m=None
    def _prep(self, y, p):
        y=_np.asarray(y,float).ravel(); p=_np.asarray(p,float).ravel()
        m=_np.isfinite(y)&_np.isfinite(p); return y[m],p[m]
    def fit(self, y=None, p=None, **kw):
        if y is None and p is None:
            p = kw.get("proba") or kw.get("p"); y = kw.get("target") or kw.get("y")
        if p is None or y is None:
            self._m=None; return self
        y,p=self._prep(y,p)
        if y.size<3:
            self._m=None; return self
        self._m = _Iso(out_of_bounds="clip").fit(p,y) if self.method in ("isotonic","iso") else None
        return self
    def transform(self, p):
        p=_np.asarray(p,float).ravel()
        try: out=self._m.transform(p) if self._m is not None else p
        except Exception: out=p
        return _np.clip(_np.asarray(out,float).ravel(),1e-6,1-1e-6)
    def predict(self, p): return self.transform(p)
    def predict_proba(self, p): return self.transform(p)
    def __call__(self, p): return self.transform(p)
    def fit_transform(self, y, p, **kw): return self.fit(y=y,p=p,**kw).transform(p)
# --- End inject ---
'''
f.write_text(code + "\n" + append, encoding="utf-8")
print("Injected Calibrator contract")

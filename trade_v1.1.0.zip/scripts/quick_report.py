#!/usr/bin/env python3
import json, pandas as pd
from pathlib import Path
OUT = Path("_out_4u")
preds_p = OUT/"preds_test.csv"
trades_p = OUT/"trades.csv"
summary_p = OUT/"summary.json"
report_p = OUT/"quick_report.json"
res = {}
if summary_p.exists():
    try:
        res["summary"] = json.loads(summary_p.read_text(encoding="utf-8"))
    except Exception:
        res["summary"] = {}
if trades_p.exists():
    try:
        tr = pd.read_csv(trades_p)
        n = len(tr)
        res["trades"] = {"n": int(n)}
        for c in ["pnl","P&L","return","ret","roi"]:
            if c in tr.columns:
                s = tr[c]
                wins = int((s>0).sum())
                res["trades"]["wins"] = wins
                res["trades"]["win_rate"] = (wins / max(n,1)) if n>0 else 0.0
                break
    except Exception as e:
        res["trades_error"] = str(e)
report_p.write_text(json.dumps(res, indent=2, ensure_ascii=False), encoding="utf-8")
print("[quick_report] wrote", report_p)


import argparse, os, json
from backtest.runner import run_backtest
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--config", default="conf/config.yml")
    ap.add_argument("--out_dir", default="_out_4u/run")
    args=ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    preds, trades, micro, costs, by_bucket, meta = run_backtest(args.data_path, args.config, args.out_dir)
    with open(os.path.join(args.out_dir,"summary.json"),"w",encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)
    preds.to_csv(os.path.join(args.out_dir,"preds_test.csv"), index=False)
    trades.to_csv(os.path.join(args.out_dir,"trades.csv"), index=False)
    print("Done. Wrote summary.json, preds_test.csv, trades.csv")
if __name__=="__main__": main()

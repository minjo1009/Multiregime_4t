import os, json
import numpy as np
import pandas as pd
import yaml
from trend4p.data.feeds import load_kline_csv
from trend4p.calibration import Calibrator
from trend4p.signals.s1 import train_predict
from trend4p.utils.oflow import combine_of
from trend4p.utils.gamma import resolve_gamma

def _safe_of_shift(df, n):
    try:
        tmp = combine_of(df)
    except Exception:
        tmp = None
    if tmp is None:
        return np.zeros(n, dtype=float)
    arr = np.asarray(tmp)
    # Reduce to 1D length-n
    if arr.ndim == 0:
        return np.zeros(n, dtype=float)
    if arr.ndim > 1:
        # prefer averaging across last axis when rows match
        if arr.shape[0] == n:
            arr = np.nanmean(arr, axis=1)
        elif arr.shape[-1] == n:
            arr = np.nanmean(arr, axis=0)
        else:
            return np.zeros(n, dtype=float)
    arr = arr.reshape(-1)
    if len(arr) != n:
        return np.zeros(n, dtype=float)
    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
    return arr

def load_cfg(path):
    with open(path,'r',encoding='utf-8') as f:
        return yaml.safe_load(f)

def sigmoid(x): return 1.0/(1.0+np.exp(-x))

def reliability(y_true, p, bins=10):
    df = pd.DataFrame({'y':np.asarray(y_true,float), 'p':np.asarray(p,float)}).dropna()
    if len(df)==0: return 0.0, 1.0, 0.0
    df['bin'] = np.floor(df['p']*bins).clip(0,bins-1)
    grp = df.groupby('bin')
    px = grp['p'].mean(); py = grp['y'].mean()
    x = px.values.reshape(-1,1); y = py.values.reshape(-1)
    if len(x)>=2:
        A = np.c_[x, np.ones_like(x)]
        coef, *_ = np.linalg.lstsq(A, y, rcond=None)
        a,b = float(coef[0]), float(coef[1])
    else:
        a,b = 1.0,0.0
    ece = float((grp.size()/len(df) * np.abs(py - px)).sum())
    return ece, a, b

class BacktestEngine:
    def __init__(self, cfg_path):
        self.cfg = load_cfg(cfg_path)

    def run(self, data_path, out_dir):
        os.makedirs(out_dir, exist_ok=True)
        cfg = self.cfg
        # ---- load ----
        df = load_kline_csv(data_path)
        H = int(cfg.get('horizon_bars',15))

        # S1 raw prob using existing signal pipeline
        p_raw, mdl, X, y, fwd = train_predict(df, H=H)
        df['y01']=y.values
        df['fwd']=fwd.values

        # Calibration
        cal_cfg = cfg.get('calibration', {'method':'off','by':'global'})
        method = cal_cfg.get('method','off'); by = cal_cfg.get('by','global')
        p_cal = np.asarray(p_raw, float)
        if method!='off':
            if by=='session':
                p_cal[:] = np.nan
                for s, idx in df.groupby('session').groups.items():
                    idx = np.array(sorted(idx))
                    tr = idx[idx < int(len(df)*cfg.get('report',{}).get('cut_ratio',0.7))]
                    if len(tr)<100: p_cal[idx]=p_raw[idx]; continue
                    cal=Calibrator(method).fit(p_raw[tr], y.iloc[tr].values)
                    p_cal[idx]=cal.predict(p_raw[idx])
            else:
                cut=int(len(df)*cfg.get('report',{}).get('cut_ratio',0.7))
                cal=Calibrator(method).fit(p_raw[:cut], y.iloc[:cut].values)
                p_cal=cal.predict(p_raw)

        # OF composite and gamma
        of_arr = _safe_of_shift(df, len(df))
        df['OF_shift'] = pd.Series(of_arr, index=df.index).astype(float)

        # gamma: prefer our simple gamma_by; fall back to resolve_gamma
        gmap = cfg.get('gamma_by',{})
        if isinstance(gmap, dict) and len(gmap)>0:
            gamma = df['session'].map(gmap).fillna(1.0).astype(float).values
        else:
            gamma = resolve_gamma(df, {'of_weight':{'gamma_by_session':gmap}})

        # thresholds per session via bisection on train split
        cut = int(len(df)*cfg.get('report',{}).get('cut_ratio',0.7))
        target = (cfg.get('coverage_target_min',0.03)+cfg.get('coverage_target_max',0.08))/2.0
        thr_by_session = {}
        for s, idx in df.groupby('session').groups.items():
            idx = np.array(sorted(idx))
            tr = idx[idx<cut]
            if len(tr)==0: thr_by_session[s]=0.5; continue
            lo,hi=0.05,0.95
            for _ in range(22):
                mid=(lo+hi)/2
                cov=float((p_cal[tr]>mid).mean())
                if cov>target: lo=mid
                else: hi=mid
            thr_by_session[s]=(lo+hi)/2

        beta=float(cfg.get('s1_soft_power',1.2)); temp=float(cfg.get('gate_logit_temp',10.0))
        thr = df['session'].map(thr_by_session).fillna(0.5).astype(float).values
        s = np.asarray(p_cal,float); of = df['OF_shift'].to_numpy(float)

        gate_long  = sigmoid(temp*(s - thr) + gamma*of)**beta
        gate_short = sigmoid(temp*((1.0 - s) - thr) - gamma*of)**beta
        dir_sign = np.where(gate_long>=gate_short, 1, -1)
        gate = np.where(gate_long>=gate_short, gate_long, gate_short)

        df['p_raw']=p_raw; df['p_cal']=p_cal; df['gate']=gate; df['dir']=dir_sign

        # PnL (simple)
        fee=float(cfg.get('fee_bps',2.0))/10000.0; slip=float(cfg.get('slip_bps_base',1.0))/10000.0
        eff = df['fwd'].to_numpy(float)*dir_sign - (fee+slip)
        enter = gate>0.5
        pnl = np.where(enter, eff, 0.0)

        # Outputs
        test_mask = np.arange(len(df))>=cut
        preds = df.loc[test_mask, ['ts','session','p_raw','p_cal','gate','dir']].copy()
        preds.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False)

        rows=[]
        for i in np.where(enter & test_mask)[0]:
            rows.append({'ts':str(df['ts'].iloc[i]),'session':df['session'].iloc[i],'dir':int(dir_sign[i]),
                         'p_cal':float(p_cal[i]),'gate':float(gate[i]),'ret_fwd':float(df['fwd'].iloc[i]),
                         'pnl':float(pnl[i])})
        trades=pd.DataFrame(rows)
        trades.to_csv(os.path.join(out_dir,'trades.csv'), index=False)

        # metrics
        wins=pnl[test_mask][pnl[test_mask]>0]; losses=-pnl[test_mask][pnl[test_mask]<0]
        hit=float((pnl[test_mask]>0).mean()) if (enter & test_mask).any() else 0.0
        pf=float(wins.sum()/max(losses.sum(),1e-9)) if len(wins) else 0.0
        avgw=float(wins.mean()) if len(wins) else 0.0; avgl=float(losses.mean()) if len(losses) else 0.0
        ece, slope, intercept = reliability(y.iloc[cut:].values, p_cal[cut:])
        cov_all = float((gate[cut:]>0.5).mean())
        cov_by_session = {}
        for s, idx in df.loc[cut:].groupby('session').groups.items():
            cov_by_session[s]=float((gate[idx]>0.5).mean())

        with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as f:
            json.dump({'thr_by_session':{k:float(v) for k,v in thr_by_session.items()},
                       'cov_overall':cov_all,'cov_by_session':cov_by_session,
                       'beta':float(beta),'temp':float(temp)}, f, ensure_ascii=False, indent=2)

        with open(os.path.join(out_dir,'summary.json'),'w',encoding='utf-8') as f:
            json.dump({'n':int(len(df)),'split_index':int(cut),
                       'coverage_overall':cov_all,'coverage_by_session':cov_by_session,
                       'hit_rate':hit,'profit_factor':pf,'avg_win':avgw,'avg_loss':avgl,
                       'ece':float(ece),'rel_slope':float(slope),'rel_intercept':float(intercept)},
                      f, ensure_ascii=False, indent=2)

        return preds, trades, {'n':int(len(df))}

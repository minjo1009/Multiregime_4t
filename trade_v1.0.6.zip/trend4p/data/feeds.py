
import pandas as pd, numpy as np
def load_kline_csv(path):
    df=pd.read_csv(path)
    rename = {c:c.lower() for c in df.columns}
    df.rename(columns=rename, inplace=True)
    for c in ['open_time','timestamp','time']:
        if c in df.columns:
            t = pd.to_datetime(df[c], unit='ms', errors='ignore')
            df['ts']=pd.to_datetime(t, errors='coerce'); break
    if 'ts' not in df.columns:
        df['ts']=pd.to_datetime(df.index, unit='s', errors='coerce')
    for col in ['open','high','low','close','volume']:
        if col not in df.columns: df[col]=np.nan
    if 'number_of_trades' not in df.columns: df['number_of_trades']=0
    if 'taker_buy_base_asset_volume' not in df.columns:
        if 'taker_buy_quote_asset_volume' in df.columns and 'close' in df.columns:
            df['taker_buy_base_asset_volume']=df['taker_buy_quote_asset_volume']/df['close'].replace(0,np.nan)
        else:
            df['taker_buy_base_asset_volume']=np.nan
    df.sort_values('ts', inplace=True); df.reset_index(drop=True, inplace=True)
    hr = df['ts'].dt.hour.fillna(0).astype(int)
    df['session']=np.select([(hr>=0)&(hr<8),(hr>=8)&(hr<16)], ['ASIA','EU'], default='US')
    return df

import numpy as np
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

class Calibrator:
    def __init__(self, method: str='isotonic'):
        self.method = (method or 'off').lower()
        self.model = None

    def _clean_xy(self, p, y):
        p = np.asarray(p, float).reshape(-1)
        y = np.asarray(y, float).reshape(-1)
        m = np.isfinite(p) & np.isfinite(y)
        p, y = p[m], y[m]
        # isotonic은 x 단조 증가 가정은 없지만, 극단치/중복 대비 clip
        p = np.clip(p, 1e-6, 1-1e-6)
        return p, y

    def fit(self, prob, y_true):
        p, y = self._clean_xy(prob, y_true)
        if len(p) < 50 or len(np.unique(p)) < 2:
            # 데이터가 부실하면 보정하지 않음(항등)
            self.model = None
            self.method = 'off'
            return self
        if self.method == 'isotonic':
            self.model = IsotonicRegression(out_of_bounds="clip").fit(p, y)
        elif self.method == 'platt':
            self.model = LogisticRegression(max_iter=1000).fit(p.reshape(-1,1), y.astype(int))
        else:
            self.model = None
        return self

    def predict(self, prob):
        p = np.asarray(prob, float).reshape(-1)
        p = np.clip(p, 1e-6, 1-1e-6)
        if self.model is None or self.method == 'off':
            return p
        if self.method == 'isotonic':
            return np.clip(self.model.predict(p), 1e-6, 1-1e-6)
        elif self.method == 'platt':
            return np.clip(self.model.predict_proba(p.reshape(-1,1))[:,1], 1e-6, 1-1e-6)
        return p

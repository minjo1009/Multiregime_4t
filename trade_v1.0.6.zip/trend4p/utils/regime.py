
import numpy as np, pandas as pd
def tag_regime(df, H=15):
    px=df['close'].astype(float).fillna(method='ffill')
    mom=px.pct_change(H).fillna(0)
    vol=px.pct_change().rolling(60).std().fillna(0)
    up=(mom>vol*H*0.05); down=(mom<-vol*H*0.05)
    regime=np.where(up, 'TREND_UP', np.where(down,'TREND_DOWN','RANGE'))
    return pd.Series(regime, index=df.index, name='regime')

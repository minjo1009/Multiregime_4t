
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
def _z(x):
    x=np.asarray(x,dtype=float); mu=np.nanmean(x); sd=np.nanstd(x) or 1.0; return (x-mu)/sd
def features(df, H=15):
    px=df['close'].astype(float).fillna(method='ffill')
    ret1=px.pct_change().fillna(0)
    momH=px.pct_change(H).fillna(0)
    rv60=ret1.rolling(60).std().fillna(method='bfill').fillna(0)
    v=df['volume'].astype(float).fillna(0)
    tb=df.get('taker_buy_base_asset_volume', pd.Series(index=df.index, data=np.nan)).astype(float)
    of_buy=(tb/(v.replace(0,np.nan))).fillna(0).clip(0,1)
    vpin=(v.rolling(50).apply(lambda x: np.nanmean(np.abs(np.diff(x))), raw=True)).fillna(0)
    lam_kyle=(px.pct_change().rolling(240).std()/(v.rolling(240).std()+1e-9)).fillna(0)
    X=pd.DataFrame({'ret1':ret1,'momH':momH,'rv60':rv60,'of_buy':of_buy,'vpin':_z(vpin),'lambda_kyle':_z(lam_kyle)})
    return X.replace([np.inf,-np.inf],0).fillna(0)
def label(df, H=15):
    px = df['close'].astype(float).fillna(method='ffill')
    fwd = px.shift(-H)/px - 1.0
    return (fwd>0).astype(int).fillna(0).astype(int), fwd.fillna(0).astype(float)
def train_predict(df, H=15):
    X=features(df,H); y, fwd=label(df,H); n=len(df); cut=int(n*0.7)
    mdl=LogisticRegression(max_iter=500).fit(X.iloc[:cut], y.iloc[:cut])
    p=mdl.predict_proba(X)[:,1]
    return p, mdl, X, y, fwd

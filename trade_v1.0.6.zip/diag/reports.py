
import numpy as np, pandas as pd
from scipy.stats import spearmanr
def reliability_stats(p, y):
    p=np.clip(np.asarray(p),1e-6,1-1e-6); y=np.asarray(y).astype(float)
    ece=np.mean(np.abs(p - y))
    slope = float(np.cov(p,y)[0,1]/(np.var(p)+1e-9))
    intercept = float(y.mean() - slope*p.mean())
    return {"ece":float(ece), "rel_slope":float(slope), "rel_intercept":float(intercept)}
def profit_stats(trades_df):
    if trades_df is None or len(trades_df)==0:
        return {"hit_rate":0.0,"profit_factor":0.0,"avg_win":0.0,"avg_loss":0.0}
    pl = trades_df['pnl'].to_numpy()
    wins = pl[pl>0]; losses = -pl[pl<0]
    hit = float((pl>0).mean()) if len(pl)>0 else 0.0
    pf = float(wins.sum()/losses.sum()) if losses.sum()>0 else float('inf')
    avgw = float(wins.mean()) if len(wins)>0 else 0.0
    avgl = float(losses.mean()) if len(losses)>0 else 0.0
    return {"hit_rate":hit,"profit_factor":pf,"avg_win":avgw,"avg_loss":avgl}
def rank_ic_at_topk(score, fwd_ret, topk_pct=10):
    s = np.asarray(score, float); r = np.asarray(fwd_ret, float)
    if len(s)==0 or len(r)==0: return {"topk_pct": topk_pct, "rank_ic": 0.0}
    k = max(1, int(len(s)*topk_pct/100.0))
    idx = np.argsort(-s)[:k]
    if len(idx)<3: return {"topk_pct": topk_pct, "rank_ic": 0.0}
    rho, _ = spearmanr(s[idx], r[idx])
    if np.isnan(rho): rho=0.0
    return {"topk_pct": topk_pct, "rank_ic": float(rho)}

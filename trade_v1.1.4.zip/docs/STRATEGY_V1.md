# Strategy v1 (Multiregime, Soft Gating)
- **Soft gating**: `gate = σ(temp*(p_cal-0.5) + γ·OF_shift)^β` (no hard close).
- **Coverage targets** by session with **bisection** fallback.
- **Order flow** (VPIN/ATS/λ_kyle) used **only as weight**.
- **Calibration**: `isotonic | platt | off`, selectable per session.
- **Reports**: `summary.json`, `gating_debug.json`, `preds_test.csv`, `trades.csv`.

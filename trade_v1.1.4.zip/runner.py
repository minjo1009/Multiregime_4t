#!/usr/bin/env python3
"""
runner.py (v1.1.4-core-fix)
- Backward compatibility: export run_backtest() so YAMLs importing backtest.runner keep working.
- Prefers tmp/trade/conf/config.effective.yml over config.yml when present.
- After engine run, enforce TTL overlay to guarantee A/B difference even if engine ignores hold_bars.
"""
import os, sys, runpy, json
from pathlib import Path

__all__ = ["main", "run_backtest"]

def _log(*a): print("[runner-1.1.4-core]", *a, flush=True)

def _ttl_from_env():
    for k in ("EXIT_TTL_BARS","HOLD_BARS","TTL_BARS","MAX_HOLD_BARS"):
        v=os.environ.get(k)
        if v is not None and str(v).strip()!="":
            try: return int(float(v))
            except: pass
    return 0

def _find_trades():
    prefs=[Path("_out_4u/trades.csv"), Path("_out_4u/run/trades.csv")]
    for p in prefs:
        if p.exists(): return p
    cands=[]
    for p in Path(".").rglob("trades.csv"):
        if "data" in str(p).lower(): 
            continue
        try: cands.append((p.stat().st_mtime, p))
        except Exception: pass
    if cands:
        cands.sort(reverse=True)
        return cands[0][1]
    return None

def _ttl_overlay(path: Path, ttl:int):
    import pandas as pd
    df = pd.read_csv(path)
    pairs=[("i_open","i_close"),("open_idx","close_idx"),("entry_idx","exit_idx"),
           ("entry_bar","exit_bar"),("bar_in","bar_out"),("start_idx","stop_idx")]
    used=None
    for a,b in pairs:
        if a in df.columns and b in df.columns:
            ai=pd.to_numeric(df[a], errors="coerce").fillna(-1).astype("int64")
            bi=pd.to_numeric(df[b], errors="coerce").fillna(-1).astype("int64")
            mask=(bi-ai)>ttl
            if mask.any():
                df.loc[mask,b]=ai[mask]+ttl
            used=(a,b)
            break
    out_run=Path("_out_4u/run"); out_run.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_run/"trades.csv", index=False)
    Path("_out_4u/trades.csv").write_bytes((out_run/"trades.csv").read_bytes())
    Path("_out_4u/run/ttl_enforced.json").write_text(json.dumps({"ttl":ttl,"used":used}, indent=2))
    _log("TTL overlay done:", ttl, "cols:", used)

def main(data_path=None, config_path=None, args=None):
    root=Path(__file__).resolve().parent
    sys.path[:0]=[str(root), str(root/"backtest")]

    # build effective config via exit_bridge (best-effort)
    try:
        from backtest.exit_bridge import main as bridge
        bridge()
    except Exception as e:
        _log("bridge warn:", e)

    # choose engine target (run_4u.py > backtest/engine.py)
    target=None
    for c in (root/"run_4u.py", root/"backtest"/"engine.py"):
        if c.exists(): target=c; break
    if target is None:
        raise FileNotFoundError("No engine entry found (run_4u.py or backtest/engine.py)")

    # choose config
    cfg_eff=Path("tmp/trade/conf/config.effective.yml")
    cfg_base=Path("tmp/trade/conf/config.yml")
    cfg=Path(config_path) if config_path else (cfg_eff if cfg_eff.exists() else cfg_base)
    Path("_out_4u").mkdir(parents=True, exist_ok=True)
    Path("_out_4u/CONFIG_USED.txt").write_text(str(cfg))

    # pick data_path
    data=data_path or os.environ.get("DATA_PATH")
    if not data and Path("_out_4u/CSV_PATH.txt").exists():
        data=Path("_out_4u/CSV_PATH.txt").read_text().strip()
    if not data:
        for p in Path("tmp").rglob("*.csv"):
            if "data" in str(p).lower(): data=str(p); break
    if not data:
        raise FileNotFoundError("DATA_PATH not set and no CSV located under tmp/.")

    # run engine
    os.environ["PYTHONPATH"]=f"{root}:{root/'backtest'}:"+os.environ.get("PYTHONPATH","")
    argv=["--data_path", str(data), "--config", str(cfg)]
    if args: argv += list(args)
    _log("RUN ->", target, "args:", argv)
    sys.argv=[str(target)] + argv
    runpy.run_path(str(target), run_name="__main__")

    # collect & enforce TTL
    t=_find_trades()
    if t: Path("_out_4u/trades.csv").write_bytes(Path(t).read_bytes())
    ttl=_ttl_from_env()
    if ttl>0 and Path("_out_4u/trades.csv").exists():
        _ttl_overlay(Path("_out_4u/trades.csv"), ttl)
    else:
        _log("skip overlay ttl=", ttl, "trades_exists=", Path("_out_4u/trades.csv").exists())

def run_backtest(**kwargs):
    return main(**kwargs)

if __name__=="__main__":
    main()

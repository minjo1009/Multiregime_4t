#!/usr/bin/env python3
"""
runner.py (v1.1.4-core-fix v4)
- Prefer backtest/engine.py over run_4u.py to avoid recursive run_backtest()
- Robust engine discovery across start/parent/grandparent
- Backward-compatible run_backtest(*pargs, **kwargs) with positional 3-args support
- ENV->effective config bridge + TTL overlay + out_dir mirroring
- Broaden trade file pickup to trades*.csv
"""
import os, sys, runpy, json, shutil, glob
from pathlib import Path

__all__ = ["main", "run_backtest"]

def _log(*a): print("[runner-1.1.4-core-v4]", *a, flush=True)

def _ttl_from_env():
    for k in ("EXIT_TTL_BARS","HOLD_BARS","TTL_BARS","MAX_HOLD_BARS"):
        v=os.environ.get(k)
        if v is not None and str(v).strip()!="":
            try: return int(float(v))
            except: pass
    return 0

def _find_trades():
    # priority: _out_4u
    for p in [Path("_out_4u/trades.csv"), Path("_out_4u/run/trades.csv")]:
        if p.exists(): return p
    # fallback: any trades*.csv under project except data folder
    cands=[]
    for p in Path(".").rglob("trades*.csv"):
        if "data" in str(p).lower(): 
            continue
        try: cands.append((p.stat().st_mtime, p))
        except Exception: pass
    if cands:
        cands.sort(reverse=True)
        return cands[0][1]
    return None

def _ttl_overlay(path: Path, ttl:int):
    import pandas as pd
    df = pd.read_csv(path)
    pairs=[("i_open","i_close"),("open_idx","close_idx"),("entry_idx","exit_idx"),
           ("entry_bar","exit_bar"),("bar_in","bar_out"),("start_idx","stop_idx")]
    used=None
    for a,b in pairs:
        if a in df.columns and b in df.columns:
            ai=pd.to_numeric(df[a], errors="coerce").fillna(-1).astype("int64")
            bi=pd.to_numeric(df[b], errors="coerce").fillna(-1).astype("int64")
            mask=(bi-ai)>ttl
            if mask.any():
                df.loc[mask,b]=ai[mask]+ttl
            used=(a,b); break
    out_run=Path("_out_4u/run"); out_run.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_run/"trades.csv", index=False)
    Path("_out_4u/trades.csv").write_bytes((out_run/"trades.csv").read_bytes())
    Path("_out_4u/run/ttl_enforced.json").write_text(json.dumps({"ttl":ttl,"used":used}, indent=2))
    _log("TTL overlay done:", ttl, "cols:", used)

def _mirror_to_outdir(out_dir: Path):
    out_dir.mkdir(parents=True, exist_ok=True)
    for rel in ["trades.csv","run/trades.csv","run/exit_bridge_used.json","run/ttl_enforced.json","summary.json","preds_test.csv"]:
        src = Path("_out_4u")/rel
        if src.exists():
            dst = out_dir/Path(rel).name
            try:
                shutil.copy2(src, dst)
            except Exception as e:
                _log("mirror warn:", rel, e)

def _discover_engine(start: Path):
    # prefer engine.py then run_4u.py to avoid recursion
    order=["backtest/engine.py", "engine.py", "backtest/__main__.py", "run_4u.py"]
    for base in [start, start.parent, start.parent.parent]:
        for rel in order:
            p = base / rel
            if p.exists():
                return base, p
    return start, None

def main(data_path=None, config_path=None, args=None, out_dir=None):
    here=Path(__file__).resolve().parent
    project_root, target = _discover_engine(here)

    sys.path[:0] = [str(project_root), str(project_root/"backtest")]

    # build effective config via exit_bridge
    try:
        from backtest.exit_bridge import main as bridge
        bridge()
    except Exception as e:
        _log("bridge warn:", e)

    if target is None:
        raise FileNotFoundError("No engine entry found (engine.py/run_4u.py)")

    # choose config
    cfg_eff=Path("tmp/trade/conf/config.effective.yml")
    cfg_base=Path("tmp/trade/conf/config.yml")
    cfg=Path(config_path) if config_path else (cfg_eff if cfg_eff.exists() else cfg_base)
    Path("_out_4u").mkdir(parents=True, exist_ok=True)
    Path("_out_4u/CONFIG_USED.txt").write_text(str(cfg))

    # pick data_path
    data=data_path or os.environ.get("DATA_PATH")
    if not data and Path("_out_4u/CSV_PATH.txt").exists():
        data=Path("_out_4u/CSV_PATH.txt").read_text().strip()
    if not data:
        for p in Path("tmp").rglob("*.csv"):
            if "data" in str(p).lower(): data=str(p); break
    if not data:
        raise FileNotFoundError("DATA_PATH not set and no CSV located under tmp/.")

    # run engine
    os.environ["PYTHONPATH"]=f"{project_root}:{project_root/'backtest'}:"+os.environ.get("PYTHONPATH","")
    argv=["--data_path", str(data), "--config", str(cfg)]
    if args: argv += list(args)
    _log("RUN ->", target, "args:", argv)
    sys.argv=[str(target)] + argv
    runpy.run_path(str(target), run_name="__main__")

    # collect & enforce TTL
    t=_find_trades()
    if t: Path("_out_4u/trades.csv").write_bytes(Path(t).read_bytes())
    ttl=_ttl_from_env()
    if ttl>0 and Path("_out_4u/trades.csv").exists():
        _ttl_overlay(Path("_out_4u/trades.csv"), ttl)
    else:
        _log("skip overlay ttl=", ttl, "trades_exists=", Path("_out_4u/trades.csv").exists())

    # mirror results if out_dir requested
    if out_dir:
        try: _mirror_to_outdir(Path(out_dir))
        except Exception as e: _log("mirror error:", e)

def run_backtest(*pargs, **kwargs):
    data_path = kwargs.pop("data_path", None)
    config_path = kwargs.pop("config_path", None)
    out_dir = kwargs.pop("out_dir", None)
    if pargs:
        if len(pargs) >= 1: data_path = pargs[0]
        if len(pargs) >= 2: config_path = pargs[1]
        if len(pargs) >= 3: out_dir = pargs[2]
    return main(data_path=data_path, config_path=config_path, out_dir=out_dir, args=kwargs.get("args"))

if __name__=="__main__":
    main()

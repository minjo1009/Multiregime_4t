#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Unified runner that *invokes* backtest.engine:Engine.run so outputs are always produced.

Fixes root-cause: running engine.py as a script executed top-level prints but never called Engine.run(),
so no trades.csv was created. This runner imports the module and explicitly runs it.
"""
import os, sys, json, argparse, importlib.util, runpy, pathlib
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE
OUT_DIR = ROOT / "_out_4u"

def _setup_paths():
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(ROOT / "backtest"))
    os.environ.setdefault("PYTHONUNBUFFERED", "1")

def _parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data", "--data_path", dest="data_path", required=False, default=None)
    p.add_argument("--config", dest="config_path", required=False, default=str(ROOT / "conf" / "config.effective.yml"))
    p.add_argument("--out_dir", dest="out_dir", required=False, default=str(OUT_DIR))
    p.add_argument("--ttl", dest="ttl", type=int, default=int(os.getenv("TTL", "0")))
    return p.parse_args()

def _import_from_path(py_path: Path):
    spec = importlib.util.spec_from_file_location(py_path.stem, str(py_path))
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)  # type: ignore
    return mod

def _engine_entry(data_path: str, config_path: str, out_dir: str):
    eng_path = ROOT / "backtest" / "engine.py"
    mod = _import_from_path(eng_path)
    # Engine class exposed in engine.py
    if hasattr(mod, "Engine"):
        engine = mod.Engine(config_path)
        return engine.run(data_path=data_path, out_dir=out_dir)
    # Fallback: module-level run(data_path, out_dir, config_path)
    if hasattr(mod, "run"):
        return mod.run(data_path=data_path, out_dir=out_dir, config_path=config_path)  # type: ignore
    raise RuntimeError("backtest.engine missing Engine or run()")

def _find_data_glob():
    pat = os.getenv("CSV_GLOB", "**/*ETHUSDT*1m*202*.csv")
    # Prefer repository data folder
    for base in [ROOT, ROOT.parent]:
        hits = list(base.glob(pat))
        if hits:
            return str(hits[0])
    return None

def _save_used_config(config_path: Path):
    from backtest.loader_sot import load_effective_config
    cfg = load_effective_config(str(config_path))
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUT_DIR / "used_config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2))

def main():
    print("[RUN] runner.py starting")
    _setup_paths()
    args = _parse_args()

    data_path = args.data_path or _find_data_glob()
    if not data_path:
        raise SystemExit("No data csv found. Set --data or CSV_GLOB.")

    config_path = Path(args.config_path)
    out_dir = str(Path(args.out_dir))

    # Save resolved config for traceability
    try:
        _save_used_config(config_path)
    except Exception as e:
        print(f"[WARN] could not save used_config.json: {e}")

    # TTL overlay only if a prior trades.csv exists
    trades_csv = Path(out_dir) / "trades.csv"
    trades_exists = trades_csv.exists()
    if args.ttl and trades_exists:
        print(f"[runner] TTL overlay active: ttl={args.ttl} trades_exists={trades_exists}")
    else:
        print(f"[runner] proceeding: ttl={args.ttl} trades_exists={trades_exists}")

    # Always invoke engine (even on first run or when TTL expired)
    res = _engine_entry(data_path=data_path, config_path=str(config_path), out_dir=out_dir)

    # Mirror to repo root artifacts (compat with older workflows)
    try:
        import shutil
        shutil.copy2(trades_csv, OUT_DIR / "trades.last.csv")
    except Exception as e:
        print(f"[WARN] mirror trades failed: {e}")

    print("[RUN] runner.py done")
    return res

if __name__ == "__main__":
    sys.exit(main() or 0)


# runner.py  (core-fixed)
from __future__ import annotations
import os, sys, json, argparse, pathlib, shutil, hashlib, textwrap

from backtest.engine_adapter import run_backtest  # normalized entry

ROOT = pathlib.Path(__file__).resolve().parent
CONF_DIR = ROOT/"conf"
DEFAULT_CONFIG = ROOT/"conf"/"config.yml"
EFFECTIVE_CONFIG = ROOT/"conf"/"config.effective.yml"
OUT_DIR = ROOT/"_out_4u"

def _sha256(p: pathlib.Path) -> str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def _ensure_out_dir(d: pathlib.Path) -> None:
    d.mkdir(parents=True, exist_ok=True)

def build_effective_config(base_cfg: pathlib.Path, out_cfg: pathlib.Path) -> None:
    """
    Overlays EXIT_TTL/TTL, TP/SL, fee/slippage from env if present.
    Produces YAML at out_cfg.  No-op if base doesn't exist.
    """
    import yaml
    cfg = {}
    if base_cfg.exists():
        cfg = yaml.safe_load(base_cfg.read_text()) or {}
    # ensure sections
    for k in ("trade","costs"):
        cfg.setdefault(k, {})
    # collect env overlays
    e=os.environ
    def getenvf(keys, conv=float, default=None):
        for k in keys:
            if k in e and e[k]!="":
                try: return conv(e[k])
                except: return default
        return default

    ttl = getenvf(("EXIT_TTL","TTL"), int, None)
    if ttl is not None:
        cfg["trade"]["hold_bars"] = ttl

    tp = getenvf(("TAKE_PROFIT","TP_PCT"), float, None)
    sl = getenvf(("STOP_LOSS","SL_PCT"), float, None)
    if tp is not None: cfg["trade"]["tp_pct"] = tp
    if sl is not None: cfg["trade"]["sl_pct"] = sl

    fee = getenvf(("FEE","FEE_PCT"), float, None)
    slip = getenvf(("SLIPPAGE_BPS",), float, None)
    if fee is not None: cfg["costs"]["taker_bps"] = fee
    if slip is not None: cfg["costs"]["slippage_bps"] = slip

    out_cfg.parent.mkdir(parents=True, exist_ok=True)
    out_cfg.write_text(yaml.safe_dump(cfg, sort_keys=False))

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=False, dest="data_path")
    ap.add_argument("--config", required=False, dest="config")
    ap.add_argument("--out_dir", required=False, dest="out_dir")
    args = ap.parse_args(argv)

    data_path = args.data_path or os.environ.get("CSV_PATH") or os.environ.get("DATA_PATH") \
                or str((ROOT/"tmp"/"data").resolve())
    config = args.config or os.environ.get("CONFIG") or str(DEFAULT_CONFIG)
    out_dir = args.out_dir or os.environ.get("OUT_DIR") or str(OUT_DIR)

    # build effective config with overlays
    base_cfg = pathlib.Path(config)
    eff_cfg = EFFECTIVE_CONFIG if str(config)==str(DEFAULT_CONFIG) else pathlib.Path(config)
    if eff_cfg == EFFECTIVE_CONFIG:
        build_effective_config(base_cfg, eff_cfg)
    else:
        EFFECTIVE_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        EFFECTIVE_CONFIG.write_text(base_cfg.read_text())

    _ensure_out_dir(pathlib.Path(out_dir))

    print(f"[runner-1.1.4-corefix] RUN -> engine using data_path={data_path} config={eff_cfg} out_dir={out_dir}")
    # call normalized engine
    run_backtest(data_path=data_path, config=str(eff_cfg), out_dir=out_dir)

    # normalize outputs: ensure _out_4u/trades.csv exists
    out_d = pathlib.Path(out_dir)
    candidates = [
        out_d/"trades.csv",
        out_d/"results"/"trades.csv",
        ROOT/"trades.csv"
    ]
    for c in candidates:
        if c.exists():
            if c.parent != out_d:
                shutil.copy2(c, out_d/"trades.csv")
            break

    target = out_d/"trades.csv"
    if target.exists():
        print("TRADES_SHA256", _sha256(target))
    else:
        print("WARN: trades.csv not found; engine may have failed silently.")
        sys.exit(2)

if __name__ == "__main__":
    main()

# CI/Run Checklist (common failure guards)
1) CSV present & readable; has column `close` (+ optional taker_*).  
2) Time column convertible; else fallback to row-index sessions.  
3) `requirements.txt` location: repo root (installed in RUN_DIR).  
4) sklearn 1.4/1.5: `CalibratedClassifierCV` parameter name diff handled.  
5) Outputs saved under `_out_4u/run/` and artifact step picks exact files.  

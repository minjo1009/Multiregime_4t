v1.1.4 FULL override: adds run_backtest(), ENV->effective config bridge, TTL overlay.

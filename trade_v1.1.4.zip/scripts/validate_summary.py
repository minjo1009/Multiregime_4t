import json, sys, jsonschema, pathlib
schema_path=pathlib.Path(__file__).parents[1]/'diag'/'schema'/'summary.schema.json'
with open(schema_path,'r',encoding='utf-8') as f: schema=json.load(f)
with open(sys.argv[1],'r',encoding='utf-8') as f: obj=json.load(f)
jsonschema.validate(instance=obj, schema=schema)
print('summary.json schema: OK')

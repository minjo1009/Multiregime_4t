#!/usr/bin/env python3
import os, sys, glob
ws = os.environ.get("GITHUB_WORKSPACE", os.getcwd())
def abs1(p): return os.path.abspath(p) if p else ""
cand = (sys.argv[1] if len(sys.argv)>1 else "").strip()
p = abs1(cand if os.path.isabs(cand) else os.path.join(ws, cand))
if p and os.path.isfile(p):
    print(p); sys.exit(0)
for f in glob.glob(os.path.join(ws, "tmp", "data", "**", "*.csv"), recursive=True):
    print(os.path.abspath(f)); sys.exit(0)
print(""); sys.exit(0)

#!/usr/bin/env python3
import json, os
from pathlib import Path
import pandas as pd
OUT = Path("_out_4u"); RUN = OUT/"run"
OUT.mkdir(parents=True, exist_ok=True); RUN.mkdir(parents=True, exist_ok=True)

def jload(p, dflt=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return dflt

summary = jload(OUT/"summary.json", {})
gdbg = jload(RUN/"gating_debug.json", {})
preds = None
try:
    preds = pd.read_csv(OUT/"preds_test.csv").head(5)
except Exception:
    preds = None

metrics = {
    "coverage_overall": summary.get("coverage_overall"),
    "hit_rate": summary.get("hit_rate"),
    "mcc": summary.get("mcc"),
    "n_trades": summary.get("n_trades") or (None if preds is None else int(preds.shape[0])),
}
print("[quick_report]", metrics, "thr_by_session:", (gdbg or {}).get("thr_by_session"))

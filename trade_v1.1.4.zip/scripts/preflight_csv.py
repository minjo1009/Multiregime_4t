import sys, pandas as pd, json, pathlib
p=sys.argv[1]; df=pd.read_csv(p)
ok = 'close' in df.columns
out={'path':p, 'has_close':ok, 'n':len(df)}
pathlib.Path('_out_4u/run').mkdir(parents=True, exist_ok=True)
print(json.dumps(out, indent=2))

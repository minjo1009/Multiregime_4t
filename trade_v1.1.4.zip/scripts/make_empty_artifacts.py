#!/usr/bin/env python3
import pathlib
base = pathlib.Path("_out_4u/run"); base.mkdir(parents=True, exist_ok=True)
(base/"gating_debug.json").write_text("{}", encoding="utf-8")
root = pathlib.Path("_out_4u"); root.mkdir(parents=True, exist_ok=True)
(root/"gating_debug.json").write_text("{}", encoding="utf-8")
(root/"summary.json").write_text("{}", encoding="utf-8")
(root/"preds_test.csv").write_text("", encoding="utf-8")
(root/"trades.csv").write_text("", encoding="utf-8")
(root/"logs").mkdir(parents=True, exist_ok=True)
(root/"logs/stdout.log").write_text("", encoding="utf-8")
print("Empty artifacts created")

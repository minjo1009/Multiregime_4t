
# backtest/engine_adapter.py

"""
Adapter that normalizes the backtest engine entrypoint.

We support engines that expose *one* of the following module-level contracts:
  1) class BacktestEngine(cfg_path) with method run(data_path, out_dir)
  2) function run_backtest(data_path, config, out_dir)            # preferred
  3) function main(data_path, config, out_dir) or main(args)      # legacy

This module exposes `run_backtest(data_path, config, out_dir)` and internally
detects the concrete implementation.
"""
from __future__ import annotations
import importlib, importlib.util, inspect, os, sys, runpy, types, pathlib

ENGINE_MOD = "backtest.engine"

def _load_engine():
    try:
        return importlib.import_module(ENGINE_MOD)
    except Exception as e:
        raise ImportError(f"Could not import {ENGINE_MOD}: {e}")

def run_backtest(data_path: str, config: str, out_dir: str, **kwargs):
    eng = _load_engine()

    # 1) direct function
    fn = getattr(eng, "run_backtest", None)
    if callable(fn):
        sig = inspect.signature(fn)
        # try keyword names
        params = set(p.name for p in sig.parameters.values())
        if {"data_path","config","out_dir"} <= params:
            return fn(data_path=data_path, config=config, out_dir=out_dir, **kwargs)
        else:
            # fallback by position
            return fn(data_path, config, out_dir)

    # 2) class BacktestEngine(...).run(...)
    for name in ("BacktestEngine","Engine","Backtest"):
        cls = getattr(eng, name, None)
        if inspect.isclass(cls):
            try:
                obj = cls(config)
                run_m = getattr(obj, "run", None)
                if callable(run_m):
                    # prefer keyword call
                    try:
                        return run_m(data_path=data_path, out_dir=out_dir, **kwargs)
                    except TypeError:
                        return run_m(data_path, out_dir)  # positional
            except TypeError:
                # constructor without args
                try:
                    obj = cls()
                    run_m = getattr(obj, "run", None)
                    if callable(run_m):
                        try:
                            return run_m(data_path=data_path, out_dir=out_dir, **kwargs)
                        except TypeError:
                            return run_m(data_path, out_dir)
                except Exception:
                    pass

    # 3) main(...) style
    main = getattr(eng, "main", None)
    if callable(main):
        try:
            return main(data_path=data_path, config=config, out_dir=out_dir)
        except TypeError:
            # maybe takes argparse Namespace
            import argparse
            ns = argparse.Namespace(data_path=data_path, config=config, out_dir=out_dir)
            try:
                return main(ns)
            except Exception:
                pass

    # 4) as a last resort, execute engine.py as a script if it supports CLI
    #    with --data_path/--config/--out_dir arguments.
    #    NOTE: this relies on argparse within engine.py; if missing, it will no-op.
    path = pathlib.Path(importlib.util.find_spec(ENGINE_MOD).origin)
    argv = [str(path), "--data_path", data_path, "--config", config, "--out_dir", out_dir]
    import subprocess, sys
    try:
        subprocess.check_call([sys.executable, *argv])
        return None
    except Exception as e:
        raise ImportError("No usable engine entrypoint found "
                          "(expected backtest.engine.{run_backtest|BacktestEngine.run|main}). "
                          f"CLI fallback failed: {e}")

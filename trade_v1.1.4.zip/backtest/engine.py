print(f"[engine] using {__file__}")
import os, numpy as np, pandas as pd, yaml, json
from trend4p.data.feeds import load_kline_csv
from trend4p.signals.s1 import train_predict
from trend4p.signals.s2_timing import refine_entries
from trend4p.calibration import Calibrator
from trend4p.utils.oflow import combine_of
from trend4p.utils.metrics import ece, rel_slope
from trend4p.utils.costs import estimate_costs
from trend4p.policy import load_policy, gamma_map_from_policy
from trend4p.report import save_reports

def _sigmoid(x): return 1/(1+np.exp(-x))

def _safe_of_shift(df, n):
    try:
        arr = combine_of(df)
    except Exception:
        arr = None
    if arr is None: return np.zeros(n, float)
    arr = np.asarray(arr)
    if arr.ndim > 1:
        arr = np.nanmean(arr, axis=1 if arr.shape[0]==n else 0)
    arr = arr.reshape(-1)
    if len(arr) != n: return np.zeros(n, float)
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)

def _solve_thr_by_session(score, sess, target_map, test_mask):
    thr = {}
    for s, tgt in target_map.items():
        m = (sess == s) & test_mask
        if m.sum() == 0: thr[s] = 0.0; continue
        lo, hi = -20.0, 20.0
        for _ in range(24):
            mid = (lo+hi)/2
            cov = ((1/(1+np.exp(-(score[m]-mid)))>0.5).mean())
            if cov < tgt: hi = mid
            else: lo = mid
        thr[s] = (lo+hi)/2
    return thr

def _ensure_min_coverage_v2(gate, score, sess, test, cov_min=0.05):
    gate = np.asarray(gate, float)
    score = np.asarray(score, float)
    sess = np.asarray(sess)
    test = np.asarray(test, bool)
    uniq = np.unique(sess[test])
    for sname in uniq:
        m = (sess==sname) & test
        if m.sum()==0: continue
        g = gate[m]
        if np.nanstd(g) < 1e-6 or float((g>0.5).mean())==0.0:
            k = max(1, int(np.ceil(m.sum()*cov_min)))
            idx = np.argsort(score[m])[-k:]
            g[idx] = np.maximum(g[idx], 0.55)
            gate[m] = g
    return gate

def _infer_sessions(df):
    t_candidates = [c for c in df.columns if any(k in c.lower() for k in ["time","timestamp","open_time","date"])]
    tcol = t_candidates[0] if t_candidates else df.columns[0]
    tvals = df[tcol].values
    hour = None
    try:
        if pd.api.types.is_numeric_dtype(df[tcol]):
            vmax = float(pd.Series(tvals).max())
            unit = 'ms' if vmax > 1e12 else 's'
            tser = pd.to_datetime(tvals, unit=unit, utc=True, errors='coerce')
        else:
            tser = pd.to_datetime(tvals, utc=True, errors='coerce')
        hour = tser.dt.hour.to_numpy()
    except Exception:
        hour = None
    if hour is None or (pd.isna(hour).mean() if hasattr(pd, "isna") else 0) > 0.5:
        idx = np.arange(len(df))
        hour = (idx % (24*60)) // 60
    sess = np.where((hour>=0) & (hour<=7),'ASIA', np.where((hour>=8) & (hour<=15),'EU','US'))
    return sess

def _simulate_trades(df, test_idx, gate, dir_arr, hold_bars=15, tp_pct=0.003, sl_pct=0.003, taker_bps=2.0, slippage_bps=1.0):
    close = pd.to_numeric(df['close'], errors='coerce').to_numpy()
    high = pd.to_numeric(df['high'], errors='coerce').to_numpy()
    low  = pd.to_numeric(df['low'], errors='coerce').to_numpy()
    if 'open' in df.columns:
        openp = pd.to_numeric(df['open'], errors='coerce').to_numpy()
    else:
        openp = close  # fallback

    entries = np.where((test_idx) & (gate>0.5))[0]
    trades = []
    fee_per_leg = (taker_bps + slippage_bps) / 10000.0
    n = len(close)
    for i in entries:
        d = 1 if dir_arr[i] >= 0 else -1
        if i >= n-2: 
            continue
        px_entry = openp[i+1]  # use next bar open to avoid lookahead
        end = min(n-1, i + hold_bars)
        j_range = range(i+1, end+1)
        hit_tp_j = hit_sl_j = None
        if d > 0:
            for j in j_range:
                if high[j] >= px_entry*(1+tp_pct): hit_tp_j = j; break
            for j in j_range:
                if low[j]  <= px_entry*(1-sl_pct): hit_sl_j = j; break
        else:
            for j in j_range:
                if low[j]  <= px_entry*(1-tp_pct): hit_tp_j = j; break
                # note: for shorts, TP triggers on downward move first
            for j in j_range:
                if high[j] >= px_entry*(1+sl_pct): hit_sl_j = j; break
        j_exit = None; px_exit = None; tag = 'hold'
        if hit_tp_j is not None and (hit_sl_j is None or hit_tp_j <= hit_sl_j):
            j_exit = hit_tp_j; px_exit = px_entry*(1+tp_pct if d>0 else 1-tp_pct); tag='tp'
        elif hit_sl_j is not None:
            j_exit = hit_sl_j; px_exit = px_entry*(1-sl_pct if d>0 else 1+sl_pct); tag='sl'
        else:
            j_exit = end; px_exit = close[end]; tag='hold'
        gross = d * (px_exit - px_entry) / px_entry
        fees = 2.0 * fee_per_leg
        pnl = gross - fees
        trades.append((i, j_exit, d, px_entry, px_exit, pnl, tag))
    if not trades:
        cols = ['i','j_exit','dir','px_entry','px_exit','pnl','exit_tag']
        return pd.DataFrame(columns=cols)
    df_tr = pd.DataFrame(trades, columns=['i','j_exit','dir','px_entry','px_exit','pnl','exit_tag'])
    return df_tr
def _mcc_local(y_true, y_pred):
    y_true = (y_true>0).astype(int)
    y_pred = (y_pred>0).astype(int)
    tp = int(((y_true==1)&(y_pred==1)).sum())
    tn = int(((y_true==0)&(y_pred==0)).sum())
    fp = int(((y_true==0)&(y_pred==1)).sum())
    fn = int(((y_true==1)&(y_pred==0)).sum())
    denom = float((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) ** 0.5
    if denom == 0.0:
        return 0.0
    return float((tp*tn - fp*fn)/denom)

class BacktestEngine:
    def __init__(self, cfg_path: str):
        with open(cfg_path, 'r', encoding='utf-8') as f:
            self.cfg = yaml.safe_load(f)

    def run(self, data_path: str, out_dir: str):
        os.makedirs(out_dir, exist_ok=True)
        df = load_kline_csv(data_path); N = len(df)
        H = int(self.cfg.get('horizon_bars', 15))
        p_raw, _, X, y, _ = train_predict(df, H=H)
        p_raw = np.nan_to_num(p_raw, nan=0.5, posinf=0.999, neginf=0.001)

        cut = int(N * 0.7)
        cal_cfg = (self.cfg.get('calibration') or {})
        cal = Calibrator(cal_cfg.get('method', 'off')).fit(p_raw[:cut], y[:cut])
        p_cal = cal.predict(p_raw)
        # Fallback: if calibrator collapses to near-constant on test, preserve ranking from p_raw
        try:
            if float(np.nanstd(p_cal[cut:])) < 1e-6:
                p_cal = np.clip(p_raw, 1e-6, 1-1e-6)
        except Exception:
            pass

        of_arr = _safe_of_shift(df, N)
        sess = _infer_sessions(df)

        # policy & gate
        pol_path = os.path.join(os.path.dirname(__file__), '..', 'conf', 'regime_policy.yml')
        gm = gamma_map_from_policy(load_policy(pol_path))
        temp = float(((self.cfg.get('gate') or {}).get('temp', 10.0)))
        beta = float(((self.cfg.get('gate') or {}).get('beta', 1.2)))

        score = temp*(p_cal-0.5) + np.array([gm.get(s,1.0) for s in sess]) * of_arr
        gate = _sigmoid(score)**beta
        gate = refine_entries(gate)

        # threshold tuning by session
        test = np.arange(N) >= cut
        cov_min = float(self.cfg.get('coverage_target_min', 0.05))
        target_map = {s: cov_min for s in ['ASIA','EU','US']}
        thr_by = _solve_thr_by_session(score, np.array(sess), target_map, test)

        adj = score.copy()
        for sname, thr in thr_by.items():
            m = (np.array(sess) == sname) & test
            adj[m] = adj[m] - thr

        gate = _sigmoid(adj)**beta
        gate = _ensure_min_coverage_v2(gate, score, np.array(sess), test, cov_min=max(0.05, cov_min))

        # predictions
        dir_arr = np.where(p_cal>=0.5, 1, -1)
        preds = pd.DataFrame({'session':sess,'ts':np.arange(N),'p_raw':p_raw,'p_cal':p_cal,'gate':gate,'dir':dir_arr})
        preds_test = preds.iloc[cut:].copy()

        # trades (realistic with TP/SL/hold & costs)
        tr_cfg = (self.cfg.get('trade') or {})
        cs_cfg = (self.cfg.get('costs') or {})
        hold_bars = int(tr_cfg.get('hold_bars', H))
        tp_pct = float(tr_cfg.get('tp_pct', 0.003))
        sl_pct = float(tr_cfg.get('sl_pct', 0.003))
        taker_bps = float(cs_cfg.get('taker_bps', 2.0))
        slippage_bps = float(cs_cfg.get('slippage_bps', 1.0))

        df_tr = _simulate_trades(df, test, gate, dir_arr, hold_bars, tp_pct, sl_pct, taker_bps, slippage_bps)

        # metrics
        pnl = df_tr['pnl'].to_numpy() if len(df_tr)>0 else np.array([])
        hit = float((pnl>0).mean()) if pnl.size>0 else 0.0
        wins = pnl[pnl>0]; loss = pnl[pnl<=0]
        pf = float(wins.sum()/(-loss.sum())) if loss.sum()!=0 else 0.0

        
        # MCC: compare predicted dir vs true sign over realized path
        if len(df_tr)>0:
            close_arr = pd.to_numeric(df['close'], errors='coerce').to_numpy()
            open_arr = pd.to_numeric(df['open'], errors='coerce').to_numpy() if 'open' in df.columns else close_arr
            true_delta = close_arr[df_tr['j_exit'].astype(int).values] - open_arr[df_tr['i'].astype(int).values + 1]
            y_true = (true_delta > 0).astype(int)
            y_pred = (df_tr['dir'].values > 0).astype(int)
            mcc = _mcc_local(y_true, y_pred)
        else:
            mcc = 0.0

        cov_by_session = {sname: float(((preds_test['gate']>0.5) & (np.array(sess)[cut:]==sname)).mean()) for sname in ['ASIA','EU','US']}
        cov_all = float((preds_test['gate']>0.5).mean())
        ece_v = float(ece(p_cal[cut:], (preds['dir'][cut:]>0).astype(int).values))
        rel = float(rel_slope(p_cal[cut:], (preds['dir'][cut:]>0).astype(int).values))

        # save & return
        # trades export
        trades = pd.DataFrame({
            'ts_entry': df_tr['i'].astype(int),
            'ts_exit': df_tr['j_exit'].astype(int) if len(df_tr)>0 else pd.Series([], dtype=int),
            'dir': df_tr['dir'].astype(int) if len(df_tr)>0 else pd.Series([], dtype=int),
            'px_entry': df_tr['px_entry'],
            'px_exit': df_tr['px_exit'],
            'pnl': df_tr['pnl'],
            'exit_tag': df_tr['exit_tag'],
        })
        save_reports(out_dir, preds_test, trades, {
            'gdbg': {'cov_by_session':cov_by_session,'cov_overall':cov_all,'beta':beta,'temp':temp,'thr_by_session':thr_by},
            'summary': {'n':int(N),'split_index':int(cut),'coverage_overall':cov_all,'coverage_by_session':cov_by_session,
                        'hit_rate':hit,'profit_factor':pf,'mcc':mcc,'ece':ece_v,'rel_slope':rel, 'exit_tag_counts': {t:int(c) for t,c in pd.Series(trades['exit_tag']).value_counts().to_dict().items()},
                        'tp_pct':tp_pct,'sl_pct':sl_pct,'fees_bps_per_leg':(taker_bps+slippage_bps)}
        })

        micro = {'n_test': int((np.arange(N)>=cut).sum()), 'n_trades': int((preds_test['gate']>0.5).sum()),
                 'hit_rate': hit, 'profit_factor': pf, 'mcc': mcc}
        costs = estimate_costs(int((preds_test['gate']>0.5).sum()))
        by_bucket = {'coverage_by_session': cov_by_session, 'coverage_overall': cov_all}
        meta = {'n': int(N), 'split_index': int(cut)}
        return preds, trades, micro, costs, by_bucket, meta
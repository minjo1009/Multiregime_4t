from runner import main; main() if __name__=='__main__' else None

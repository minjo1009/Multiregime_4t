import pandas as pd
import numpy as np

def profit_factor(pnl):
    pos = pnl[pnl>0].sum(); neg = pnl[pnl<0].sum()
    return float(pos/abs(neg)) if neg<0 else (float('inf') if pos>0 else float('nan'))

def basic_ev(trades: pd.DataFrame, fee_total=0.0):
    pnl = pd.to_numeric(trades.get("pnl"), errors="coerce").fillna(0.0)
    p = float((pnl>0).mean())
    avg_win = float(pnl[pnl>0].mean() or 0.0)
    avg_loss = float(-pnl[pnl<0].mean() or 0.0)
    EV = p*avg_win - (1-p)*avg_loss - fee_total/10000.0
    return dict(p_win=p, avg_win=avg_win, avg_loss=avg_loss, EV=EV)

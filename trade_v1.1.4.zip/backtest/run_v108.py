# backtest/run_v108.py — artifact-guarantee wrapper
import os, json, argparse
import pandas as pd, numpy as np
from datetime import datetime as _dt
def ensure_dir(d): os.makedirs(d, exist_ok=True)
def write_json(p,o):
    with open(p,"w",encoding="utf-8") as f: json.dump(o,f,ensure_ascii=False,indent=2)
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--config", default=None)
    ap.add_argument("--out_dir", required=True)
    a=ap.parse_args()
    ensure_dir(a.out_dir)
    need=["open_time","open","high","low","close","volume"]
    df=pd.read_csv(a.data_path)
    miss=[c for c in need if c not in df.columns]
    if miss: raise SystemExit(f"Preflight passed but runtime missing columns: {miss}")
    ret1=df["close"].astype(float).pct_change().fillna(0.0)
    s1=(ret1-ret1.mean())/(ret1.std()+1e-12)
    a10,beta=10.0,1.2
    sig=lambda x:1.0/(1.0+np.exp(-x))
    gate=(sig(a10*s1.values))**beta
    preds=pd.DataFrame({"open_time":df["open_time"],"score":s1.values,"gate":gate})
    preds.to_csv(os.path.join(a.out_dir,"preds_test.csv"), index=False)
    side=np.where(s1.values>0,1,-1)
    trades=pd.DataFrame({"open_time":df["open_time"],"side":side,"px":df["close"].astype(float).values})
    trades.to_csv(os.path.join(a.out_dir,"trades.csv"), index=False)
    write_json(os.path.join(a.out_dir,"gating_debug.json"),{"head":preds.head(5).to_dict(orient="list")})
    write_json(os.path.join(a.out_dir,"summary.json"),{
        "created_utc":_dt.utcnow().isoformat()+"Z",
        "n_rows":int(len(df)),
        "n_trades":int((np.abs(side)>0).sum()),
        "placeholders":True,
        "notes":"v1.0.8 wrapper to ensure artifacts"})
if __name__=="__main__": main()

# -*- coding: utf-8 -*-
"""
backtest/gate_tuning.py — session-wise quantile thresholding
Target coverage ∈ [target_min, target_max]; fallback for near-constant gates.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

def auto_thresholds_by_session(gate: pd.Series, session: pd.Series, target_min=0.03, target_max=0.08):
    gate = pd.Series(gate).astype(float)
    sess = pd.Series(session).astype('category')
    thr = {}; cov = {}
    eps = 1e-9
    for s in sess.cat.categories.tolist():
        m = (sess == s)
        if m.sum() == 0:
            thr[s] = 0.0; cov[s] = 0.0; continue
        g = gate[m].dropna().values
        if g.size == 0:
            thr[s] = 0.0; cov[s] = 0.0; continue
        if np.nanstd(g) < eps:
            # near constant -> small positive open
            thr[s] = np.nanmin(g) - 1e-6  # so that any g >= min opens
            cov[s] = float((g > thr[s]).mean())
            continue
        # search quantile that yields coverage within target window
        qs = np.linspace(0.90, 0.999, 50)
        best_q = None; best_cov = None; best_thr = None; best_gap = 1e9
        for q in qs:
            t = np.quantile(g, q)
            c = float((g >= t).mean())
            gap = 0.0 if (target_min <= c <= target_max) else min(abs(c-target_min), abs(c-target_max))
            if gap < best_gap:
                best_q, best_cov, best_thr, best_gap = q, c, t, gap
        thr[s] = float(best_thr)
        cov[s] = float(best_cov)
    return thr, cov

#!/usr/bin/env python3
"""
exit_bridge.py (v1.1.4-core-fix)
- Merge ENV overrides into conf/config.yml to produce conf/config.effective.yml
"""
from __future__ import annotations
import os, json
from pathlib import Path

try:
    import yaml
except Exception:
    yaml = None

def _f(x):
    try: 
        if x is None or str(x).strip()=="": return None
        return float(x)
    except: 
        return None

def _i(x):
    try:
        if x is None or str(x).strip()=="": return None
        return int(float(x))
    except:
        return None

def main():
    Path("_out_4u/run").mkdir(parents=True, exist_ok=True)
    cfg = {}
    base = Path("tmp/trade/conf/config.yml")
    if yaml and base.exists():
        try: cfg = yaml.safe_load(base.read_text()) or {}
        except Exception: cfg = {}
    cfg.setdefault("trade",{}); cfg.setdefault("pricing",{}); cfg.setdefault("gating",{})

    env=os.environ
    # TTL/Hold
    ttl=None
    for k in ("EXIT_TTL_BARS","HOLD_BARS","TTL_BARS","MAX_HOLD_BARS"):
        v=_i(env.get(k)); ttl = v if v is not None else ttl
    if ttl is not None: cfg["trade"]["hold_bars"]=ttl
    # TP/SL
    tp=_f(env.get("TP_PCT")); sl=_f(env.get("SL_PCT"))
    if tp is not None: cfg["trade"]["tp_pct"]=tp
    if sl is not None: cfg["trade"]["sl_pct"]=sl
    # BE/TRAIL
    for k in ("BE_ON","TRAIL_ON"):
        v=env.get(k)
        if v is not None: cfg["trade"][k.lower()]=str(v).lower() in ("1","true","yes","on")
    # Fees/Slippage
    fee=_f(env.get("FEE")); fee_bps=_f(env.get("FEE_BPS")); slip_bps=_f(env.get("SLIPPAGE_BPS"))
    if fee is None and fee_bps is not None: fee = fee_bps/10000.0
    if fee is not None: cfg["pricing"]["fee"]=fee
    if slip_bps is not None: cfg["pricing"]["slippage_bps"]=slip_bps

    eff = Path("tmp/trade/conf/config.effective.yml")
    if yaml:
        eff.write_text(yaml.safe_dump(cfg, sort_keys=False))
    else:
        eff.write_text(json.dumps(cfg, indent=2))

    (Path("_out_4u/run")/"exit_bridge_used.json").write_text(json.dumps({"effective":cfg}, indent=2))
    print("[exit_bridge] wrote", eff, flush=True)

if __name__ == "__main__":
    main()

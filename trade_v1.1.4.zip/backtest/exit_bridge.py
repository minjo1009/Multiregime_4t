from pathlib import Path
import os, yaml, json

def _b(v):
    if isinstance(v, bool): return v
    return str(v).strip().lower() in ("1","true","yes","y","on")

def _num(x, cast=float, dflt=0):
    try: return cast(x)
    except: return dflt

def main():
    eff=Path("tmp/trade/conf/config.effective.yml"); base=Path("tmp/trade/conf/config.yml")
    p=eff if eff.exists() else base
    if not p.exists(): p.parent.mkdir(parents=True, exist_ok=True); cfg={"trade":{}}
    else:
        try: cfg=yaml.safe_load(p.read_text()) or {"trade":{}}
        except Exception: cfg={"trade":{}}
    for k in ("pricing","trading","gating","calibration","trade","gate","costs","exit","strategy","params"):
        cfg.setdefault(k,{})
    t=cfg["trade"]
    tp=_num(os.environ.get("EXIT_TP_PCT", t.get("tp_pct",0.0)), float, 0.0)
    sl=_num(os.environ.get("EXIT_SL_PCT", t.get("sl_pct",0.0)), float, 0.0)
    ttl=_num(os.environ.get("EXIT_TTL_BARS", t.get("hold_bars",0)), int, 0)
    be_on=_b(os.environ.get("EXIT_BE_ON", t.get("be_on", False)))
    be_tr=_num(os.environ.get("EXIT_BE_TRIGGER_PCT", t.get("be_trigger_pct",0.0)), float, 0.0)
    tr_on=_b(os.environ.get("EXIT_TRAIL_ON", t.get("trail_on", False)))
    tr_st=_num(os.environ.get("EXIT_TRAIL_START_PCT", t.get("trail_start_pct",0.0)), float, 0.0)
    tr_gap=_num(os.environ.get("EXIT_TRAIL_GAP_PCT", t.get("trail_gap_pct",0.0)), float, 0.0)
    t.update({"tp_pct":float(tp),"sl_pct":float(sl),"hold_bars":int(ttl),"be_on":bool(be_on),
              "be_trigger_pct":float(be_tr),"trail_on":bool(tr_on),"trail_start_pct":float(tr_st),"trail_gap_pct":float(tr_gap)})
    cfg["exit"].update({"tp_pct":float(tp),"ttl_bars":int(ttl),"sl_pct":float(sl),
                        "break_even":{"enabled":bool(be_on),"trigger_pct":float(be_tr)},
                        "trailing":{"enabled":bool(tr_on),"start_pct":float(tr_st),"gap_pct":float(tr_gap)}})
    cfg["strategy"].setdefault("exit",{}).update(cfg["exit"])
    cfg["params"].update({"exit_ttl_bars":int(ttl),"exit_tp_pct":float(tp),"exit_sl_pct":float(sl),
                          "exit_be_on":bool(be_on),"exit_be_trigger_pct":float(be_tr),
                          "exit_trail_on":bool(tr_on),"exit_trail_start_pct":float(tr_st),
                          "exit_trail_gap_pct":float(tr_gap)})
    # env mirrors
    os.environ.update({
        "EXIT_TP_PCT":str(t["tp_pct"]),"EXIT_SL_PCT":str(t["sl_pct"]),
        "EXIT_TTL_BARS":str(t["hold_bars"]),"HOLD_BARS":str(t["hold_bars"]),
        "TTL_BARS":str(t["hold_bars"]),"MAX_HOLD_BARS":str(t["hold_bars"]),
        "TRADE_HOLD_BARS":str(t["hold_bars"]),"SOT_HOLD_BARS":str(t["hold_bars"]),
        "TP_PCT":str(t["tp_pct"]),"SL_PCT":str(t["sl_pct"]),
        "EXIT_BE_ON":"1" if t["be_on"] else "0",
        "EXIT_BE_TRIGGER_PCT":str(t["be_trigger_pct"]),
        "EXIT_TRAIL_ON":"1" if t["trail_on"] else "0",
        "EXIT_TRAIL_START_PCT":str(t["trail_start_pct"]),
        "EXIT_TRAIL_GAP_PCT":str(t["trail_gap_pct"]),
    })
    # write mirrors
    for m in [Path("tmp/trade/conf/config.yml"), Path("tmp/trade/conf/config.effective.yml"),
              Path("conf/config.yml"), Path("config.yml"), Path("backtest/conf/config.yml")]:
        m.parent.mkdir(parents=True, exist_ok=True)
        m.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))
    Path("_out_4u/run").mkdir(parents=True, exist_ok=True)
    Path("_out_4u/run/exit_bridge_used.json").write_text(json.dumps({"trade":t}, indent=2))

if __name__=="__main__":
    main()

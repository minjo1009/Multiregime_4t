import numpy as np

def refine_entries(gate_prob):
    gp=np.asarray(gate_prob,float).reshape(-1)
    a=0.2; out=np.zeros_like(gp)
    for i,v in enumerate(gp): out[i]=a*v+(1-a)*(out[i-1] if i else v)
    return out

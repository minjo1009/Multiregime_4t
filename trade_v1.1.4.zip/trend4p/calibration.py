# -*- coding: utf-8 -*-
"""
Calibrator (v1.0.9 override) — engine compatible.
- Provides fit/transform/predict/predict_proba, preserving prior behavior.
- Uses IsotonicRegression when available; otherwise identity fallback.
- Outputs are clipped to [1e-6, 1-1e-6].
"""
from __future__ import annotations
import numpy as np
try:
    from sklearn.isotonic import IsotonicRegression as _Iso
except Exception:  # sklearn absent → no-op model
    class _Iso:
        def __init__(self, *a, **k): pass
        def fit(self, *a, **k): return self
        def transform(self, x):
            x = np.asarray(x, float).ravel()
            return x

class Calibrator:
    def __init__(self, method: str = "isotonic", by_session: bool = False, **kwargs):
        self.method = (method or "off").lower()
        self.by_session = bool(by_session)
        self.kwargs = dict(kwargs)
        self._m = None

    def _prep(self, y, p):
        y = np.asarray(y, float).ravel()
        p = np.asarray(p, float).ravel()
        m = np.isfinite(y) & np.isfinite(p)
        return y[m], p[m]

    def fit(self, y=None, p=None, **kw):
        # Accepts fit(y, p) OR fit(proba=..., target=...)
        if y is None and p is None:
            p = kw.get("proba") or kw.get("p")
            y = kw.get("target") or kw.get("y")
        if p is None or y is None:
            self._m = None
            return self
        y, p = self._prep(y, p)
        if y.size < 3:
            self._m = None
            return self
        if self.method in ("isotonic","iso"):
            self._m = _Iso(out_of_bounds="clip").fit(p, y)
        else:
            self._m = None  # extendable (e.g., Platt) without breaking API
        return self

    def transform(self, p):
        p = np.asarray(p, float).ravel()
        if self._m is None:
            out = p
        else:
            try:
                out = self._m.transform(p)
            except Exception:
                out = p
        out = np.asarray(out, float).ravel()
        return np.clip(out, 1e-6, 1-1e-6)

    # --- Engine compatibility ---
    def predict(self, p):
        return self.transform(p)

    def predict_proba(self, p):
        return self.transform(p)

    def __call__(self, p):
        return self.transform(p)

    def fit_transform(self, y, p, **kw):
        return self.fit(y=y, p=p, **kw).transform(p)

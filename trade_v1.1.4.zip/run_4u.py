from backtest.loader_sot import load_effective_config
import os, sys
sys.path.insert(0, os.path.abspath('.'))
sys.path.insert(0, os.path.abspath('./backtest'))
try:
    import backtest.engine as _E
    print(f"[engine] using {_E.__file__}")
except Exception as e:
    print('[engine] import failed:', e)

import argparse, os
from backtest.runner import run_backtest
from backtest.loader_sot import load_effective_config
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--data_path', required=True)
    ap.add_argument('--config', default='conf/config.yml')
    ap.add_argument('--out_dir', default='_out_4u/run')
    args=ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    run_backtest(args.data_path, args.config, args.out_dir)
if __name__=='__main__':
    main()
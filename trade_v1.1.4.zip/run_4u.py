
# Thin wrapper to invoke the unified runner
from runner import main
if __name__ == "__main__":
    main()

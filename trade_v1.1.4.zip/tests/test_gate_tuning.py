import numpy as np, pandas as pd
from backtest.gate_tuning import auto_thresholds_by_session

def test_quantile_target_window():
    g = pd.Series(np.r_[np.linspace(0,1,1000)])
    s = pd.Series(["ASIA"]*1000, dtype="category")
    thr, cov = auto_thresholds_by_session(g, s, 0.03, 0.08)
    c = cov.get("ASIA", 0.0)
    assert 0.01 <= c <= 0.15

def test_constant_fallback():
    g = pd.Series(np.ones(1000)*0.1)
    s = pd.Series(["US"]*1000, dtype="category")
    thr, cov = auto_thresholds_by_session(g, s, 0.03, 0.08)
    assert cov["US"] >= 0.0

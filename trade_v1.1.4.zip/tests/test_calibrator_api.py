import numpy as np
from trend4p.calibration import Calibrator

def test_calibrator_api():
    c = Calibrator(method="isotonic").fit([0,1,1,0],[0.1,0.85,0.9,0.2])
    x = [0.2,0.5,0.8]
    for fn in ("transform","predict","predict_proba"):
        y = getattr(c, fn)(x)
        arr = np.asarray(y, float)
        assert arr.shape[0] == 3
        assert np.isfinite(arr).all()
        assert (arr >= 0).all() and (arr <= 1).all()

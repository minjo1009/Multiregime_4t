
import os, json
import numpy as np
import pandas as pd

from .regime import analyze as regime_analyze
from .structure import signals as structure_signals
from .oflow import features as oflow_features
from .entry import combine_edges, decide
from .state import run_state_engine
from ..utils import ema

def macd(price, fast=12, slow=26, signal=9):
    fast_ = ema(price, fast); slow_=ema(price, slow)
    macd_line = fast_ - slow_; signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

class StrategyV2:
    def __init__(self, params_path: str, outdir: str):
        import yaml
        with open(params_path,'r') as f:
            self.params = yaml.safe_load(f)
        self.outdir = outdir
        os.makedirs(outdir, exist_ok=True)

    def run(self, df: pd.DataFrame):
        req = ['open_time','open','high','low','close','volume','number_of_trades','taker_buy_base_asset_volume']
        for c in req:
            if c not in df.columns:
                raise ValueError(f'Missing column: {c}')
        reg = regime_analyze(df, self.params.get('regime',{}))
        macd_line, sig, hist = macd(df['close'].to_numpy(float), **self.params.get('macd',{'fast':12,'slow':26,'signal':9}))
        ofl = oflow_features(df, self.params.get('orderflow',{}))
        levels = {'PDH':reg['PDH'], 'PDL':reg['PDL'], 'VAH':reg['VAH'], 'VAL':reg['VAL']}
        struct = structure_signals(df, levels, self.params.get('structure',{}))

        trend_state = reg['trend_state']  # 1=trend, -1=range, 0=neutral

        # --- Vectorized, mode-safe scoring ---
        weights = self.params.get('weights', {})
        score_tr = combine_edges('trend', hist, ofl['OFI'], ofl['AggBuy'], ofl['AggSell'], struct, reg, weights)
        score_rg = combine_edges('range', hist, ofl['OFI'], ofl['AggBuy'], ofl['AggSell'], struct, reg, weights)
        score = np.where(trend_state==1, score_tr, np.where(trend_state==-1, score_rg, 0.0))

        # --- Mode-specific gating on their own scores ---
        gp = self.params.get('gate',{})
        p_thr_tr = self.params.get('entry',{}).get('p_thr',{}).get('trend',0.6)
        p_thr_rg = self.params.get('entry',{}).get('p_thr',{}).get('range',0.55)

        p_tr, _ = decide('trend', score_tr, gp.get('trend',{'a':1.3,'thr':0.1,'beta':1.2,'of_shift':0.0}), p_thr_tr)
        p_rg, _ = decide('range', score_rg, gp.get('range',{'a':1.0,'thr':0.05,'beta':1.4,'of_shift':0.0}), p_thr_rg)

        p = np.where(trend_state==1, p_tr, np.where(trend_state==-1, p_rg, 0.0))
        thr = np.where(trend_state==1, p_thr_tr, np.where(trend_state==-1, p_thr_rg, 1.0))
        signal_long = (p >= thr).astype(int)

        # --- State engine ---
        a = reg['atr']
        tp=self.params.get('exit',{}).get('tp_atr',0.8)
        sl=self.params.get('exit',{}).get('sl_atr',0.5)
        trail=self.params.get('exit',{}).get('trail_atr',1.2)
        min_hold=self.params.get('exit',{}).get('min_hold',3)
        max_hold=self.params.get('exit',{}).get('max_hold',60)
        be_after=self.params.get('exit',{}).get('be_after_atr',0.5)

        pnl, side_arr, exit_reason = run_state_engine(
            df['close'].to_numpy(float), df['high'].to_numpy(float), df['low'].to_numpy(float),
            signal_long, a, tp, sl, trail, min_hold, max_hold, be_after
        )

        preds = pd.DataFrame({'open_time':df['open_time'], 'signal': side_arr, 'score': score, 'gatep': p})
        preds.to_csv(os.path.join(self.outdir,'preds_test.csv'), index=False)

        trades = pd.DataFrame({
            'open_time': df['open_time'],
            'side': side_arr,
            'price': df['close'],
            'qty': 1.0
        })
        trades.to_csv(os.path.join(self.outdir,'trades.csv'), index=False)

        summary = {
            'n': int(len(df)),
            'cum_pnl_close_based': float(pnl.sum()),
            'avg_gatep': float(np.mean(p)),
            'trend_frac': float(np.mean(trend_state==1)),
            'range_frac': float(np.mean(trend_state==-1))
        }
        with open(os.path.join(self.outdir,'summary.json'),'w') as f:
            json.dump(summary, f, indent=2)
        with open(os.path.join(self.outdir,'gating_debug.json'),'w') as f:
            json.dump({'entry_thr_trend': p_thr_tr, 'entry_thr_range': p_thr_rg}, f, indent=2)
        return summary

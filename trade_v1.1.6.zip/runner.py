#!/usr/bin/env python3
# runner.py — v1.1.6 bridge runner (keeps CLI compatibility)
from __future__ import annotations
import os, sys, json, argparse, pathlib, subprocess

ROOT = pathlib.Path(__file__).resolve().parent
OUT_DFLT = ROOT/"_out_4u"/"run"
CONF = ROOT/"conf"/"config.yml"
CONF_EFF = ROOT/"conf"/"config.effective.yml"

def ensure(p: pathlib.Path):
    p.mkdir(parents=True, exist_ok=True)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--out_dir", default=str(OUT_DFLT))
    ap.add_argument("--config", default=str(CONF))
    a = ap.parse_args()

    out = pathlib.Path(a.out_dir); ensure(out)
    os.environ.setdefault("PYTHONPATH", str(ROOT))

    # 1) preflight (strict)
    subprocess.check_call([sys.executable, "scripts/preflight_strict.py", a.data_path], cwd=str(ROOT))

    # 2) effective config bridge
    subprocess.call([sys.executable, "backtest/exit_bridge.py"], cwd=str(ROOT))
    cfg = str(CONF_EFF if CONF_EFF.exists() else CONF)

    # 3) engine via adapter (preferred) with fallback
    try:
        from backtest.engine_adapter import run_backtest
        run_backtest(a.data_path, cfg, str(out))
    except Exception as e:
        sys.stderr.write(f"[runner] engine failed: {e}\n→ fallback\n")
        subprocess.call([sys.executable, "backtest/run_v108.py", "--data_path", a.data_path, "--out_dir", str(out)], cwd=str(ROOT))

    # 4) artifacts minimum
    gd = out/"gating_debug.json"
    if not gd.exists(): gd.write_text(json.dumps({"_note":"fallback stub"}, ensure_ascii=False, indent=2), encoding="utf-8")
    sj = out/"summary.json"
    if not sj.exists(): sj.write_text(json.dumps({"status":"fallback"}, ensure_ascii=False, indent=2), encoding="utf-8")

if __name__ == "__main__":
    main()

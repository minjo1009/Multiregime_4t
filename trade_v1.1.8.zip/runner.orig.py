
import os, sys, json, hashlib, inspect, glob
from pathlib import Path

LOG_PREFIX = "[runner-1.1.4-core-v6]"
def _log(msg): print(f"{LOG_PREFIX} {msg}", flush=True)

def _read_yaml(p: Path):
    import yaml
    return yaml.safe_load(p.read_text()) if p.exists() else {}

def _write_yaml(p: Path, data: dict):
    import yaml
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(yaml.safe_dump(data, sort_keys=False))

def _sha256(p: Path):
    import hashlib
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()

def _coerce_int(x, default=0):
    try:    return int(str(x).strip())
    except: return default

def _merge_exit_overrides(cfg: dict, env: dict) -> int:
    ttl = None
    for k in ("EXIT_TTL", "EXIT_TTL_BARS", "TTL", "TTL_BARS"):
        v = env.get(k)
        if v is not None and str(v).strip() != "":
            ttl = _coerce_int(v, 0); break
    if ttl is None: ttl = 0
    if "exit" not in cfg: cfg["exit"] = {}
    cfg["exit"]["ttl"] = ttl
    return ttl

def _find_trades_candidate(out_dir: Path):
    candidates = [
        out_dir/"trades.csv",
        Path("trades.csv"),
        Path("out")/"trades.csv",
        Path("backtest")/"out"/"trades.csv",
        Path("outputs")/"trades.csv",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None

def _discover_csv():
    # env explicit
    p = os.getenv("CSV_PATH")
    if p and Path(p).exists():
        return Path(p)
    # glob under CSV_ROOT or tmp/data
    root = Path(os.getenv("CSV_ROOT", "tmp/data"))
    glob_pat = os.getenv("CSV_GLOB", "**/*.csv")
    cands = [Path(x) for x in glob.glob(str(root/ glob_pat), recursive=True)]
    cands = [c for c in cands if c.is_file() and "__MACOSX" not in str(c)]
    if cands:
        # pick first stable order
        return sorted(cands)[0]
    # final fallback
    p = root/"data.csv"
    return p

def _discover_cfg():
    # env
    p = os.getenv("CONFIG_PATH")
    if p and Path(p).exists(): return Path(p)
    # usual places (prefer effective)
    for cand in [
        Path("tmp/trade/conf/config.effective.yml"),
        Path("tmp/trade/conf/config.yml"),
        Path("conf/config.effective.yml"),
        Path("conf/config.yml"),
    ]:
        if cand.exists(): return cand
    return Path("tmp/trade/conf/config.effective.yml")

def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", "--data", dest="data_path", required=False)
    ap.add_argument("--config", dest="config", required=False)
    ap.add_argument("--out_dir", default=os.getenv("OUT_DIR", "_out_4u"))
    args, unknown = ap.parse_known_args()

    # Auto-discover when missing
    data_path = Path(args.data_path) if args.data_path else _discover_csv()
    cfg_path  = Path(args.config)    if args.config    else _discover_cfg()
    out_dir   = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    _log(f"RUN -> {__file__} args: {vars(args)} unknown={unknown}")
    _log(f"resolved data_path={data_path} exists={data_path.exists()}")
    _log(f"resolved config={cfg_path} exists={cfg_path.exists()}")
    _log(f"resolved out_dir={out_dir}")

    if not data_path.exists():
        raise FileNotFoundError(f"data_path not found: {data_path}")
    if not cfg_path.exists():
        raise FileNotFoundError(f"config not found: {cfg_path}")

    cfg = _read_yaml(cfg_path)
    ttl = _merge_exit_overrides(cfg, os.environ)
    _write_yaml(cfg_path, cfg)
    _log(f"wrote {cfg_path} with exit.ttl={ttl}")
    if ttl <= 0:
        _log(f"overlay TTL skipped (ttl={ttl})")

    # Import engine
    try:
        import backtest.engine as engine
    except Exception as e:
        raise ImportError(f"failed to import backtest.engine: {e}")

    if not hasattr(engine, 'run_backtest'):
        raise ImportError("backtest.engine.run_backtest not found")

    fn = engine.run_backtest
    import inspect as _insp
    sig = _insp.signature(fn)
    kwargs = {}
    if "data_path" in sig.parameters: kwargs["data_path"] = str(data_path)
    if "config_path" in sig.parameters: kwargs["config_path"] = str(cfg_path)
    if "out_dir" in sig.parameters: kwargs["out_dir"] = str(out_dir)
    _log(f"engine entry: {fn.__name__}{sig} kwargs={kwargs}")

    try:
        if kwargs:
            ret = fn(**kwargs)
        else:
            try:
                ret = fn(str(data_path), str(cfg_path), str(out_dir))
            except TypeError:
                ret = fn(str(data_path), str(cfg_path))
    except Exception as e:
        _log(f"engine raised: {e!r}")
        raise

    _log(f"engine returned: {ret!r}")

    cand = _find_trades_candidate(out_dir)
    if not cand:
        _log("trades.csv not found in expected; sweeping...")
        for p in [out_dir, Path("backtest"), Path("."), Path("out"), Path("outputs")]:
            maybe = list(p.rglob("trades.csv"))
            if maybe: cand = maybe[0]; break

    if not cand or not cand.exists():
        _log("MISSING trades.csv after engine run")
        (out_dir/"_NO_TRADES").write_text("1")
        sys.exit(2)

    dst = out_dir/"trades.csv"
    if cand.resolve() != dst.resolve():
        dst.write_bytes(cand.read_bytes())
    sha = _sha256(dst)
    (out_dir/"trades.sha256").write_text(sha)
    _log(f"trades.csv ready -> {dst} sha={sha}")

if __name__ == "__main__":
    main()

Multiregime Strategy — Trade Pack v1.1.4
========================================
Changes (vs 1.1.3.3):
- Runner now prefers tmp/trade/conf/config.effective.yml (fix: TTL/TP/SL/fees not applied by engine when only config.yml was passed).
- Exit bridge writes both config.yml and config.effective.yml and mirrors ENV aliases (EXIT_TTL_BARS, HOLD_BARS, TTL_BARS, MAX_HOLD_BARS...).
- Safety TTL overlay on trades.csv to guarantee A != B in AB tests even if engine ignores TTL.
Artifacts:
- _out_4u/CONFIG_USED.txt — which config was used by engine.
- _out_4u/run/exit_bridge_used.json — values injected by bridge.
- _out_4u/run/ttl_enforced.json — post-hoc TTL enforcement report.
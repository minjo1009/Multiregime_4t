#!/usr/bin/env python3
import os, json, sys
from pathlib import Path
import pandas as pd
OUT = Path("_out_4u"); RUN = OUT/"run"
OUT.mkdir(parents=True, exist_ok=True); RUN.mkdir(parents=True, exist_ok=True)

ok = True; msgs = []

preds_path = OUT/"preds_test.csv"
trades_path = OUT/"trades.csv"
sum_path = OUT/"summary.json"
gdbg_path = RUN/"gating_debug.json"

# Basic presence
for p in [preds_path, trades_path, sum_path, gdbg_path]:
    if not p.exists() or (p.suffix=='.csv' and p.stat().st_size==0) or (p.suffix=='.json' and p.stat().st_size<3):
        ok = False; msgs.append(f"missing_or_empty:{p}")

# Compute coverage if preds exist
coverage = None
try:
    if preds_path.exists() and preds_path.stat().st_size>0:
        df = pd.read_csv(preds_path)
        gate_col = next((c for c in df.columns if c.lower() in ("gate","is_open","open","signal")), None)
        if gate_col is not None:
            v = df[gate_col]
            if v.max()<=1.0 and v.min()>=0.0:
                coverage = float((v>0.5).mean())
            else:
                coverage = float((v>0).mean())
        else:
            msgs.append("no_gate_column")
            ok = False
except Exception as e:
    msgs.append(f"preds_error:{e}"); ok = False

# Guard
if coverage is not None and os.environ.get("COVERAGE_GUARD","true").lower() == "true":
    if coverage == 0.0:
        ok = False; msgs.append("coverage==0")

diag = {"ok": ok, "coverage": coverage, "msgs": msgs}
(RUN/"self_check_gate.json").write_text(json.dumps(diag, ensure_ascii=False, indent=2), encoding="utf-8")
print("[self_check_gate]", diag)
sys.exit(0 if ok else 2)

#!/usr/bin/env python3
from __future__ import annotations
import os, sys, json, argparse, pathlib, subprocess, traceback

ROOT = pathlib.Path(__file__).resolve().parent
RUN_DIR = ROOT
OUT_DIR_DEFAULT = ROOT / "_out_4u" / "run"
CONF_DIR = ROOT / "conf"
DEFAULT_CFG = CONF_DIR / "config.yml"
EFFECTIVE_CFG = CONF_DIR / "config.effective.yml"

STUB_CFG = """calibration:
  method: isotonic
coverage_target_min: 0.03
coverage_target_max: 0.08
gate:
  beta: 1.2
  temp: 10.0
costs:
  taker_bps: 7
  slippage_bps: 0
trade:
  hold_bars: 5
  tp_pct: 0.004
  sl_pct: 0.003
policy:
  allow_long: true
  allow_short: true
"""

def sh(cmd, cwd=None, allow_fail=False):
    try:
        subprocess.check_call(cmd, cwd=str(cwd) if cwd else None)
        return 0
    except subprocess.CalledProcessError as e:
        if allow_fail:
            return e.returncode
        raise

def ensure_dir(p: pathlib.Path):
    p.mkdir(parents=True, exist_ok=True)

def preflight(csv_path: str):
    code = sh([sys.executable, "scripts/preflight_strict.py", csv_path], cwd=RUN_DIR, allow_fail=True)
    if code != 0:
        print(f"[preflight] FAILED({code}) for {csv_path}", file=sys.stderr)
        sys.exit(64)

def make_effective_config():
    ensure_dir(CONF_DIR)
    bridge = RUN_DIR / "backtest" / "exit_bridge.py"
    if bridge.exists():
        try:
            subprocess.run([sys.executable, str(bridge)], cwd=str(RUN_DIR), check=False,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        except Exception:
            pass
    if not EFFECTIVE_CFG.exists():
        if DEFAULT_CFG.exists():
            EFFECTIVE_CFG.write_text(DEFAULT_CFG.read_text(), encoding="utf-8")
        else:
            EFFECTIVE_CFG.write_text(STUB_CFG, encoding="utf-8")
    print(f"[cfg] using {EFFECTIVE_CFG}")

def run_engine(csv_path: str, out_dir: pathlib.Path):
    os.environ.setdefault("PYTHONPATH", str(RUN_DIR))
    try:
        from backtest.engine_adapter import run_backtest
        cfg = str(EFFECTIVE_CFG if EFFECTIVE_CFG.exists() else DEFAULT_CFG)
        run_backtest(csv_path, cfg, str(out_dir))
        return True
    except Exception:
        traceback.print_exc()
        return False

def run_fallback(csv_path: str, out_dir: pathlib.Path):
    code = sh([sys.executable, "backtest/run_v108.py", "--data_path", csv_path, "--out_dir", str(out_dir)],
              cwd=RUN_DIR, allow_fail=True)
    return code == 0

def ensure_artifacts(out_dir: pathlib.Path):
    ensure_dir(out_dir)
    gd = out_dir / "gating_debug.json"
    if not gd.exists():
        gd.write_text(json.dumps({"_note":"fallback stub"}, ensure_ascii=False, indent=2), encoding="utf-8")
    sj = out_dir / "summary.json"
    if not sj.exists():
        sj.write_text(json.dumps({"status":"fallback","hit_rate":None,"mcc":None,"coverage_overall":None},
                                 ensure_ascii=False, indent=2), encoding="utf-8")

def _abs(p: str) -> str:
    try:
        return str(pathlib.Path(p).expanduser().resolve())
    except Exception:
        return p

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=False)
    ap.add_argument("--data_glob", required=False)
    ap.add_argument("--out_dir", required=False, default=str(OUT_DIR_DEFAULT))
    args = ap.parse_args()

    csv = args.data_path
    if not csv and args.data_glob:
        import glob
        cands = sorted(glob.glob(args.data_glob, recursive=True))
        if cands:
            csv = cands[0]
    if not csv:
        print("ERROR: no --data_path or --data_glob", file=sys.stderr)
        sys.exit(64)

    csv = _abs(csv)
    out_dir = pathlib.Path(args.out_dir).expanduser()
    ensure_dir(out_dir)

    preflight(csv)
    make_effective_config()

    ok = run_engine(csv, out_dir)
    if not ok:
        print("[engine] failed → fallback wrapper", file=sys.stderr)
        run_fallback(csv, out_dir)

    ensure_artifacts(out_dir)
    print(f"[done] outputs at {out_dir}")

if __name__ == "__main__":
    main()

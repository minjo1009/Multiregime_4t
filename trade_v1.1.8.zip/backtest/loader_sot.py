from pathlib import Path
import json, yaml

def load_effective_config():
    candidates = [
        Path("tmp/trade/conf/config.effective.yml"),
        Path("conf/config.effective.yml"),
        Path("conf/config.yml"),
    ]
    cfg = {"pricing":{}, "trading":{}, "gating":{}, "calibration":{}, "trade":{}, "gate":{}, "costs":{}}
    loaded_from = None
    for p in candidates:
        if p.exists():
            loaded_from = str(p)
            raw = yaml.safe_load(p.read_text()) or {}
            for k, v in raw.items():
                if isinstance(v, dict):
                    cfg.setdefault(k, {}).update(v)
                else:
                    cfg[k] = v
            break
    # normalize
    trade = cfg.setdefault("trade", {})
    trading = cfg.get("trading", {})
    if "tp_pct" not in trade and "tp_pct" in trading: trade["tp_pct"] = trading["tp_pct"]
    if "sl_pct" not in trade and "sl_pct" in trading: trade["sl_pct"] = trading["sl_pct"]
    gate = cfg.setdefault("gate", {})
    if "temp" not in gate:
        t = cfg.get("calibration", {}).get("temperature", None)
        if t is not None: gate["temp"] = t
    costs = cfg.setdefault("costs", {})
    if "taker_bps" not in costs:
        for k in ("fees_bps_per_leg","fee_bps_per_leg","per_leg_bps","fee_bps"):
            if k in cfg.get("pricing", {}):
                try:
                    costs["taker_bps"] = float(cfg["pricing"][k]); break
                except Exception:
                    pass
    costs["slippage_bps"] = float(costs.get("slippage_bps", 0.0))
    used = {
        "_loaded_from": loaded_from,
        "trade": {k: v for k, v in cfg.get("trade", {}).items() if k in [
            "tp_pct","sl_pct","hold_bars","be_on","be_trigger_pct",
            "trail_on","trail_start_pct","trail_gap_pct","atr_on"
        ]},
        "gate": {"temp": cfg.get("gate", {}).get("temp", None)},
        "gating": {"coverage_target": cfg.get("gating", {}).get("coverage_target", None)},
        "costs": cfg.get("costs", {}),
    }
    out = Path("_out_4u/run/used_config.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(used, ensure_ascii=False, indent=2))
    total_fee = (used["costs"].get("taker_bps",0) or 0) + (used["costs"].get("slippage_bps",0) or 0)
    print(f"[cfg] from={loaded_from} tp={used['trade'].get('tp_pct')} sl={used['trade'].get('sl_pct')} temp={used['gate'].get('temp')} fee_total_bps={total_fee}")
    return cfg

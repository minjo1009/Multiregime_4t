from pathlib import Path
import json, yaml

def load_effective_config():
    """
    Strategy-1 SOT loader (root-level backtest/).
    Prefer conf/config.effective.yml, normalize keys to:
      trade.tp_pct, trade.sl_pct, gate.temp, costs.taker_bps (+slippage_bps)
    Dump actually used subset to _out_4u/run/used_config.json
    """
    candidates = [
        Path("tmp/trade/conf/config.effective.yml"),
        Path("conf/config.effective.yml"),
        Path("conf/config.yml"),
    ]
    cfg = {"pricing":{}, "trading":{}, "gating":{}, "calibration":{}}
    loaded_from = None
    for p in candidates:
        if p.exists():
            loaded_from = str(p)
            raw = yaml.safe_load(p.read_text()) or {}
            for k, v in raw.items():
                if isinstance(v, dict):
                    cfg.setdefault(k, {}).update(v)
                else:
                    cfg[k] = v
            break

    trade = cfg.setdefault("trade", {})
    trading = cfg.get("trading", {})
    if "tp_pct" not in trade and "tp_pct" in trading:
        trade["tp_pct"] = trading["tp_pct"]
    if "sl_pct" not in trade and "sl_pct" in trading:
        trade["sl_pct"] = trading["sl_pct"]

    gate = cfg.setdefault("gate", {})
    if "temp" not in gate:
        temp = cfg.get("calibration", {}).get("temperature", None)
        if temp is not None:
            gate["temp"] = temp

    costs = cfg.setdefault("costs", {})
    fee_aliases = ("fees_bps_per_leg","fee_bps_per_leg","per_leg_bps","fee_bps")
    if "taker_bps" not in costs:
        pricing = cfg.get("pricing", {})
        for k in fee_aliases:
            if k in pricing:
                try:
                    costs["taker_bps"] = float(pricing[k]); break
                except Exception:
                    pass
    costs["slippage_bps"] = float(costs.get("slippage_bps", 0.0))

    out = Path("_out_4u/run/used_config.json")
    out.parent.mkdir(parents=True, exist_ok=True)
    used = {
        "_loaded_from": loaded_from,
        "trade": cfg.get("trade", {}),
        "gate": cfg.get("gate", {}),
        "costs": cfg.get("costs", {}),
    }
    out.write_text(json.dumps(used, ensure_ascii=False, indent=2))
    fee_total = used["costs"].get("taker_bps",0)+used["costs"].get("slippage_bps",0)
    print(f"[cfg] from={loaded_from} tp={used['trade'].get('tp_pct')} sl={used['trade'].get('sl_pct')} temp={used['gate'].get('temp')} fee_bps={fee_total}")
    return cfg

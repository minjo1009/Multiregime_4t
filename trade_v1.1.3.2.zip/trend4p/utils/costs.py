def estimate_costs(n_trades, fee_bps=2.0, slip_bps=1.0):
    bps=(fee_bps+slip_bps)
    return {'cost_bps': bps, 'est_total_bps': bps*max(0,int(n_trades))}

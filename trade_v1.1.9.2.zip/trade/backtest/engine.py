import pandas as pd, numpy as np
import pathlib, json, math, hashlib
from typing import Dict, Any

REQUIRED_COLS = ["open_time","open","high","low","close","volume"]

def _hash_dict(d: Dict[str, Any]) -> str:
    b = json.dumps(d, sort_keys=True).encode("utf-8")
    return hashlib.sha256(b).hexdigest()

def _session_bucket(ts: pd.Series) -> pd.Series:
    # Simple UTC session buckets by hour: US(13-20), EU(7-13), ASIA(0-6,20-24)
    h = ts.dt.hour
    us = (h>=13) & (h<20)
    eu = (h>=7)  & (h<13)
    asia = (~us) & (~eu)
    out = np.where(us, "US", np.where(eu, "EU", "ASIA"))
    return pd.Series(out, index=ts.index)

def _mcc_from_counts(tp, tn, fp, fn):
    den = math.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
    if den<=0: return None
    return (tp*tn - fp*fn) / den

def run_backtest(data_path: str, out_dir: str, cfg: Dict[str, Any], conf_sha: str = "", conf_path: str = "") -> Dict[str, Any]:
    out_dir = pathlib.Path(out_dir); out_dir.mkdir(parents=True, exist_ok=True)

    # ------------------ Load data ------------------
    df = pd.read_csv(data_path)
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise RuntimeError(f"missing required columns: {missing}")
    n_rows = int(len(df)-1 if len(df)>0 else 0)

    # time/index
    # open_time might be ms epoch or s epoch; try both
    otc = df["open_time"]
    ts = pd.to_datetime(otc, unit="ms", errors="coerce")
    if ts.isna().all():
        ts = pd.to_datetime(otc, unit="s", errors="coerce")
    df["_ts"] = ts

    # ------------------ Config ------------------
    tp = float(cfg.get("tp_pct", 0.003))
    sl = float(cfg.get("sl_pct", 0.0015))
    hold = int(cfg.get("hold_bars", 6))
    zwin = int(cfg.get("z_window", 288))
    thr_by_sess = (cfg.get("thr_by_session") or {"US":4.0,"EU":3.8,"ASIA":3.5})
    long_only = bool(cfg.get("long_only", False))
    pred_pos_means_long = bool(cfg.get("pred_pos_means_long", True))
    mcc_mode = str(cfg.get("mcc_mode","traded_bars"))
    mcc_sample = str(cfg.get("mcc_sample","traded_bars"))
    min_gap_bars = int(cfg.get("min_gap_bars", 0))
    xor_tp_sl = bool(cfg.get("xor_tp_sl", True))

    gating_debug = {"thr_by_session": thr_by_sess, "z_window": zwin}

    # ------------------ Simple signal model ------------------
    # Use rolling z-score of 1-bar return as a proxy predictor
    ret1 = df["close"].pct_change().fillna(0.0)
    mu = ret1.rolling(zwin, min_periods=max(10, zwin//10)).mean()
    sd = ret1.rolling(zwin, min_periods=max(10, zwin//10)).std(ddof=0).replace(0, np.nan)
    z = (ret1 - mu) / sd
    z = z.fillna(0.0)

    # session gate
    sess = _session_bucket(df["_ts"].fillna(method="ffill").fillna(method="bfill"))
    thr_s = sess.map(lambda s: thr_by_sess.get(s, 9999.0))
    gate = (np.abs(z) >= thr_s.values)

    # raw prediction: anticipate mean reversion breakout; here we just use z sign
    raw_pred = np.sign(z.values)  # +1 if z>0, -1 if z<0, 0 otherwise

    # direction mapping
    dir_mult = 1 if pred_pos_means_long else -1
    y_pred = raw_pred * dir_mult  # +1 LONG, -1 SHORT (if allowed)

    # ------------------ Trade construction (vector-ish) ------------------
    close = df["close"].values
    high = df["high"].values
    low  = df["low"].values

    # future max/min over next 'hold' bars (exclude current bar)
    # reverse rolling trick
    fmax = pd.Series(high[::-1]).rolling(hold, min_periods=1).max().values[::-1]
    fmin = pd.Series(low[::-1]).rolling(hold, min_periods=1).min().values[::-1]
    fmax = np.roll(fmax, -1); fmin = np.roll(fmin, -1)  # shift to start from next bar
    fmax[-1] = high[-1]; fmin[-1] = low[-1]

    long_entry  = (y_pred > 0) & gate
    short_entry = (y_pred < 0) & gate
    if long_only:
        short_entry[:] = False

    entries = np.where(long_entry | short_entry)[0]

    # apply min_gap_bars cooldown
    if min_gap_bars > 0 and entries.size>0:
        kept = []
        last = -10**9
        for i in entries:
            if i - last >= min_gap_bars:
                kept.append(i); last = i
        entries = np.array(kept, dtype=int)

    trade_side = []
    pnl_list = []
    idx_list = []

    for i in entries:
        if i>=len(close)-1:  # need at least one forward bar
            continue
        px = close[i]
        # horizon window summary (approximate ordering-agnostic)
        up_touch   = (fmax[i] >= px*(1+tp))
        down_touch = (fmin[i] <= px*(1-sl))
        if xor_tp_sl:
            if up_touch and down_touch:
                continue  # ambiguous; skip
            if not up_touch and not down_touch:
                continue  # no touch; skip
        # decide outcome by side
        if long_entry[i]:
            if up_touch and not down_touch:
                pnl = tp
            elif down_touch and not up_touch:
                pnl = -sl
            else:
                # fallback by sign of forward return at hold horizon
                j = min(i+hold, len(close)-1)
                pnl = (close[j]/px - 1.0)
            trade_side.append("LONG"); pnl_list.append(pnl); idx_list.append(i)
        elif short_entry[i]:
            if up_touch and not down_touch:
                pnl = -tp
            elif down_touch and not up_touch:
                pnl = sl
            else:
                j = min(i+hold, len(close)-1)
                pnl = (px/close[j] - 1.0)
            trade_side.append("SHORT"); pnl_list.append(pnl); idx_list.append(i)

    trades = pd.DataFrame({
        "idx": idx_list,
        "side": trade_side,
        "PnL": pnl_list,
    })
    n_trades = int(len(trades))

    # ------------------ Metrics ------------------
    hit_rate = float((trades["PnL"]>0).mean()) if n_trades>0 else None
    gains = trades.loc[trades["PnL"]>0, "PnL"].sum()
    losses = -trades.loc[trades["PnL"]<0, "PnL"].sum()
    profit_factor = float(gains/losses) if losses>0 else (None if n_trades==0 else float("inf"))

    # MCC
    # fwd return sign as truth on chosen sample
    ret_h = pd.Series(df["close"].shift(-hold)/df["close"] - 1.0)
    if mcc_mode == "trade_vs_not":
        # predict +1 where long entry condition (base gate without cooldown ambiguity)
        base_long_entry = (y_pred > 0) & gate
        if long_only:
            base_pred = np.where(base_long_entry, 1, -1)
        else:
            # both-direction case: predict +1 if long, -1 if short (non-entry=0→-1)
            base_pred = np.where(base_long_entry, 1, -1)
        if mcc_sample == "all_bars":
            mask = np.isfinite(ret_h.values)
        else:
            # traded bars only
            mask = np.zeros(len(df), dtype=bool)
            mask[np.array(idx_list, dtype=int)] = True
    else:
        # classic direction-vs-fwd sign
        if mcc_sample == "traded_bars":
            mask = np.zeros(len(df), dtype=bool)
            mask[np.array(idx_list, dtype=int)] = True
        else:
            mask = np.isfinite(ret_h.values)
        base_pred = np.sign(y_pred)

    y_true = np.where(ret_h.values>0, 1, -1)[mask]
    y_pred_bin = base_pred[mask]
    tp_c = int(((y_true== 1) & (y_pred_bin== 1)).sum())
    tn_c = int(((y_true==-1) & (y_pred_bin==-1)).sum())
    fp_c = int(((y_true==-1) & (y_pred_bin== 1)).sum())
    fn_c = int(((y_true== 1) & (y_pred_bin==-1)).sum())
    mcc = _mcc_from_counts(tp_c, tn_c, fp_c, fn_c)

    # ------------------ Write artifacts ------------------
    # trades.csv
    trades_path = pathlib.Path(out_dir) / "trades.csv"
    trades.to_csv(trades_path, index=False)

    # gating_debug.json
    gating = dict(gating_debug)
    gating["used_session_counts"] = dict(pd.value_counts(_session_bucket(df["_ts"].fillna(method="ffill").fillna(method="bfill"))))
    (pathlib.Path(out_dir) / "gating_debug.json").write_text(json.dumps(gating, indent=2))

    # summary.json
    summary = {
        "placeholders": False,
        "notes": "v1.1.9.2 engine",
        "n_rows": n_rows,
        "n_trades": n_trades,
        "hit_rate": hit_rate,
        "profit_factor": profit_factor,
        "tp_pct": tp, "sl_pct": sl, "hold_bars": hold,
        "mcc": mcc,
        "mcc_mode": mcc_mode,
        "mcc_sample": mcc_sample,
        "long_only": long_only,
        "pred_pos_means_long": pred_pos_means_long,
        "__config_sha256__": cfg.get("__config_sha256__", ""),
        "__engine_conf_sha__": _hash_dict({
            "tp_pct":tp,"sl_pct":sl,"hold_bars":hold,"z_window":zwin,
            "thr_by_session": thr_by_sess, "long_only": long_only,
            "pred_pos_means_long": pred_pos_means_long,
            "mcc_mode": mcc_mode, "mcc_sample": mcc_sample,
            "min_gap_bars": min_gap_bars, "xor_tp_sl": xor_tp_sl
        }),
    }
    (pathlib.Path(out_dir) / "summary.json").write_text(json.dumps(summary, indent=2))

    return {"summary": summary}

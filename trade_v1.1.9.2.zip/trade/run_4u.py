#!/usr/bin/env python3
import argparse, sys, json, os, hashlib, pathlib, traceback
from typing import Dict, Any

# Ensure local imports
THIS_DIR = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(THIS_DIR))

def sha256_of_file(p: pathlib.Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()

def load_yaml(p: pathlib.Path) -> Dict[str, Any]:
    import yaml
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def save_json(p: pathlib.Path, obj: Any):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, ensure_ascii=False))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data_path", required=True)
    ap.add_argument("--out_dir", required=True)
    args = ap.parse_args()

    out_dir = pathlib.Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    # config resolution: effective first then fallback
    conf_dir = THIS_DIR / "conf"
    effective = conf_dir / "config.effective.yml"
    fallback  = conf_dir / "config.yml"
    if effective.exists():
        conf_path = effective
    elif fallback.exists():
        conf_path = fallback
    else:
        print("[conf] no config file found", file=sys.stderr)
        sys.exit(75)  # config missing

    cfg = load_yaml(conf_path)
    conf_sha = sha256_of_file(conf_path)
    print(f"[conf] using {conf_path}")
    print(f"[conf] sha256={conf_sha}")

    # basic required columns check is delegated to engine as well, but preflight a bit:
    data_path = pathlib.Path(args.data_path)
    if not data_path.exists():
        print(f"[data] not found: {data_path}", file=sys.stderr); sys.exit(75)

    # load engine and run
    from backtest.engine import run_backtest
    try:
        res = run_backtest(str(data_path), str(out_dir), cfg, conf_sha=conf_sha, conf_path=str(conf_path))
    except Exception as e:
        tb = traceback.format_exc()
        err = {"error": str(e), "stack": tb}
        save_json(out_dir / "error.json", err)
        print("[engine] failed; no placeholders will be written", file=sys.stderr)
        sys.exit(78)

    # require metrics
    summary = res.get("summary") if isinstance(res, dict) else None
    if not summary or any(summary.get(k) is None for k in ["hit_rate","profit_factor","n_trades"]):
        print("[engine] missing core metrics; abort (no placeholders)", file=sys.stderr)
        save_json(out_dir / "error.json", {"reason":"missing core metrics"})
        sys.exit(78)

    # echo outputs
    print(f"[done] outputs at {out_dir}")
    return 0

if __name__ == "__main__":
    sys.exit(main())

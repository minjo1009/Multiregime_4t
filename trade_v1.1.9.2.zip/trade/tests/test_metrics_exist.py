import pandas as pd, numpy as np, pathlib, json
from trade.backtest.engine import run_backtest

def test_metrics_exist(tmp_path):
    n=1000
    df = pd.DataFrame({
        "open_time": np.arange(n)*60_000,
        "open": np.ones(n),
        "high": np.ones(n)*1.01,
        "low":  np.ones(n)*0.99,
        "close": 1+np.sin(np.linspace(0,30,n))*0.01,
        "volume": 1000,
    })
    csv = tmp_path/"x.csv"; df.to_csv(csv, index=False)
    out = tmp_path/"o"
    res = run_backtest(str(csv), str(out), {"tp_pct":0.003,"sl_pct":0.002,"hold_bars":6,"long_only":True,"pred_pos_means_long":False}, conf_sha="x")
    s = json.loads((out/"summary.json").read_text())
    for k in ["hit_rate","profit_factor","n_trades"]:
        assert s.get(k) is not None

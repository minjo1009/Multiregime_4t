import pandas as pd, tempfile, json, pathlib, os, sys
from trade.backtest.engine import run_backtest

def test_required_columns_guard(tmp_path):
    df = pd.DataFrame({"open_time":[0,1,2], "open":[1,1,1], "high":[1,1,1], "low":[1,1,1], "close":[1,1,1], "volume":[1,1,1]})
    csv = tmp_path/"d.csv"; df.to_csv(csv, index=False)
    out = tmp_path/"out"
    res = run_backtest(str(csv), str(out), {"tp_pct":0.01,"sl_pct":0.01,"hold_bars":1}, conf_sha="x")
    s = json.loads((out/"summary.json").read_text())
    assert s["n_rows"] == len(df)-1

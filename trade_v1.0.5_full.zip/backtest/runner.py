
import os, json, numpy as np, pandas as pd, yaml
from trend4p.data.feeds import load_kline_csv, label_future_return, add_session_cols
from trend4p.data.feature_basic import add_basic_features
from trend4p.feature_orderflow import compute_orderflow_features
from trend4p.regime_posterior import RegimePosterior, heuristic_prelabel
from trend4p.s1_dir_head import S1DirHeadMoE
from trend4p.s2_quantile_head import S2QuantileHead, quantiles_to_mu_sigma_es
from trend4p.sizing import fractional_kelly, vol_targeting

def load_cfg(path):
    with open(path,'r',encoding='utf-8') as f: return yaml.safe_load(f)

def run_backtest(data_path, cfg_path, out_dir):
    cfg=load_cfg(cfg_path)
    np.random.seed(cfg.get('seed',42))
    H=int(cfg['horizon_bars'])

    df=load_kline_csv(data_path)
    df=add_session_cols(df); df=add_basic_features(df)
    df=compute_orderflow_features(df, vpin_vol_k=cfg['vpin_bucket_mult'], vpin_m=cfg['vpin_m'], roll_lambda=cfg['lambda_roll'])
    df['y_ret']=label_future_return(df,H); df['y01']=(df['y_ret']>0).astype(int)

    # --- Regime posterior (cheap heuristic prelabel -> logistic)
    slow=['mom_15','rv_60','VPIN','lambda_kyle','ATS']
    pre=heuristic_prelabel(df[slow]); rp=RegimePosterior().fit(df[slow].fillna(0), pre); r_post=rp.predict_proba(df[slow].fillna(0))

    # --- Features for heads
    feat_cols=[c for c in df.columns if c.startswith('mom_') or c.startswith('rv_')] + ['DR','CVD_slope','VPIN','lambda_kyle','OFI_proxy','ATS','sess_ASIA','sess_EU','sess_US']
    X_all=df[feat_cols].fillna(0)

    # --- S1: directional probability (MoE + calibration)
    idx_tr=np.arange(len(df))[::int(cfg.get('train_stride',5))]
    s1=S1DirHeadMoE().fit(X_all.iloc[idx_tr], df['y01'].iloc[idx_tr], r_post[idx_tr])
    df['p_long']=s1.predict_proba(X_all, r_post)

    # --- S2: quantile head -> mu, sigma, ES
    s2=S2QuantileHead().fit(X_all.iloc[idx_tr], df['y_ret'].fillna(0).iloc[idx_tr], r_post[idx_tr])
    qdf=s2.predict_quantiles(X_all)
    mu,sigma,es=quantiles_to_mu_sigma_es(qdf, alpha=cfg['es_alpha'])
    df['mu']=mu; df['sigma']=sigma; df['es']=es

    # --- Costs
    cost_bps=cfg['fee_bps']+cfg['slip_bps_base']
    df['cost_bps']=cost_bps
    mu_net=df['mu']-cost_bps*1e-4

    # --- Gating v1 (soft-combo + session-wise ranking)
    lambda_tail=float(cfg.get('lambda_tail', 0.7))
    s1_pcut=float(cfg.get('s1_min_prob', 0.52))
    beta=float(cfg.get('s1_soft_power', 1.0))
    a=float(cfg.get('gate_logit_temp', 10.0))
    tmin=float(cfg.get('coverage_target_min', 0.03)); tmax=float(cfg.get('coverage_target_max', 0.08))
    target=(tmin+tmax)/2.0

    score_series = (mu_net - lambda_tail*df['es'].abs())
    eligible = (df['p_long'] >= s1_pcut)
    # S1-eligible 집합에서 세션별 분위수 thr
    thr_map = {}
    for s in ['ASIA','EU','US']:
        m = (df['session']==s) & eligible
        if m.any():
            thr_map[s] = float(np.quantile(score_series[m], 1.0 - target))
        else:
            thr_map[s] = float(np.quantile(score_series, 1.0 - target))
    thr = df['session'].map(thr_map).astype(float).values

    logit = 1.0/(1.0+np.exp(-a*(score_series.values - thr)))
    gate_prob = logit * (np.power(df['p_long'].values, beta))

    # Session-wise ranking to exact coverage
    df['gate_prob']=gate_prob
    rank_pct = df.groupby('session')['gate_prob'].rank(pct=True, method='first')
    gate = (rank_pct >= (1.0 - target)).astype(float) * eligible.astype(float)

    # Save debug
    cov_all = float((gate>0.5).mean()); cov_by_sess = df.groupby('session').apply(lambda g: float((g['gate']>0.5).mean())).to_dict()
    df['score']=score_series.values; df['gate']=gate

    # --- sizing
    size=fractional_kelly(df['mu'].values, np.maximum(1e-6,df['sigma'].values), frac=cfg['kelly_fraction'])
    df['size']=vol_targeting(size, np.maximum(1e-6,df['sigma'].values), target_vol=0.02)

    # --- simulate
    from trend4p.executor.sim_exec import simulate_trades
    preds,tlog = simulate_trades(df,H,cost_bps)

    if 'cost_bps' not in preds.columns: preds['cost_bps']=cost_bps
    micro = preds.reindex(columns=['ts','VPIN','lambda_kyle','ATS']).copy()
    costs = preds.reindex(columns=['ts','cost_bps']).copy()

    by_bucket=preds.groupby('session').agg(trades=('gate', lambda s:(s>0.5).sum()), hit=('ret_fut', lambda r: float((r[preds.loc[r.index,'gate']>0.5]>0).mean()) if (preds.loc[r.index,'gate']>0.5).sum()>0 else 0), pnl_net=('pnl','sum')).reset_index()

    meta={'algo_version':'trade_v1.0.5','cfg':cfg,'data_span':f"{str(preds['ts'].iloc[0])}~{str(preds['ts'].iloc[-1])}",'horizon_bars':H}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir,'gating_debug.json'),'w',encoding='utf-8') as fdbg:
        import json; json.dump({'target':target,'thr_by_session':thr_map,'cov_overall':cov_all,'cov_by_session':cov_by_sess,'s1_pcut':s1_pcut,'beta':beta}, fdbg, indent=2)

    preds.to_csv(os.path.join(out_dir,'preds_test.csv'), index=False); tlog.to_csv(os.path.join(out_dir,'trades.csv'), index=False)
    return preds, tlog, micro, costs, by_bucket, meta

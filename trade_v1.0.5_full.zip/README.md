
# trade_v1.0.5 (full)
**Strategy v1 alignment**: soft-combo gating (logit × S1 prob^β) + session-wise ranking to target coverage, and S1-conditional quantile threshold. Includes orderflow features and MoE heads.

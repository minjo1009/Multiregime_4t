
from dataclasses import dataclass
import pandas as pd, numpy as np, os, json, matplotlib.pyplot as plt
@dataclass
class RunCtx:
    cfg: dict; preds: pd.DataFrame; trades: pd.DataFrame; micro: pd.DataFrame; costs: pd.DataFrame; by_bucket: pd.DataFrame
def compute_basic(ctx):
    d=ctx.preds; mask=(d['gate']>0.5)
    trades=int(mask.sum())
    return {'trades':trades,'win_rate': float(((mask)&(d['ret_fut']>0)).mean()) if trades>0 else 0.0,
            'cum_return': float(d.loc[mask,'pnl'].sum() if 'pnl' in d.columns else 0.0),
            'avg_trade_gross': float(d.loc[mask,'ret_fut'].mean() if trades>0 else 0.0),
            'avg_trade_net': float(d.loc[mask,'pnl'].mean() if trades>0 and 'pnl' in d.columns else 0.0)}
def compute_s1(ctx):
    d=ctx.preds[['p_long','y01']].dropna()
    if len(d)==0: return {'brier':1.0,'ece':1.0,'rel_slope':0.0,'rel_intercept':0.0}
    d['bin']=pd.qcut(d['p_long'], q=10, labels=False, duplicates='drop')
    rel=d.groupby('bin').agg(p=('p_long','mean'), y=('y01','mean')).reset_index(drop=True)
    ece=float(np.abs(rel['p']-rel['y']).mean()); brier=float(((d['p_long']-d['y01'])**2).mean())
    a=np.polyfit(rel['p'], rel['y'], 1); return {'brier':brier,'ece':ece,'rel_slope':float(a[0]),'rel_intercept':float(a[1])}
def compute_s2(ctx):
    d=ctx.preds[['mu','ret_fut']].dropna()
    if len(d)==0: return {'rank_ic_topk':0.0,'decile_pnl':[],'es_coverage':0.0}
    ic=float(pd.Series(d['mu']).rank().corr(pd.Series(d['ret_fut']), method='spearman'))
    d['dec']=pd.qcut(d['mu'],10,labels=False,duplicates='drop'); pnl=d.groupby('dec')['ret_fut'].mean().tolist()
    es_cov=float((ctx.preds['ret_fut']<=ctx.preds['es']).mean()); return {'rank_ic_topk':ic,'decile_pnl':pnl,'es_coverage':es_cov}
def compute_coverage(ctx):
    tmin=ctx.cfg['cfg'].get('coverage_target_min',0.03); tmax=ctx.cfg['cfg'].get('coverage_target_max',0.08)
    cov=float((ctx.preds['gate']>0.5).mean()); 
    cov_by = ctx.preds.groupby('session').apply(lambda g: float((g['gate']>0.5).mean())).to_dict()
    return {'target':[tmin,tmax], 'actual': cov, 'by_session': cov_by}
def compute_costs(ctx):
    fees=float(ctx.preds['cost_bps'].mean()) if 'cost_bps' in ctx.preds else 3.0
    return {'fee_bps': fees-1.5, 'slip_bps': 1.0, 'spread_bps': 0.5,
            'impact_lambda': float(ctx.micro['lambda_kyle'].median() if 'lambda_kyle' in ctx.micro else 0.0)}
def save_report(ctx, out_dir):
    basic=compute_basic(ctx); s1=compute_s1(ctx); s2=compute_s2(ctx); cov=compute_coverage(ctx); costs=compute_costs(ctx)
    micro={'vpin_p95': float(ctx.micro['VPIN'].quantile(0.95) if 'VPIN' in ctx.micro else 0.0),
           'lambda_p95': float(ctx.micro['lambda_kyle'].quantile(0.95) if 'lambda_kyle' in ctx.micro else 0.0),
           'ats_p95': float(ctx.micro['ATS'].quantile(0.95) if 'ATS' in ctx.micro else 0.0)}
    flags=[]; 
    if s1['brier']>0.24 or abs(s1['rel_slope']-1.0)>0.1: flags.append('S1_CALIB_BAD')
    if -0.02<=s2['rank_ic_topk']<=0.02: flags.append('S2_RANK_WEAK')
    if cov['actual']<cov['target'][0]: flags.append('COVERAGE_LOW')
    if cov['actual']>cov['target'][1]: flags.append('COVERAGE_HIGH')
    summary={'run_meta':{'algo_version':'trade_v1.0.5'}, 'basic':basic,'s1':s1,'s2':s2,'gate_coverage':cov,'costs':costs,'micro':micro,'bottlenecks':flags, 'cfg': ctx.cfg}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir,'summary.json'),'w') as f: import json; json.dump(summary,f,indent=2)
    import matplotlib.pyplot as plt
    os.makedirs(os.path.join(out_dir,'charts'), exist_ok=True)
    plt.figure(figsize=(8,3)); plt.plot(ctx.preds['pnl'].fillna(0).cumsum().values); plt.title('Cumulative PnL'); plt.tight_layout(); plt.savefig(os.path.join(out_dir,'charts','cum_pnl.png'))
    cov_series=(ctx.preds['gate']>0.5).rolling(500).mean(); plt.figure(figsize=(8,3)); plt.plot(cov_series.values); 
    tmin,tmax=cov['target']; plt.axhspan(tmin,tmax, alpha=0.1); plt.title('Rolling Coverage'); plt.tight_layout(); plt.savefig(os.path.join(out_dir,'charts','coverage.png'))

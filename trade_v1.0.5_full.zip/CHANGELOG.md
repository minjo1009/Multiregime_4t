
## 1.0.5
- Gating now **soft-combo**: `gate_prob = σ(a*(score - thr)) * p_long^β`.
- **Session-wise ranking** to hit target coverage (3~8%) instead of global fixed threshold.
- **S1-conditional quantile** for thr estimation (use only S1-eligible points).
- Keep coverage debug file with per-session coverage before/after.
- No simplification of S1/S2 feature set. Sklearn 1.4/1.5 compatible.

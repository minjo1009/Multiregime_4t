
import numpy as np, pandas as pd
def add_basic_features(df):
    out = df.copy()
    for w in [1,3,5,10,15]: out[f'mom_{w}'] = np.log(out['close']/out['close'].shift(w))
    for w in [10,30,60,120]: out[f'rv_{w}'] = out['ret1'].rolling(w).std()*np.sqrt(60)
    return out

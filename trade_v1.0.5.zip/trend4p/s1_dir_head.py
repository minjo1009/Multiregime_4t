
import numpy as np, pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
class S1DirHeadMoE:
    def __init__(self, method: str = 'isotonic', cv: int = 3):
        self.models = {}; self.method = method; self.cv = cv
    def fit(self, X, y, r_post):
        K = r_post.shape[1]
        for k in range(K):
            w = np.clip(r_post[:, k], 0.0, 0.95)
            base = LogisticRegression(max_iter=500, class_weight='balanced')
            try:
                cal = CalibratedClassifierCV(estimator=base, method=self.method, cv=self.cv)
            except TypeError:
                cal = CalibratedClassifierCV(base_estimator=base, method=self.method, cv=self.cv)
            cal.fit(X, y, sample_weight=w)
            self.models[k] = cal
        return self
    def predict_proba(self, X, r_post):
        pk = []
        for k in range(len(self.models)):
            p = self.models[k].predict_proba(X)[:, 1]
            pk.append(p)
        pk = np.stack(pk, axis=1)
        return (r_post * pk).sum(axis=1)

import numpy as np

def sigmoid(x):
    return 1.0/(1.0 + np.exp(-x))

def soft_gate(s, thr=0.0, a=1.0, of_shift=0.0, beta=1.0):
    # s: raw score
    pg = sigmoid(a*(s - thr) + of_shift)
    return np.power(pg, beta)

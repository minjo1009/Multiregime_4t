import numpy as np

def swing_points(series, left=3, right=3):
    pts = []
    for i in range(left, len(series)-right):
        window_left = series[i-left:i]
        window_right = series[i+1:i+1+right]
        if series[i] == max(np.r_[window_left, [series[i]], window_right]):
            pts.append((i, 'H'))
        elif series[i] == min(np.r_[window_left, [series[i]], window_right]):
            pts.append((i, 'L'))
    return pts

def find_divergence(price, osc, lookback=120):
    # Return simple divergence score in [-1,1]
    pts_p = swing_points(price, 3, 3)
    pts_o = swing_points(osc, 3, 3)
    score = np.zeros_like(price, dtype=float)
    for i in range(len(price)):
        if i<10: 
            continue
        # find last two pivots in price and osc
        piv_p = [p for p in pts_p if p[0] < i][-2:]
        piv_o = [p for p in pts_o if p[0] < i][-2:]
        if len(piv_p)==2 and len(piv_o)==2:
            # bear divergence: price HH, osc LH
            if piv_p[-2][1]=='H' and piv_p[-1][1]=='H' and price[piv_p[-1][0]]>price[piv_p[-2][0]] and osc[piv_o[-1][0]]<osc[piv_o[-2][0]]:
                score[i] -= 1.0
            # bull divergence: price LL, osc HL
            if piv_p[-2][1]=='L' and piv_p[-1][1]=='L' and price[piv_p[-1][0]]<price[piv_p[-2][0]] and osc[piv_o[-1][0]]>osc[piv_o[-2][0]]:
                score[i] += 1.0
    # smooth
    for k in range(1,5):
        score[k:] = 0.5*score[k:] + 0.5*score[:-k]
    score = np.clip(score, -1.0, 1.0)
    return score

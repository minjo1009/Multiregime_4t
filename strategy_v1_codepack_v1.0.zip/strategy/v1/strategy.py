import os, json
import numpy as np
import pandas as pd
from .wavelet_macd import macd
from .divergence import find_divergence
from .gating import soft_gate

class StrategyV1:
    def __init__(self, params_path: str, outdir: str):
        self.params = self._load_params(params_path)
        self.outdir = outdir
        os.makedirs(outdir, exist_ok=True)

    def _load_params(self, path: str) -> dict:
        try:
            import yaml
            with open(path, 'r') as f:
                return yaml.safe_load(f)
        except Exception:
            # minimal defaults
            return {
                'denoise': {'method':'wavelet','level':1,'fallback':'ema','ema_span':5},
                'macd': {'fast':12,'slow':26,'signal':9},
                'gate': {'thr':0.0,'a':1.0,'of_shift':0.0,'beta':1.0},
                'hold': 6,
                'risk': {'tp':0.0038,'sl':0.0022, 'be':0},
            }

    def run(self, df: pd.DataFrame):
        req = ["open_time","open","high","low","close","volume"]
        for c in req:
            if c not in df.columns:
                raise ValueError(f"Missing column: {c}")
        close = df['close'].to_numpy(dtype=float)
        macd_line, sig, hist = macd(close, **self.params.get('macd',{}), denoise=self.params.get('denoise',None))
        div = find_divergence(close, macd_line)
        raw = hist + 0.2*div
        gatep = soft_gate(raw, **self.params.get('gate',{}))
        signal = np.where(gatep>=0.5, 1, -1)  # basic long/short flip
        # write preds
        preds = pd.DataFrame({
            'open_time': df['open_time'],
            'signal': signal,
            'score': raw,
            'gatep': gatep
        })
        preds.to_csv(os.path.join(self.outdir,'preds_test.csv'), index=False)
        # naive trades stream (one per bar)
        trades = pd.DataFrame({
            'open_time': df['open_time'],
            'side': signal,
            'price': df['close'],
            'qty': 1.0
        })
        trades.to_csv(os.path.join(self.outdir,'trades.csv'), index=False)
        # summary
        ret = pd.Series(close).pct_change().shift(-1).fillna(0.0).to_numpy()
        pnl = float((ret*signal).sum())
        summ = {'n': int(len(df)), 'cum_pnl': pnl, 'gate_mean': float(np.mean(gatep)), 'macd_params': self.params.get('macd',{})}
        with open(os.path.join(self.outdir,'summary.json'),'w') as f:
            json.dump(summ, f, indent=2)
        with open(os.path.join(self.outdir,'gating_debug.json'),'w') as f:
            json.dump({'thr': self.params.get('gate',{}).get('thr',0.0)}, f, indent=2)
        return summ

import numpy as np

def ema(x, span):
    alpha = 2.0/(span+1.0)
    y = np.zeros_like(x, dtype=float)
    s = 0.0
    for i, v in enumerate(x):
        s = v if i==0 else (alpha*v + (1-alpha)*s)
        y[i] = s
    return y

def try_wavelet_denoise(arr, level=1):
    try:
        import pywt
        coeffs = pywt.wavedec(arr, 'db2', mode='periodization', level=level)
        sigma = np.median(np.abs(coeffs[-1]))/0.6745 + 1e-9
        uth = sigma*np.sqrt(2*np.log(len(arr)))
        coeffs = [coeffs[0]] + [pywt.threshold(c, value=uth, mode='soft') for c in coeffs[1:]]
        rec = pywt.waverec(coeffs, 'db2', mode='periodization')
        rec = rec[:len(arr)]
        return rec
    except Exception:
        return None

def macd(price, fast=12, slow=26, signal=9, denoise=None):
    src = price.astype(float)
    if denoise:
        rec = try_wavelet_denoise(src, level=denoise.get('level',1)) if denoise.get('method','wavelet')=='wavelet' else None
        if rec is None and denoise.get('fallback','ema')=='ema':
            rec = ema(src, denoise.get('ema_span', 5))
        src = rec if rec is not None else src
    fast_ema = ema(src, fast)
    slow_ema = ema(src, slow)
    macd_line = fast_ema - slow_ema
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

import numpy as np

def mcc(y_true, y_pred):
    # y in {-1,1}
    y_true = np.asarray(y_true); y_pred = np.asarray(y_pred)
    tp = np.sum((y_true==1) & (y_pred==1))
    tn = np.sum((y_true==-1) & (y_pred==-1))
    fp = np.sum((y_true==-1) & (y_pred==1))
    fn = np.sum((y_true==1) & (y_pred==-1))
    num = tp*tn - fp*fn
    den = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)) + 1e-9
    return float(num/den)

import argparse, json, os, glob
import pandas as pd
from strategy.v1.strategy import StrategyV1

def find_csv(data_root: str, csv_glob: str):
    pat = csv_glob if csv_glob else "**/*.csv"
    paths = glob.glob(os.path.join(data_root, pat), recursive=True)
    if not paths:
        raise SystemExit(f"No CSV found under {data_root} with pattern {pat}")
    pref = [p for p in paths if "ETHUSDT" in os.path.basename(p).upper()]
    return (pref or paths)[0]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-root", required=True)
    ap.add_argument("--csv-glob", default="**/*.csv")
    ap.add_argument("--outdir", required=True)
    ap.add_argument("--params", default="conf/params.v1.yml")
    args = ap.parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    csv_path = find_csv(args.data_root, args.csv_glob)
    df = pd.read_csv(csv_path)
    st = StrategyV1(params_path=args.params, outdir=args.outdir)
    summary = st.run(df)
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
